<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting keepoldvectorfont="yes"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="yes" active="no"/>
<layer number="2" name="Route2" color="16" fill="1" visible="yes" active="no"/>
<layer number="3" name="Route3" color="17" fill="1" visible="yes" active="no"/>
<layer number="4" name="Route4" color="18" fill="1" visible="yes" active="no"/>
<layer number="5" name="Route5" color="19" fill="1" visible="yes" active="no"/>
<layer number="6" name="Route6" color="25" fill="1" visible="yes" active="no"/>
<layer number="7" name="Route7" color="26" fill="1" visible="yes" active="no"/>
<layer number="8" name="Route8" color="27" fill="1" visible="yes" active="no"/>
<layer number="9" name="Route9" color="28" fill="1" visible="yes" active="no"/>
<layer number="10" name="Route10" color="29" fill="1" visible="yes" active="no"/>
<layer number="11" name="Route11" color="30" fill="1" visible="yes" active="no"/>
<layer number="12" name="Route12" color="20" fill="1" visible="yes" active="no"/>
<layer number="13" name="Route13" color="21" fill="1" visible="yes" active="no"/>
<layer number="14" name="Route14" color="22" fill="1" visible="yes" active="no"/>
<layer number="15" name="Route15" color="23" fill="1" visible="yes" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="yes" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="yes" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="yes" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="yes" active="no"/>
<layer number="20" name="Dimension" color="24" fill="1" visible="yes" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="yes" active="no"/>
<layer number="22" name="bPlace" color="25" fill="1" visible="yes" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="yes" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="yes" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="yes" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="yes" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="yes" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="yes" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="12" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="25" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="yes" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="yes" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="yes" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="yes" active="no"/>
<layer number="48" name="Document" color="11" fill="1" visible="yes" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="yes" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="yes" active="no"/>
<layer number="51" name="tDocu" color="14" fill="1" visible="yes" active="no"/>
<layer number="52" name="bDocu" color="13" fill="1" visible="yes" active="no"/>
<layer number="53" name="tGND_GNDA" color="7" fill="9" visible="yes" active="no"/>
<layer number="54" name="bGND_GNDA" color="1" fill="9" visible="yes" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="yes" active="no"/>
<layer number="57" name="tCAD" color="7" fill="1" visible="yes" active="no"/>
<layer number="58" name="bCopper" color="7" fill="1" visible="yes" active="no"/>
<layer number="59" name="tCarbon" color="7" fill="1" visible="yes" active="no"/>
<layer number="60" name="bCarbon" color="7" fill="1" visible="yes" active="no"/>
<layer number="61" name="stand" color="7" fill="1" visible="yes" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="yes" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="yes" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="no" active="no"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="no" active="yes"/>
<layer number="99" name="SpiceOrder" color="7" fill="1" visible="yes" active="yes"/>
<layer number="100" name="Muster" color="7" fill="1" visible="no" active="no"/>
<layer number="101" name="Patch_Top" color="12" fill="4" visible="no" active="yes"/>
<layer number="102" name="Vscore" color="7" fill="1" visible="yes" active="yes"/>
<layer number="103" name="tMap" color="7" fill="1" visible="yes" active="yes"/>
<layer number="104" name="Name" color="7" fill="1" visible="yes" active="yes"/>
<layer number="105" name="tPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="106" name="bPlate" color="7" fill="1" visible="yes" active="yes"/>
<layer number="107" name="Crop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="108" name="fp8" color="7" fill="1" visible="yes" active="yes"/>
<layer number="109" name="fp9" color="7" fill="1" visible="yes" active="yes"/>
<layer number="110" name="fp0" color="7" fill="1" visible="yes" active="yes"/>
<layer number="111" name="LPC17xx" color="7" fill="1" visible="yes" active="yes"/>
<layer number="112" name="tSilk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="113" name="IDFDebug" color="7" fill="1" visible="yes" active="yes"/>
<layer number="114" name="Badge_Outline" color="7" fill="1" visible="yes" active="yes"/>
<layer number="115" name="ReferenceISLANDS" color="7" fill="1" visible="yes" active="yes"/>
<layer number="116" name="Patch_BOT" color="9" fill="4" visible="no" active="yes"/>
<layer number="117" name="BACKMAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="118" name="Rect_Pads" color="7" fill="1" visible="no" active="yes"/>
<layer number="119" name="KAP_TEKEN" color="7" fill="1" visible="yes" active="yes"/>
<layer number="120" name="KAP_MAAT1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="121" name="_tsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="122" name="_bsilk" color="7" fill="1" visible="no" active="yes"/>
<layer number="123" name="tTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="124" name="bTestmark" color="7" fill="1" visible="yes" active="yes"/>
<layer number="125" name="_tNames" color="7" fill="1" visible="no" active="yes"/>
<layer number="126" name="_bNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="127" name="_tValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="128" name="_bValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="129" name="Mask" color="7" fill="1" visible="yes" active="yes"/>
<layer number="130" name="SMDSTROOK" color="7" fill="1" visible="yes" active="yes"/>
<layer number="131" name="tAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="132" name="bAdjust" color="7" fill="1" visible="yes" active="yes"/>
<layer number="133" name="bottom_silk" color="7" fill="1" visible="yes" active="yes"/>
<layer number="134" name="silk_top" color="7" fill="1" visible="yes" active="yes"/>
<layer number="135" name="silk_bottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="136" name="silktop" color="7" fill="1" visible="yes" active="yes"/>
<layer number="137" name="silkbottom" color="7" fill="1" visible="yes" active="yes"/>
<layer number="138" name="EEE" color="7" fill="1" visible="yes" active="yes"/>
<layer number="139" name="_tKeepout" color="7" fill="1" visible="yes" active="yes"/>
<layer number="140" name="case_and_reflector_section" color="7" fill="1" visible="yes" active="yes"/>
<layer number="141" name="ASSEMBLY_TOP" color="7" fill="1" visible="yes" active="yes"/>
<layer number="142" name="mbRestrict" color="7" fill="1" visible="yes" active="yes"/>
<layer number="143" name="PLACE_BOUND_TOP" color="7" fill="1" visible="yes" active="yes"/>
<layer number="144" name="Drill_legend" color="7" fill="1" visible="no" active="yes"/>
<layer number="145" name="DrillLegend_01-16" color="7" fill="1" visible="yes" active="yes"/>
<layer number="146" name="DrillLegend_01-20" color="7" fill="1" visible="yes" active="yes"/>
<layer number="147" name="PIN_NUMBER" color="7" fill="1" visible="yes" active="yes"/>
<layer number="148" name="mDocument" color="7" fill="1" visible="yes" active="yes"/>
<layer number="149" name="DrillLegend_02-15" color="7" fill="1" visible="yes" active="yes"/>
<layer number="150" name="Notes" color="7" fill="1" visible="yes" active="yes"/>
<layer number="151" name="HeatSink" color="7" fill="1" visible="no" active="yes"/>
<layer number="152" name="_bDocu" color="7" fill="1" visible="yes" active="yes"/>
<layer number="153" name="FabDoc1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="154" name="FabDoc2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="155" name="FabDoc3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="156" name="DXF0409-TOP" color="7" fill="1" visible="no" active="yes"/>
<layer number="157" name="DXF0409-BOTTOM" color="7" fill="1" visible="no" active="yes"/>
<layer number="158" name="FaceMMeas" color="3" fill="1" visible="no" active="no"/>
<layer number="159" name="Geh-Bear2" color="1" fill="7" visible="no" active="no"/>
<layer number="160" name="Topologie" color="9" fill="1" visible="no" active="no"/>
<layer number="161" name="tomplace2" color="7" fill="1" visible="no" active="no"/>
<layer number="166" name="AntennaArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="168" name="4mmHeightArea" color="7" fill="1" visible="yes" active="yes"/>
<layer number="170" name="Pinguin_tPlace" color="7" fill="1" visible="no" active="yes"/>
<layer number="171" name="Pinguin_bPlace" color="7" fill="1" visible="no" active="yes"/>
<layer number="172" name="Pinguin_tBackup" color="7" fill="1" visible="no" active="yes"/>
<layer number="173" name="Pinguin_bBackup" color="7" fill="1" visible="no" active="yes"/>
<layer number="191" name="mNets" color="7" fill="1" visible="yes" active="yes"/>
<layer number="192" name="mBusses" color="7" fill="1" visible="yes" active="yes"/>
<layer number="193" name="mPins" color="7" fill="1" visible="yes" active="yes"/>
<layer number="194" name="mSymbols" color="7" fill="1" visible="yes" active="yes"/>
<layer number="195" name="mNames" color="7" fill="1" visible="yes" active="yes"/>
<layer number="196" name="mValues" color="7" fill="1" visible="yes" active="yes"/>
<layer number="199" name="Contour" color="7" fill="1" visible="yes" active="yes"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="no" active="no"/>
<layer number="201" name="201bmp" color="2" fill="1" visible="no" active="no"/>
<layer number="202" name="202bmp" color="3" fill="1" visible="no" active="no"/>
<layer number="203" name="203bmp" color="4" fill="10" visible="no" active="yes"/>
<layer number="204" name="204bmp" color="5" fill="10" visible="no" active="yes"/>
<layer number="205" name="205bmp" color="6" fill="10" visible="no" active="yes"/>
<layer number="206" name="206bmp" color="7" fill="10" visible="no" active="yes"/>
<layer number="207" name="207bmp" color="8" fill="10" visible="no" active="yes"/>
<layer number="208" name="208bmp" color="9" fill="10" visible="no" active="yes"/>
<layer number="209" name="209bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="210" name="210bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="211" name="211bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="212" name="212bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="213" name="213bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="214" name="214bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="215" name="215bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="216" name="216bmp" color="7" fill="1" visible="no" active="yes"/>
<layer number="217" name="217bmp" color="18" fill="1" visible="no" active="no"/>
<layer number="218" name="218bmp" color="19" fill="1" visible="no" active="no"/>
<layer number="219" name="219bmp" color="20" fill="1" visible="no" active="no"/>
<layer number="220" name="220bmp" color="21" fill="1" visible="no" active="no"/>
<layer number="221" name="221bmp" color="22" fill="1" visible="no" active="no"/>
<layer number="222" name="222bmp" color="23" fill="1" visible="no" active="no"/>
<layer number="223" name="223bmp" color="24" fill="1" visible="no" active="no"/>
<layer number="224" name="224bmp" color="25" fill="1" visible="no" active="no"/>
<layer number="225" name="225bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="226" name="226bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="227" name="227bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="228" name="228bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="229" name="229bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="230" name="230bmp" color="7" fill="1" visible="yes" active="yes"/>
<layer number="231" name="Eagle3D_PG1" color="7" fill="1" visible="yes" active="yes"/>
<layer number="232" name="Eagle3D_PG2" color="7" fill="1" visible="yes" active="yes"/>
<layer number="233" name="Eagle3D_PG3" color="7" fill="1" visible="yes" active="yes"/>
<layer number="247" name="wrappinf" color="7" fill="1" visible="yes" active="yes"/>
<layer number="248" name="Housing" color="7" fill="1" visible="yes" active="yes"/>
<layer number="249" name="Edge" color="7" fill="1" visible="yes" active="yes"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
<layer number="252" name="BR-BS" color="7" fill="1" visible="yes" active="yes"/>
<layer number="253" name="Extra" color="7" fill="1" visible="yes" active="yes"/>
<layer number="254" name="cooling" color="7" fill="1" visible="no" active="yes"/>
<layer number="255" name="routoute" color="7" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="frames" urn="urn:adsk.eagle:library:229">
<packages>
</packages>
<symbols>
<symbol name="A4L-LOC" urn="urn:adsk.eagle:symbol:13874/1" library_version="1">
<wire x1="256.54" y1="3.81" x2="256.54" y2="8.89" width="0.1016" layer="94"/>
<wire x1="256.54" y1="8.89" x2="256.54" y2="13.97" width="0.1016" layer="94"/>
<wire x1="256.54" y1="13.97" x2="256.54" y2="19.05" width="0.1016" layer="94"/>
<wire x1="256.54" y1="19.05" x2="256.54" y2="24.13" width="0.1016" layer="94"/>
<wire x1="161.29" y1="3.81" x2="161.29" y2="24.13" width="0.1016" layer="94"/>
<wire x1="161.29" y1="24.13" x2="215.265" y2="24.13" width="0.1016" layer="94"/>
<wire x1="215.265" y1="24.13" x2="256.54" y2="24.13" width="0.1016" layer="94"/>
<wire x1="246.38" y1="3.81" x2="246.38" y2="8.89" width="0.1016" layer="94"/>
<wire x1="246.38" y1="8.89" x2="256.54" y2="8.89" width="0.1016" layer="94"/>
<wire x1="246.38" y1="8.89" x2="215.265" y2="8.89" width="0.1016" layer="94"/>
<wire x1="215.265" y1="8.89" x2="215.265" y2="3.81" width="0.1016" layer="94"/>
<wire x1="215.265" y1="8.89" x2="215.265" y2="13.97" width="0.1016" layer="94"/>
<wire x1="215.265" y1="13.97" x2="256.54" y2="13.97" width="0.1016" layer="94"/>
<wire x1="215.265" y1="13.97" x2="215.265" y2="19.05" width="0.1016" layer="94"/>
<wire x1="215.265" y1="19.05" x2="256.54" y2="19.05" width="0.1016" layer="94"/>
<wire x1="215.265" y1="19.05" x2="215.265" y2="24.13" width="0.1016" layer="94"/>
<text x="217.17" y="15.24" size="2.54" layer="94">&gt;DRAWING_NAME</text>
<text x="217.17" y="10.16" size="2.286" layer="94">&gt;LAST_DATE_TIME</text>
<text x="230.505" y="5.08" size="2.54" layer="94">&gt;SHEET</text>
<text x="216.916" y="4.953" size="2.54" layer="94">Sheet:</text>
<frame x1="0" y1="0" x2="260.35" y2="179.07" columns="6" rows="4" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="A4L-LOC" urn="urn:adsk.eagle:component:13926/1" prefix="FRAME" uservalue="yes" library_version="1">
<description>&lt;b&gt;FRAME&lt;/b&gt;&lt;p&gt;
DIN A4, landscape with location and doc. field</description>
<gates>
<gate name="G$1" symbol="A4L-LOC" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="supply2" urn="urn:adsk.eagle:library:372">
<packages>
</packages>
<symbols>
<symbol name="GND" urn="urn:adsk.eagle:symbol:26990/1" library_version="2">
<wire x1="-1.27" y1="0" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="0" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0" y1="-1.27" x2="-1.27" y2="0" width="0.254" layer="94"/>
<text x="-1.905" y="-3.175" size="1.778" layer="96">&gt;VALUE</text>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND" urn="urn:adsk.eagle:component:27037/1" prefix="SUPPLY" library_version="2">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="GND" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun">
<packages>
</packages>
<symbols>
<symbol name="VCC2">
<wire x1="0.762" y1="1.27" x2="0" y2="2.54" width="0.254" layer="94"/>
<wire x1="0" y1="2.54" x2="-0.762" y2="1.27" width="0.254" layer="94"/>
<text x="-1.016" y="3.556" size="1.778" layer="96">&gt;VALUE</text>
<pin name="VCC" x="0" y="0" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="VCC" prefix="P+">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="1" symbol="VCC2" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="LowPowerLab">
<packages>
<package name="TQFP32-08">
<description>&lt;B&gt;Thin Plasic Quad Flat Package&lt;/B&gt; Grid 0.8 mm</description>
<smd name="1" x="-4.2926" y="2.8" dx="1.27" dy="0.5334" layer="1"/>
<smd name="2" x="-4.2926" y="2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="3" x="-4.2926" y="1.2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="4" x="-4.2926" y="0.4" dx="1.27" dy="0.5334" layer="1"/>
<smd name="5" x="-4.2926" y="-0.4" dx="1.27" dy="0.5334" layer="1"/>
<smd name="6" x="-4.2926" y="-1.2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="7" x="-4.2926" y="-2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="8" x="-4.2926" y="-2.8" dx="1.27" dy="0.5334" layer="1"/>
<smd name="9" x="-2.8" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="10" x="-2" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="11" x="-1.2" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="12" x="-0.4" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="13" x="0.4" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="14" x="1.2" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="15" x="2" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="16" x="2.8" y="-4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="17" x="4.2926" y="-2.8" dx="1.27" dy="0.5334" layer="1"/>
<smd name="18" x="4.2926" y="-2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="19" x="4.2926" y="-1.2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="20" x="4.2926" y="-0.4" dx="1.27" dy="0.5334" layer="1"/>
<smd name="21" x="4.2926" y="0.4" dx="1.27" dy="0.5334" layer="1"/>
<smd name="22" x="4.2926" y="1.2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="23" x="4.2926" y="2" dx="1.27" dy="0.5334" layer="1"/>
<smd name="24" x="4.2926" y="2.8" dx="1.27" dy="0.5334" layer="1"/>
<smd name="25" x="2.8" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="26" x="2" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="27" x="1.2" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="28" x="0.4" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="29" x="-0.4" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="30" x="-1.2" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="31" x="-2" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<smd name="32" x="-2.8" y="4.2926" dx="0.5334" dy="1.27" layer="1"/>
<text x="-3.175" y="5.08" size="0.4064" layer="25">&gt;NAME</text>
<text x="-2.54" y="-6.35" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-4.5466" y1="2.5714" x2="-3.556" y2="3.0286" layer="51"/>
<rectangle x1="-4.5466" y1="1.7714" x2="-3.556" y2="2.2286" layer="51"/>
<rectangle x1="-4.5466" y1="0.9714" x2="-3.556" y2="1.4286" layer="51"/>
<rectangle x1="-4.5466" y1="0.1714" x2="-3.556" y2="0.6286" layer="51"/>
<rectangle x1="-4.5466" y1="-0.6286" x2="-3.556" y2="-0.1714" layer="51"/>
<rectangle x1="-4.5466" y1="-1.4286" x2="-3.556" y2="-0.9714" layer="51"/>
<rectangle x1="-4.5466" y1="-2.2286" x2="-3.556" y2="-1.7714" layer="51"/>
<rectangle x1="-4.5466" y1="-3.0286" x2="-3.556" y2="-2.5714" layer="51"/>
<rectangle x1="-3.0286" y1="-4.5466" x2="-2.5714" y2="-3.556" layer="51"/>
<rectangle x1="-2.2286" y1="-4.5466" x2="-1.7714" y2="-3.556" layer="51"/>
<rectangle x1="-1.4286" y1="-4.5466" x2="-0.9714" y2="-3.556" layer="51"/>
<rectangle x1="-0.6286" y1="-4.5466" x2="-0.1714" y2="-3.556" layer="51"/>
<rectangle x1="0.1714" y1="-4.5466" x2="0.6286" y2="-3.556" layer="51"/>
<rectangle x1="0.9714" y1="-4.5466" x2="1.4286" y2="-3.556" layer="51"/>
<rectangle x1="1.7714" y1="-4.5466" x2="2.2286" y2="-3.556" layer="51"/>
<rectangle x1="2.5714" y1="-4.5466" x2="3.0286" y2="-3.556" layer="51"/>
<rectangle x1="3.556" y1="-3.0286" x2="4.5466" y2="-2.5714" layer="51"/>
<rectangle x1="3.556" y1="-2.2286" x2="4.5466" y2="-1.7714" layer="51"/>
<rectangle x1="3.556" y1="-1.4286" x2="4.5466" y2="-0.9714" layer="51"/>
<rectangle x1="3.556" y1="-0.6286" x2="4.5466" y2="-0.1714" layer="51"/>
<rectangle x1="3.556" y1="0.1714" x2="4.5466" y2="0.6286" layer="51"/>
<rectangle x1="3.556" y1="0.9714" x2="4.5466" y2="1.4286" layer="51"/>
<rectangle x1="3.556" y1="1.7714" x2="4.5466" y2="2.2286" layer="51"/>
<rectangle x1="3.556" y1="2.5714" x2="4.5466" y2="3.0286" layer="51"/>
<rectangle x1="2.5714" y1="3.556" x2="3.0286" y2="4.5466" layer="51"/>
<rectangle x1="1.7714" y1="3.556" x2="2.2286" y2="4.5466" layer="51"/>
<rectangle x1="0.9714" y1="3.556" x2="1.4286" y2="4.5466" layer="51"/>
<rectangle x1="0.1714" y1="3.556" x2="0.6286" y2="4.5466" layer="51"/>
<rectangle x1="-0.6286" y1="3.556" x2="-0.1714" y2="4.5466" layer="51"/>
<rectangle x1="-1.4286" y1="3.556" x2="-0.9714" y2="4.5466" layer="51"/>
<rectangle x1="-2.2286" y1="3.556" x2="-1.7714" y2="4.5466" layer="51"/>
<rectangle x1="-3.0286" y1="3.556" x2="-2.5714" y2="4.5466" layer="51"/>
<wire x1="-3.937" y1="3.937" x2="3.937" y2="3.937" width="0.127" layer="51"/>
<wire x1="3.937" y1="3.937" x2="3.937" y2="-3.937" width="0.127" layer="51"/>
<wire x1="3.937" y1="-3.937" x2="-3.937" y2="-3.937" width="0.127" layer="51"/>
<wire x1="-3.937" y1="-3.937" x2="-3.937" y2="3.937" width="0.127" layer="51"/>
<circle x="-3.937" y="3.937" radius="0.0635" width="0.762" layer="51"/>
</package>
<package name="CAP-PTH-SMALL">
<wire x1="1.27" y1="0.635" x2="1.27" y2="-0.635" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="0.7" diameter="1.651"/>
<pad name="2" x="2.54" y="0" drill="0.7" diameter="1.651"/>
<text x="0.508" y="1.27" size="0.4064" layer="25">&gt;Name</text>
<text x="0.254" y="-1.524" size="0.4064" layer="27">&gt;Value</text>
</package>
<package name="CAP-PTH-SMALL2">
<wire x1="1.27" y1="0.635" x2="1.27" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="1.27" x2="3.81" y2="1.27" width="0.2032" layer="21"/>
<wire x1="3.81" y1="1.27" x2="3.81" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="3.81" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="1.27" width="0.2032" layer="21"/>
<pad name="1" x="0" y="0" drill="0.7" diameter="1.651"/>
<pad name="2" x="2.54" y="0" drill="0.7" diameter="1.651"/>
<text x="-1.27" y="1.905" size="0.6096" layer="25">&gt;Name</text>
<text x="-1.27" y="-2.54" size="0.6096" layer="27">&gt;Value</text>
</package>
<package name="CAP-PTH-LARGE">
<wire x1="0" y1="0.635" x2="0" y2="0" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="0" y2="-0.635" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="-2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="0" y1="0" x2="2.54" y2="0" width="0.2032" layer="21"/>
<pad name="1" x="-4.826" y="0" drill="0.9" diameter="1.905"/>
<pad name="2" x="4.572" y="0" drill="0.9" diameter="1.905"/>
<text x="-0.762" y="1.27" size="0.4064" layer="25">&gt;Name</text>
<text x="-1.016" y="-1.524" size="0.4064" layer="27">&gt;Value</text>
</package>
<package name="0603-CAP">
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.016" dy="0.9652" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.016" dy="0.9652" layer="1"/>
<text x="-0.889" y="0.762" size="0.4064" layer="25" font="vector">&gt;NAME</text>
<text x="-1.016" y="-1.143" size="0.4064" layer="27" font="vector">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
<wire x1="-0.127" y1="-0.254" x2="0.127" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.127" y1="0.254" x2="0.127" y2="0.254" width="0.254" layer="21"/>
</package>
<package name="CAP-PTH-5MM">
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.2032" layer="21"/>
<pad name="1" x="-2.5" y="0" drill="0.7" diameter="1.651"/>
<pad name="2" x="2.5" y="0" drill="0.7" diameter="1.651"/>
<text x="-0.762" y="1.27" size="0.4064" layer="25">&gt;Name</text>
<text x="-1.016" y="-1.524" size="0.4064" layer="27">&gt;Value</text>
</package>
<package name="AXIAL-5MM">
<wire x1="-1.14" y1="0.762" x2="1.14" y2="0.762" width="0.2032" layer="21"/>
<wire x1="1.14" y1="0.762" x2="1.14" y2="0" width="0.2032" layer="21"/>
<wire x1="1.14" y1="0" x2="1.14" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="1.14" y1="-0.762" x2="-1.14" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="-1.14" y1="-0.762" x2="-1.14" y2="0" width="0.2032" layer="21"/>
<wire x1="-1.14" y1="0" x2="-1.14" y2="0.762" width="0.2032" layer="21"/>
<wire x1="1.14" y1="0" x2="1.394" y2="0" width="0.2032" layer="21"/>
<wire x1="-1.14" y1="0" x2="-1.394" y2="0" width="0.2032" layer="21"/>
<pad name="P$1" x="-2.5" y="0" drill="0.9" diameter="1.8796"/>
<pad name="P$2" x="2.5" y="0" drill="0.9" diameter="1.8796"/>
<text x="-2.54" y="1.17" size="0.4" layer="25">&gt;Name</text>
<text x="-1.032" y="-0.208" size="0.4" layer="21" ratio="15">&gt;Value</text>
</package>
<package name="CTZ3">
<description>CTZ3 Series land pattern for variable capacitor - CTZ3E-50C-W1-PF</description>
<wire x1="-1.6" y1="1.4" x2="-1.6" y2="-2.25" width="0.127" layer="51"/>
<wire x1="-1.6" y1="-2.25" x2="1.6" y2="-2.25" width="0.127" layer="51"/>
<wire x1="1.6" y1="1.4" x2="1.6" y2="-2.25" width="0.127" layer="51"/>
<wire x1="-0.5" y1="0" x2="0.5" y2="0" width="0.127" layer="51"/>
<wire x1="-1.6" y1="1.4" x2="-1" y2="2.2" width="0.127" layer="51"/>
<wire x1="1.6" y1="1.4" x2="1" y2="2.2" width="0.127" layer="51"/>
<wire x1="-1" y1="2.2" x2="1" y2="2.2" width="0.127" layer="51"/>
<wire x1="0" y1="0.8" x2="0" y2="-0.8" width="0.127" layer="51"/>
<wire x1="-0.8" y1="0" x2="0.8" y2="0" width="0.127" layer="51"/>
<wire x1="-1.05" y1="2.25" x2="-1.7" y2="1.45" width="0.127" layer="21"/>
<wire x1="-1.7" y1="1.45" x2="-1.7" y2="-2.35" width="0.127" layer="21"/>
<wire x1="-1.7" y1="-2.35" x2="-1.05" y2="-2.35" width="0.127" layer="21"/>
<wire x1="1.05" y1="2.25" x2="1.7" y2="1.4" width="0.127" layer="21"/>
<wire x1="1.7" y1="1.4" x2="1.7" y2="-2.35" width="0.127" layer="21"/>
<wire x1="1.7" y1="-2.35" x2="1.05" y2="-2.35" width="0.127" layer="21"/>
<smd name="+" x="0" y="2.05" dx="1.5" dy="1.2" layer="1"/>
<smd name="-" x="0" y="-2.05" dx="1.5" dy="1.2" layer="1"/>
<text x="-2" y="3" size="0.4064" layer="25">&gt;NAME</text>
<text x="-2" y="-3.4" size="0.4064" layer="27">&gt;VALUE</text>
</package>
<package name="CAP-PTH-SMALL-KIT">
<description>&lt;h3&gt;CAP-PTH-SMALL-KIT&lt;/h3&gt;
Commonly used for small ceramic capacitors. Like our 0.1uF (http://www.sparkfun.com/products/8375) or 22pF caps (http://www.sparkfun.com/products/8571).&lt;br&gt;
&lt;br&gt;
&lt;b&gt;Warning:&lt;/b&gt; This is the KIT version of this package. This package has a smaller diameter top stop mask, which doesn't cover the diameter of the pad. This means only the bottom side of the pads' copper will be exposed. You'll only be able to solder to the bottom side.</description>
<wire x1="0" y1="0.635" x2="0" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-2.667" y1="1.27" x2="2.667" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.667" y1="1.27" x2="2.667" y2="-1.27" width="0.254" layer="21"/>
<wire x1="2.667" y1="-1.27" x2="-2.667" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.667" y1="-1.27" x2="-2.667" y2="1.27" width="0.254" layer="21"/>
<pad name="1" x="-1.397" y="0" drill="1.016" diameter="2.032" stop="no"/>
<pad name="2" x="1.397" y="0" drill="1.016" diameter="2.032" stop="no"/>
<polygon width="0.127" layer="30">
<vertex x="-1.4021" y="-0.9475" curve="-90"/>
<vertex x="-2.357" y="-0.0178" curve="-90.011749"/>
<vertex x="-1.4046" y="0.9576" curve="-90"/>
<vertex x="-0.4546" y="-0.0204" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="-1.4046" y="-0.4395" curve="-90.012891"/>
<vertex x="-1.8491" y="-0.0153" curve="-90"/>
<vertex x="-1.4046" y="0.452" curve="-90"/>
<vertex x="-0.9627" y="-0.0051" curve="-90.012967"/>
</polygon>
<polygon width="0.127" layer="30">
<vertex x="1.397" y="-0.9475" curve="-90"/>
<vertex x="0.4421" y="-0.0178" curve="-90.011749"/>
<vertex x="1.3945" y="0.9576" curve="-90"/>
<vertex x="2.3445" y="-0.0204" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="1.3945" y="-0.4395" curve="-90.012891"/>
<vertex x="0.95" y="-0.0153" curve="-90"/>
<vertex x="1.3945" y="0.452" curve="-90"/>
<vertex x="1.8364" y="-0.0051" curve="-90.012967"/>
</polygon>
</package>
<package name="0603-RES">
<wire x1="-0.356" y1="0.432" x2="0.356" y2="0.432" width="0.1016" layer="51"/>
<wire x1="-0.356" y1="-0.419" x2="0.356" y2="-0.419" width="0.1016" layer="51"/>
<smd name="1" x="-0.85" y="0" dx="1.016" dy="0.9652" layer="1"/>
<smd name="2" x="0.85" y="0" dx="1.016" dy="0.9652" layer="1"/>
<text x="-0.889" y="0.762" size="0.4064" layer="25" font="vector">&gt;NAME</text>
<text x="-1.016" y="-1.143" size="0.4064" layer="27" font="vector">&gt;VALUE</text>
<rectangle x1="-0.8382" y1="-0.4699" x2="-0.3381" y2="0.4801" layer="51"/>
<rectangle x1="0.3302" y1="-0.4699" x2="0.8303" y2="0.4801" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
<wire x1="-0.127" y1="0" x2="0.127" y2="0" width="0.254" layer="21"/>
</package>
<package name="1/6W-RES">
<description>1/6W Thru-hole Resistor - *UNPROVEN*</description>
<wire x1="-1.55" y1="0.85" x2="-1.55" y2="-0.85" width="0.2032" layer="21"/>
<wire x1="-1.55" y1="-0.85" x2="1.55" y2="-0.85" width="0.2032" layer="21"/>
<wire x1="1.55" y1="-0.85" x2="1.55" y2="0.85" width="0.2032" layer="21"/>
<wire x1="1.55" y1="0.85" x2="-1.55" y2="0.85" width="0.2032" layer="21"/>
<pad name="1" x="-2.5" y="0" drill="0.762"/>
<pad name="2" x="2.5" y="0" drill="0.762"/>
<text x="-1.2662" y="0.9552" size="0.6096" layer="25">&gt;NAME</text>
<text x="-1.423" y="-0.4286" size="0.8128" layer="21" ratio="15">&gt;VALUE</text>
</package>
<package name="AXIAL-0.4">
<description>1/4W Resistor, 0.4" wide&lt;p&gt;

Yageo CFR series &lt;a href="http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf"&gt;http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf&lt;/a&gt;</description>
<wire x1="-3.15" y1="-1.2" x2="-3.15" y2="1.2" width="0.2032" layer="21"/>
<wire x1="-3.15" y1="1.2" x2="3.15" y2="1.2" width="0.2032" layer="21"/>
<wire x1="3.15" y1="1.2" x2="3.15" y2="-1.2" width="0.2032" layer="21"/>
<wire x1="3.15" y1="-1.2" x2="-3.15" y2="-1.2" width="0.2032" layer="21"/>
<pad name="P$1" x="-5.08" y="0" drill="0.9" diameter="1.8796"/>
<pad name="P$2" x="5.08" y="0" drill="0.9" diameter="1.8796"/>
<text x="-3.175" y="1.905" size="0.8128" layer="25" font="vector" ratio="15">&gt;Name</text>
<text x="-2.286" y="-0.381" size="0.8128" layer="21" font="vector" ratio="15">&gt;Value</text>
</package>
<package name="AXIAL-0.5">
<description>1/2W Resistor, 0.5" wide&lt;p&gt;

Yageo CFR series &lt;a href="http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf"&gt;http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf&lt;/a&gt;</description>
<wire x1="-4.5" y1="-1.65" x2="-4.5" y2="1.65" width="0.2032" layer="21"/>
<wire x1="-4.5" y1="1.65" x2="4.5" y2="1.65" width="0.2032" layer="21"/>
<wire x1="4.5" y1="1.65" x2="4.5" y2="-1.65" width="0.2032" layer="21"/>
<wire x1="4.5" y1="-1.65" x2="-4.5" y2="-1.65" width="0.2032" layer="21"/>
<pad name="P$1" x="-6.35" y="0" drill="0.9" diameter="1.8796"/>
<pad name="P$2" x="6.35" y="0" drill="0.9" diameter="1.8796"/>
<text x="-4.445" y="2.54" size="0.8128" layer="25" font="vector" ratio="15">&gt;Name</text>
<text x="-3.429" y="-0.381" size="0.8128" layer="21" font="vector" ratio="15">&gt;Value</text>
</package>
<package name="AXIAL-0.6">
<description>1W Resistor, 0.6" wide&lt;p&gt;

Yageo CFR series &lt;a href="http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf"&gt;http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf&lt;/a&gt;</description>
<wire x1="-5.75" y1="-2.25" x2="-5.75" y2="2.25" width="0.2032" layer="21"/>
<wire x1="-5.75" y1="2.25" x2="5.75" y2="2.25" width="0.2032" layer="21"/>
<wire x1="5.75" y1="2.25" x2="5.75" y2="-2.25" width="0.2032" layer="21"/>
<wire x1="5.75" y1="-2.25" x2="-5.75" y2="-2.25" width="0.2032" layer="21"/>
<pad name="P$1" x="-7.62" y="0" drill="1.2" diameter="1.8796"/>
<pad name="P$2" x="7.62" y="0" drill="1.2" diameter="1.8796"/>
<text x="-5.715" y="3.175" size="0.8128" layer="25" font="vector" ratio="15">&gt;Name</text>
<text x="-4.064" y="-0.381" size="0.8128" layer="21" font="vector" ratio="15">&gt;Value</text>
</package>
<package name="AXIAL-0.8">
<description>2W Resistor, 0.8" wide&lt;p&gt;

Yageo CFR series &lt;a href="http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf"&gt;http://www.yageo.com/pdf/yageo/Leaded-R_CFR_2008.pdf&lt;/a&gt;</description>
<wire x1="-7.75" y1="-2.5" x2="-7.75" y2="2.5" width="0.2032" layer="21"/>
<wire x1="-7.75" y1="2.5" x2="7.75" y2="2.5" width="0.2032" layer="21"/>
<wire x1="7.75" y1="2.5" x2="7.75" y2="-2.5" width="0.2032" layer="21"/>
<wire x1="7.75" y1="-2.5" x2="-7.75" y2="-2.5" width="0.2032" layer="21"/>
<pad name="P$1" x="-10.16" y="0" drill="1.2" diameter="1.8796"/>
<pad name="P$2" x="10.16" y="0" drill="1.2" diameter="1.8796"/>
<text x="-7.62" y="3.175" size="0.8128" layer="25" font="vector" ratio="15">&gt;Name</text>
<text x="-5.969" y="-0.381" size="0.8128" layer="21" font="vector" ratio="15">&gt;Value</text>
</package>
<package name="AXIAL-0.3-KIT">
<description>&lt;h3&gt;AXIAL-0.3-KIT&lt;/h3&gt;

Commonly used for 1/4W through-hole resistors. 0.3" pitch between holes.&lt;br&gt;
&lt;br&gt;

&lt;b&gt;Warning:&lt;/b&gt; This is the KIT version of the AXIAL-0.3 package. This package has a smaller diameter top stop mask, which doesn't cover the diameter of the pad. This means only the bottom side of the pads' copper will be exposed. You'll only be able to solder to the bottom side.</description>
<wire x1="-2.54" y1="1.27" x2="2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="1.27" x2="2.54" y2="0" width="0.254" layer="21"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="-1.27" x2="-2.54" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.54" y1="-1.27" x2="-2.54" y2="0" width="0.254" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="0" x2="2.794" y2="0" width="0.254" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.794" y2="0" width="0.254" layer="21"/>
<pad name="P$1" x="-3.81" y="0" drill="1.016" diameter="2.032" stop="no"/>
<pad name="P$2" x="3.81" y="0" drill="1.016" diameter="2.032" stop="no"/>
<text x="-2.54" y="1.27" size="0.4064" layer="25" font="vector">&gt;Name</text>
<text x="-2.159" y="-0.762" size="1.27" layer="21" font="vector" ratio="15">&gt;Value</text>
<polygon width="0.127" layer="30">
<vertex x="3.8201" y="-0.9449" curve="-90"/>
<vertex x="2.8652" y="-0.0152" curve="-90.011749"/>
<vertex x="3.8176" y="0.9602" curve="-90"/>
<vertex x="4.7676" y="-0.0178" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="3.8176" y="-0.4369" curve="-90.012891"/>
<vertex x="3.3731" y="-0.0127" curve="-90"/>
<vertex x="3.8176" y="0.4546" curve="-90"/>
<vertex x="4.2595" y="-0.0025" curve="-90.012967"/>
</polygon>
<polygon width="0.127" layer="30">
<vertex x="-3.8075" y="-0.9525" curve="-90"/>
<vertex x="-4.7624" y="-0.0228" curve="-90.011749"/>
<vertex x="-3.81" y="0.9526" curve="-90"/>
<vertex x="-2.86" y="-0.0254" curve="-90.024193"/>
</polygon>
<polygon width="0.127" layer="29">
<vertex x="-3.81" y="-0.4445" curve="-90.012891"/>
<vertex x="-4.2545" y="-0.0203" curve="-90"/>
<vertex x="-3.81" y="0.447" curve="-90"/>
<vertex x="-3.3681" y="-0.0101" curve="-90.012967"/>
</polygon>
</package>
<package name="RES_UPRIGHT">
<wire x1="-2.5025" y1="0.977" x2="-2.5025" y2="-0.977" width="0.2032" layer="21"/>
<wire x1="-2.5025" y1="-0.977" x2="2.5025" y2="-0.977" width="0.2032" layer="21"/>
<wire x1="2.5025" y1="-0.977" x2="2.5025" y2="0.977" width="0.2032" layer="21"/>
<wire x1="2.5025" y1="0.977" x2="-2.5025" y2="0.977" width="0.2032" layer="21"/>
<pad name="1" x="-1.5475" y="0" drill="0.762" diameter="1.524"/>
<pad name="2" x="1.5475" y="0" drill="0.762" diameter="1.524"/>
<text x="-1.5837" y="1.2727" size="0.6096" layer="25">&gt;NAME</text>
<text x="-2.058" y="-2.0161" size="0.8128" layer="21" ratio="15">&gt;VALUE</text>
</package>
<package name="AXIAL-1/4W">
<pad name="P$1" x="-3.81" y="0" drill="0.8" diameter="1.524"/>
<pad name="P$2" x="3.81" y="0" drill="0.8" diameter="1.524"/>
</package>
<package name="1/6W-RES_6MMSPACED">
<wire x1="-2.05" y1="0.85" x2="-2.05" y2="-0.85" width="0.2032" layer="21"/>
<wire x1="-2.05" y1="-0.85" x2="2.05" y2="-0.85" width="0.2032" layer="21"/>
<wire x1="2.05" y1="-0.85" x2="2.05" y2="0.85" width="0.2032" layer="21"/>
<wire x1="2.05" y1="0.85" x2="-2.05" y2="0.85" width="0.2032" layer="21"/>
<pad name="1" x="-3" y="0" drill="0.762"/>
<pad name="2" x="3" y="0" drill="0.762"/>
<text x="-1.2662" y="0.9552" size="0.6096" layer="25">&gt;NAME</text>
<text x="-1.423" y="-0.4286" size="0.8128" layer="21" ratio="15">&gt;VALUE</text>
</package>
<package name="FUSE_UPRIGHT">
<wire x1="-2.5025" y1="0.977" x2="-2.5025" y2="-0.977" width="0.2032" layer="51"/>
<wire x1="-2.5025" y1="-0.977" x2="2.5025" y2="-0.977" width="0.2032" layer="51"/>
<wire x1="2.5025" y1="-0.977" x2="2.5025" y2="0.977" width="0.2032" layer="51"/>
<wire x1="2.5025" y1="0.977" x2="-2.5025" y2="0.977" width="0.2032" layer="51"/>
<pad name="1" x="-1.5475" y="0" drill="0.762" diameter="1.524"/>
<pad name="2" x="1.5475" y="0" drill="0.762" diameter="1.524"/>
<text x="-1.5837" y="1.2727" size="0.6096" layer="25">&gt;NAME</text>
<text x="-2.058" y="-2.0161" size="0.8128" layer="21" ratio="15">&gt;VALUE</text>
</package>
<package name="AXIAL-0.3">
<wire x1="-2.54" y1="0.762" x2="2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0.762" x2="2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="-0.762" x2="-2.54" y2="-0.762" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="-0.762" x2="-2.54" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="0.762" width="0.2032" layer="21"/>
<wire x1="2.54" y1="0" x2="2.794" y2="0" width="0.2032" layer="21"/>
<wire x1="-2.54" y1="0" x2="-2.794" y2="0" width="0.2032" layer="21"/>
<pad name="P$1" x="-3.81" y="0" drill="0.9"/>
<pad name="P$2" x="3.81" y="0" drill="0.9"/>
<text x="-2.54" y="1.27" size="0.4064" layer="25" font="vector">&gt;Name</text>
<text x="-2.032" y="-0.381" size="1.016" layer="21" font="vector" ratio="15">&gt;Value</text>
</package>
<package name="RESONATOR-SMD">
<wire x1="-1.8" y1="-0.65" x2="-1.8" y2="0.65" width="0.2032" layer="21"/>
<wire x1="-1.6" y1="0.65" x2="1.6" y2="0.65" width="0.127" layer="51"/>
<wire x1="1.6" y1="0.65" x2="1.6" y2="-0.65" width="0.127" layer="51"/>
<wire x1="1.6" y1="-0.65" x2="-1.6" y2="-0.65" width="0.127" layer="51"/>
<wire x1="-1.6" y1="-0.65" x2="-1.6" y2="0.65" width="0.127" layer="51"/>
<smd name="XTAL1_IN" x="-1.2" y="0" dx="0.7" dy="1.7" layer="1"/>
<smd name="XTAL2_GND" x="0" y="0" dx="0.7" dy="1.7" layer="1"/>
<smd name="XTAL3_OUTPUT" x="1.2" y="0" dx="0.7" dy="1.7" layer="1"/>
<text x="-0.889" y="1.27" size="0.4064" layer="25">&gt;Name</text>
<text x="-0.889" y="-1.524" size="0.4064" layer="27">&gt;Value</text>
<wire x1="1.397" y1="0.381" x2="0" y2="0.381" width="0.127" layer="51"/>
<wire x1="0" y1="0.381" x2="0" y2="-0.381" width="0.127" layer="51"/>
<wire x1="0" y1="-0.381" x2="1.397" y2="-0.381" width="0.127" layer="51"/>
<wire x1="1.397" y1="-0.381" x2="1.397" y2="0.381" width="0.127" layer="51"/>
</package>
<package name="1210">
<wire x1="-1.6" y1="1.3" x2="1.6" y2="1.3" width="0.127" layer="51"/>
<wire x1="1.6" y1="1.3" x2="1.6" y2="-1.3" width="0.127" layer="51"/>
<wire x1="1.6" y1="-1.3" x2="-1.6" y2="-1.3" width="0.127" layer="51"/>
<wire x1="-1.6" y1="-1.3" x2="-1.6" y2="1.3" width="0.127" layer="51"/>
<wire x1="-1.6" y1="1.2" x2="1.6" y2="1.2" width="0.2032" layer="21"/>
<wire x1="-1.6" y1="-1.2" x2="1.6" y2="-1.2" width="0.2032" layer="21"/>
<smd name="1" x="-1.6" y="0" dx="1.2" dy="2" layer="1"/>
<smd name="2" x="1.6" y="0" dx="1.2" dy="2" layer="1"/>
<text x="-0.8" y="0.5" size="0.4064" layer="25">&gt;NAME</text>
<text x="-0.9" y="-0.7" size="0.4064" layer="27">&gt;VALUE</text>
</package>
<package name="FIDUCIAL_MOTEINO">
<smd name="P$1" x="0" y="0" dx="0.762" dy="0.762" layer="1" roundness="100" stop="no" cream="no"/>
<polygon width="0.0635" layer="29">
<vertex x="-0.5936" y="0" curve="90"/>
<vertex x="0" y="-0.5936" curve="90"/>
<vertex x="0.5936" y="0" curve="90"/>
<vertex x="0" y="0.5936" curve="90"/>
</polygon>
<polygon width="0.0635" layer="41">
<vertex x="-0.6444" y="0" curve="90"/>
<vertex x="0" y="-0.6444" curve="90"/>
<vertex x="0.6444" y="0" curve="90"/>
<vertex x="0" y="0.6444" curve="90"/>
</polygon>
</package>
<package name="FIDUCIAL_1.5MM">
<smd name="P$1" x="0" y="0" dx="0.762" dy="0.762" layer="1" roundness="100" stop="no" cream="no"/>
<polygon width="0.254" layer="29">
<vertex x="-0.619" y="0" curve="90"/>
<vertex x="0" y="-0.619" curve="90"/>
<vertex x="0.619" y="0" curve="90"/>
<vertex x="0" y="0.619" curve="90"/>
</polygon>
<polygon width="0.3302" layer="41">
<vertex x="-0.619" y="0" curve="90"/>
<vertex x="0" y="-0.619" curve="90"/>
<vertex x="0.619" y="0" curve="90"/>
<vertex x="0" y="0.619" curve="90"/>
</polygon>
</package>
<package name="FIDUCIAL_1.7MM">
<smd name="P$1" x="0" y="0" dx="0.85" dy="0.85" layer="1" roundness="100" stop="no" cream="no"/>
<polygon width="0.254" layer="29">
<vertex x="-0.719" y="0" curve="90"/>
<vertex x="0" y="-0.719" curve="90"/>
<vertex x="0.719" y="0" curve="90"/>
<vertex x="0" y="0.719" curve="90"/>
</polygon>
<polygon width="0.3302" layer="41">
<vertex x="-0.719" y="0" curve="90"/>
<vertex x="0" y="-0.719" curve="90"/>
<vertex x="0.719" y="0" curve="90"/>
<vertex x="0" y="0.719" curve="90"/>
</polygon>
</package>
<package name="WS2812-2020">
<description>&lt;h3&gt;WS2812-2020 - 2020 package for the WS2812&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count: 4&lt;/li&gt;
&lt;li&gt;Pin pitch: 1 mm&lt;/li&gt;
&lt;li&gt;Area: 2.2 mm x 2.0 mm&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=https://www.aliexpress.com/store/product/WS2812-2020-Intelligent-control-LED-integrated-light-source-2020-SMD-RGB-LED-with-built-in-WS2811/701799_32879024689.html?spm=2114.12010612.8148356.3.67626848TBx3Ev&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;</description>
<smd name="2" x="1.115" y="0.55" dx="1" dy="0.7" layer="1"/>
<smd name="1" x="1.115" y="-0.55" dx="1" dy="0.7" layer="1"/>
<smd name="4" x="-1.115" y="-0.55" dx="1" dy="0.7" layer="1"/>
<smd name="3" x="-1.115" y="0.55" dx="1" dy="0.7" layer="1"/>
<wire x1="-1.1" y1="1.1" x2="1.1" y2="1.1" width="0.127" layer="21"/>
<wire x1="1.1" y1="-1.1" x2="-1.1" y2="-1.1" width="0.127" layer="21"/>
<rectangle x1="0" y1="-1" x2="0.5" y2="1" layer="51"/>
<wire x1="-1.1" y1="1" x2="-1.1" y2="-1" width="0.127" layer="51"/>
<wire x1="-1.1" y1="-1" x2="1.1" y2="-1" width="0.127" layer="51"/>
<wire x1="1.1" y1="-1" x2="1.1" y2="1" width="0.127" layer="51"/>
<wire x1="1.1" y1="1" x2="-1.1" y2="1" width="0.127" layer="51"/>
<wire x1="-1.1" y1="-0.1" x2="-1.1" y2="0.1" width="0.127" layer="21"/>
<wire x1="1.1" y1="-0.1" x2="1.1" y2="0.1" width="0.127" layer="21"/>
<circle x="1.427" y="-1.3" radius="0.07" width="0.1778" layer="21"/>
<rectangle x1="-0.508" y1="0.381" x2="0.508" y2="0.889" layer="21"/>
<circle x="0" y="-0.508" radius="0.127" width="0.254" layer="21"/>
</package>
<package name="WS2812-1515">
<description>&lt;h3&gt;WS2812-2020 - 2020 package for the WS2812&lt;/h3&gt;
&lt;p&gt;Specifications:
&lt;ul&gt;&lt;li&gt;Pin count: 4&lt;/li&gt;
&lt;li&gt;Pin pitch: 1 mm&lt;/li&gt;
&lt;li&gt;Area: 2.2 mm x 2.0 mm&lt;/li&gt;
&lt;/ul&gt;&lt;/p&gt;
&lt;p&gt;&lt;a href=https://www.aliexpress.com/store/product/WS2812-2020-Intelligent-control-LED-integrated-light-source-2020-SMD-RGB-LED-with-built-in-WS2811/701799_32879024689.html?spm=2114.12010612.8148356.3.67626848TBx3Ev&gt;Datasheet referenced for footprint&lt;/a&gt;&lt;/p&gt;</description>
<smd name="DOUT" x="0.8" y="0.45" dx="1" dy="0.5" layer="1"/>
<smd name="VDD" x="0.8" y="-0.45" dx="1" dy="0.5" layer="1"/>
<smd name="DIN" x="-0.8" y="-0.45" dx="1" dy="0.5" layer="1"/>
<smd name="GND" x="-0.8" y="0.45" dx="1" dy="0.5" layer="1"/>
<wire x1="-0.7" y1="0.8" x2="0.7" y2="0.8" width="0.127" layer="21"/>
<wire x1="0.7" y1="-0.8" x2="-0.7" y2="-0.8" width="0.127" layer="21"/>
<wire x1="-0.7" y1="0.8" x2="-0.7" y2="-0.8" width="0.127" layer="51"/>
<wire x1="-0.7" y1="-0.8" x2="0.7" y2="-0.8" width="0.127" layer="51"/>
<wire x1="0.7" y1="-0.8" x2="0.7" y2="0.8" width="0.127" layer="51"/>
<wire x1="0.7" y1="0.8" x2="-0.7" y2="0.8" width="0.127" layer="51"/>
<wire x1="1.1" y1="0.12" x2="0.7" y2="0.12" width="0.127" layer="21"/>
<circle x="-0.92" y="-0.92" radius="0.07" width="0.127" layer="21"/>
<wire x1="0.7" y1="0.12" x2="0.9" y2="-0.13" width="0.127" layer="21"/>
<wire x1="0.9" y1="-0.13" x2="1.1" y2="0.12" width="0.127" layer="21"/>
<wire x1="0.99" y1="0.02" x2="0.82" y2="0.02" width="0.17" layer="21"/>
</package>
<package name="SOT23-3">
<wire x1="1.4224" y1="0.6604" x2="1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="1.4224" y1="-0.6604" x2="-1.4224" y2="-0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="-0.6604" x2="-1.4224" y2="0.6604" width="0.1524" layer="51"/>
<wire x1="-1.4224" y1="0.6604" x2="1.4224" y2="0.6604" width="0.1524" layer="51"/>
<smd name="1" x="-0.95" y="-1" dx="0.9" dy="1" layer="1"/>
<smd name="2" x="0.95" y="-1" dx="0.9" dy="1" layer="1"/>
<smd name="3" x="0" y="1.1" dx="0.9" dy="1" layer="1"/>
<text x="-0.8255" y="1.778" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.016" y="-0.1905" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-0.254" y1="0.762" x2="0.254" y2="1.397" layer="51"/>
<rectangle x1="-1.2065" y1="-1.397" x2="-0.6985" y2="-0.762" layer="51"/>
<rectangle x1="0.6985" y1="-1.397" x2="1.2065" y2="-0.762" layer="51"/>
<wire x1="-1.4224" y1="0.6604" x2="-0.6096" y2="0.6604" width="0.1524" layer="21"/>
<wire x1="0.6096" y1="0.6604" x2="1.4224" y2="0.6604" width="0.1524" layer="21"/>
<wire x1="1.4224" y1="0.6604" x2="1.4224" y2="-0.4064" width="0.1524" layer="21"/>
<wire x1="-1.4224" y1="-0.4064" x2="-1.4224" y2="0.6604" width="0.1524" layer="21"/>
<wire x1="0.4064" y1="-0.6604" x2="-0.4064" y2="-0.6604" width="0.1524" layer="21"/>
</package>
<package name="1206">
<wire x1="-2.473" y1="0.983" x2="2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="-0.983" x2="-2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-2.473" y1="-0.983" x2="-2.473" y2="0.983" width="0.0508" layer="39"/>
<wire x1="2.473" y1="0.983" x2="2.473" y2="-0.983" width="0.0508" layer="39"/>
<wire x1="-0.965" y1="0.787" x2="0.965" y2="0.787" width="0.1016" layer="51"/>
<wire x1="-0.965" y1="-0.787" x2="0.965" y2="-0.787" width="0.1016" layer="51"/>
<smd name="1" x="-1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<smd name="2" x="1.4" y="0" dx="1.6" dy="1.8" layer="1"/>
<text x="-1.27" y="1.143" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.397" y="-1.524" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-1.7018" y1="-0.8509" x2="-0.9517" y2="0.8491" layer="51"/>
<rectangle x1="0.9517" y1="-0.8491" x2="1.7018" y2="0.8509" layer="51"/>
<rectangle x1="-0.1999" y1="-0.4001" x2="0.1999" y2="0.4001" layer="35"/>
</package>
<package name="R2010">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;
chip</description>
<wire x1="-1.662" y1="1.245" x2="1.662" y2="1.245" width="0.1524" layer="51"/>
<wire x1="-1.637" y1="-1.245" x2="1.687" y2="-1.245" width="0.1524" layer="51"/>
<wire x1="-3.473" y1="1.483" x2="3.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="3.473" y1="1.483" x2="3.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="3.473" y1="-1.483" x2="-3.473" y2="-1.483" width="0.0508" layer="39"/>
<wire x1="-3.473" y1="-1.483" x2="-3.473" y2="1.483" width="0.0508" layer="39"/>
<wire x1="-1.027" y1="1.245" x2="1.027" y2="1.245" width="0.1524" layer="21"/>
<wire x1="-1.002" y1="-1.245" x2="1.016" y2="-1.245" width="0.1524" layer="21"/>
<smd name="1" x="-2.2" y="0" dx="1.8" dy="2.7" layer="1"/>
<smd name="2" x="2.2" y="0" dx="1.8" dy="2.7" layer="1"/>
<text x="-2.54" y="1.5875" size="0.4064" layer="25">&gt;NAME</text>
<text x="-2.54" y="-2.032" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-2.4892" y1="-1.3208" x2="-1.6393" y2="1.3292" layer="51"/>
<rectangle x1="1.651" y1="-1.3208" x2="2.5009" y2="1.3292" layer="51"/>
</package>
<package name="0805">
<smd name="1" x="-0.873" y="0" dx="1.054" dy="1.3" layer="1"/>
<smd name="2" x="0.873" y="0" dx="1.054" dy="1.3" layer="1"/>
<text x="-0.762" y="0.8255" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.016" y="-1.397" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-1" y1="-0.625" x2="1" y2="0.625" layer="51"/>
</package>
<package name="0402-RES">
<description>&lt;b&gt;RESISTOR&lt;/b&gt;&lt;p&gt;
SMD</description>
<wire x1="-0.245" y1="0.1986" x2="0.245" y2="0.1986" width="0.1" layer="51"/>
<wire x1="0.245" y1="-0.2002" x2="-0.245" y2="-0.2002" width="0.1" layer="51"/>
<smd name="1" x="-0.508" y="0" dx="0.508" dy="0.6604" layer="1"/>
<smd name="2" x="0.508" y="0" dx="0.508" dy="0.6604" layer="1"/>
<text x="-0.889" y="0.6985" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.0795" y="-1.143" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
<wire x1="-0.5" y1="0.25" x2="0.5" y2="0.25" width="0" layer="48"/>
<wire x1="0.5" y1="0.25" x2="0.5" y2="-0.25" width="0" layer="48"/>
<wire x1="0.5" y1="-0.25" x2="-0.5" y2="-0.25" width="0" layer="48"/>
<wire x1="-0.5" y1="-0.25" x2="-0.5" y2="0.25" width="0" layer="48"/>
<wire x1="-0.127" y1="0" x2="0.127" y2="0" width="0.254" layer="21"/>
<rectangle x1="-0.5" y1="-0.2508" x2="-0.2" y2="0.2492" layer="51"/>
<rectangle x1="0.2" y1="-0.2508" x2="0.5" y2="0.2492" layer="51"/>
<wire x1="-0.762" y1="0.3302" x2="0.762" y2="0.3302" width="0.0254" layer="51"/>
<wire x1="-0.762" y1="0.3302" x2="-0.762" y2="-0.3302" width="0.0254" layer="51"/>
<wire x1="0.762" y1="0.3302" x2="0.762" y2="-0.3302" width="0.0254" layer="51"/>
<wire x1="-0.762" y1="-0.3302" x2="0.762" y2="-0.3302" width="0.0254" layer="51"/>
</package>
<package name="0805-RES">
<smd name="1" x="-1.127" y="0" dx="1.016" dy="1.3208" layer="1"/>
<smd name="2" x="1.127" y="0" dx="1.016" dy="1.3208" layer="1"/>
<text x="-0.762" y="0.8255" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.016" y="-1.397" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-1" y1="-0.625" x2="1" y2="0.625" layer="51"/>
<wire x1="-0.1" y1="0.7" x2="-0.1" y2="0.5" width="0.2" layer="21"/>
<wire x1="-0.1" y1="0.5" x2="0.3" y2="0.2" width="0.2" layer="21"/>
<wire x1="0.3" y1="0.2" x2="-0.3" y2="0" width="0.2" layer="21"/>
<wire x1="-0.3" y1="0" x2="0.3" y2="-0.3" width="0.2" layer="21"/>
<wire x1="0.3" y1="-0.3" x2="-0.1" y2="-0.5" width="0.2" layer="21"/>
<wire x1="-0.1" y1="-0.5" x2="-0.1" y2="-0.7" width="0.2" layer="21"/>
</package>
<package name="VAR_RADIAL">
<wire x1="-3.5185" y1="0.977" x2="-3.5185" y2="-0.977" width="0.2032" layer="51"/>
<wire x1="-3.5185" y1="-0.977" x2="3.5185" y2="-0.977" width="0.2032" layer="51"/>
<wire x1="3.5185" y1="-0.977" x2="3.5185" y2="0.977" width="0.2032" layer="51"/>
<wire x1="3.5185" y1="0.977" x2="-3.5185" y2="0.977" width="0.2032" layer="51"/>
<pad name="1" x="-2.5635" y="0" drill="0.762" diameter="1.524"/>
<pad name="2" x="2.5635" y="0" drill="0.762" diameter="1.524"/>
<text x="-1.5837" y="1.2727" size="0.6096" layer="25">&gt;NAME</text>
<text x="-2.058" y="-2.0161" size="0.8128" layer="21" ratio="15">&gt;VALUE</text>
<wire x1="-1.27" y1="0.508" x2="-1.27" y2="0" width="0.127" layer="51"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-0.508" width="0.127" layer="51"/>
<wire x1="-1.27" y1="-0.508" x2="1.27" y2="0.508" width="0.127" layer="51"/>
<wire x1="1.27" y1="0.508" x2="1.27" y2="-0.508" width="0.127" layer="51"/>
<wire x1="-1.778" y1="0" x2="-1.27" y2="0" width="0.127" layer="51"/>
<wire x1="1.778" y1="0" x2="1.27" y2="0" width="0.127" layer="51"/>
</package>
<package name="1210_RES">
<wire x1="-1.6" y1="1.3" x2="1.6" y2="1.3" width="0.127" layer="51"/>
<wire x1="1.6" y1="1.3" x2="1.6" y2="-1.3" width="0.127" layer="51"/>
<wire x1="1.6" y1="-1.3" x2="-1.6" y2="-1.3" width="0.127" layer="51"/>
<wire x1="-1.6" y1="-1.3" x2="-1.6" y2="1.3" width="0.127" layer="51"/>
<smd name="1" x="-1.6" y="0" dx="2.95" dy="1.45" layer="1" rot="R90"/>
<smd name="2" x="1.6" y="0" dx="2.95" dy="1.45" layer="1" rot="R90"/>
<text x="-1.1" y="1.6" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.1" y="-2" size="0.4064" layer="27">&gt;VALUE</text>
<wire x1="-0.1" y1="0.7" x2="-0.1" y2="0.5" width="0.2" layer="21"/>
<wire x1="-0.1" y1="0.5" x2="0.3" y2="0.2" width="0.2" layer="21"/>
<wire x1="0.3" y1="0.2" x2="-0.3" y2="0" width="0.2" layer="21"/>
<wire x1="-0.3" y1="0" x2="0.3" y2="-0.3" width="0.2" layer="21"/>
<wire x1="0.3" y1="-0.3" x2="-0.1" y2="-0.5" width="0.2" layer="21"/>
<wire x1="-0.1" y1="-0.5" x2="-0.1" y2="-0.7" width="0.2" layer="21"/>
</package>
<package name="MLF32">
<description>&lt;b&gt;32M1-A&lt;/b&gt; Micro Lead Frame package (MLF)</description>
<wire x1="-2.05" y1="2.35" x2="2.05" y2="2.35" width="0.254" layer="51"/>
<wire x1="2.05" y1="2.35" x2="2.35" y2="2.05" width="0.254" layer="21"/>
<wire x1="2.35" y1="2.05" x2="2.35" y2="-2.05" width="0.254" layer="51"/>
<wire x1="2.35" y1="-2.05" x2="2.05" y2="-2.35" width="0.254" layer="21"/>
<wire x1="2.05" y1="-2.35" x2="-2.05" y2="-2.35" width="0.254" layer="51"/>
<wire x1="-2.05" y1="-2.35" x2="-2.35" y2="-2.05" width="0.254" layer="21"/>
<wire x1="-2.35" y1="-2.05" x2="-2.35" y2="2.05" width="0.254" layer="51"/>
<circle x="-2.35" y="2.35" radius="0.15" width="0.254" layer="21"/>
<smd name="1" x="-2.35" y="1.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="2" x="-2.35" y="1.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="3" x="-2.35" y="0.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="4" x="-2.35" y="0.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="5" x="-2.35" y="-0.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="6" x="-2.35" y="-0.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="7" x="-2.35" y="-1.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="8" x="-2.35" y="-1.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="9" x="-1.75" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="10" x="-1.25" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="11" x="-0.75" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="12" x="-0.25" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="13" x="0.25" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="14" x="0.75" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="15" x="1.25" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="16" x="1.75" y="-2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="17" x="2.35" y="-1.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="18" x="2.35" y="-1.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="19" x="2.35" y="-0.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="20" x="2.35" y="-0.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="21" x="2.35" y="0.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="22" x="2.35" y="0.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="23" x="2.35" y="1.25" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="24" x="2.35" y="1.75" dx="0.7" dy="0.3" layer="1" roundness="50"/>
<smd name="25" x="1.75" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="26" x="1.25" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="27" x="0.75" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="28" x="0.25" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="29" x="-0.25" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="30" x="-0.75" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="31" x="-1.25" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<smd name="32" x="-1.75" y="2.35" dx="0.3" dy="0.7" layer="1" roundness="50"/>
<text x="-2.54" y="3.175" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-4.445" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.5" y1="1.6" x2="-2.05" y2="1.9" layer="51"/>
<rectangle x1="-2.5" y1="1.1" x2="-2.05" y2="1.4" layer="51"/>
<rectangle x1="-2.5" y1="0.6" x2="-2.05" y2="0.9" layer="51"/>
<rectangle x1="-2.5" y1="0.1" x2="-2.05" y2="0.4" layer="51"/>
<rectangle x1="-2.5" y1="-0.4" x2="-2.05" y2="-0.1" layer="51"/>
<rectangle x1="-2.5" y1="-0.9" x2="-2.05" y2="-0.6" layer="51"/>
<rectangle x1="-2.5" y1="-1.4" x2="-2.05" y2="-1.1" layer="51"/>
<rectangle x1="-2.5" y1="-1.9" x2="-2.05" y2="-1.6" layer="51"/>
<rectangle x1="-1.9" y1="-2.5" x2="-1.6" y2="-2.05" layer="51"/>
<rectangle x1="-1.4" y1="-2.5" x2="-1.1" y2="-2.05" layer="51"/>
<rectangle x1="-0.9" y1="-2.5" x2="-0.6" y2="-2.05" layer="51"/>
<rectangle x1="-0.4" y1="-2.5" x2="-0.1" y2="-2.05" layer="51"/>
<rectangle x1="0.1" y1="-2.5" x2="0.4" y2="-2.05" layer="51"/>
<rectangle x1="0.6" y1="-2.5" x2="0.9" y2="-2.05" layer="51"/>
<rectangle x1="1.1" y1="-2.5" x2="1.4" y2="-2.05" layer="51"/>
<rectangle x1="1.6" y1="-2.5" x2="1.9" y2="-2.05" layer="51"/>
<rectangle x1="2.05" y1="-1.9" x2="2.5" y2="-1.6" layer="51"/>
<rectangle x1="2.05" y1="-1.4" x2="2.5" y2="-1.1" layer="51"/>
<rectangle x1="2.05" y1="-0.9" x2="2.5" y2="-0.6" layer="51"/>
<rectangle x1="2.05" y1="-0.4" x2="2.5" y2="-0.1" layer="51"/>
<rectangle x1="2.05" y1="0.1" x2="2.5" y2="0.4" layer="51"/>
<rectangle x1="2.05" y1="0.6" x2="2.5" y2="0.9" layer="51"/>
<rectangle x1="2.05" y1="1.1" x2="2.5" y2="1.4" layer="51"/>
<rectangle x1="2.05" y1="1.6" x2="2.5" y2="1.9" layer="51"/>
<rectangle x1="1.6" y1="2.05" x2="1.9" y2="2.5" layer="51"/>
<rectangle x1="1.1" y1="2.05" x2="1.4" y2="2.5" layer="51"/>
<rectangle x1="0.6" y1="2.05" x2="0.9" y2="2.5" layer="51"/>
<rectangle x1="0.1" y1="2.05" x2="0.4" y2="2.5" layer="51"/>
<rectangle x1="-0.4" y1="2.05" x2="-0.1" y2="2.5" layer="51"/>
<rectangle x1="-0.9" y1="2.05" x2="-0.6" y2="2.5" layer="51"/>
<rectangle x1="-1.4" y1="2.05" x2="-1.1" y2="2.5" layer="51"/>
<rectangle x1="-1.9" y1="2.05" x2="-1.6" y2="2.5" layer="51"/>
</package>
<package name="MLF32_RECTPADS">
<wire x1="2.304" y1="2.604" x2="2.604" y2="2.304" width="0.254" layer="51"/>
<wire x1="2.604" y1="-2.304" x2="2.304" y2="-2.604" width="0.254" layer="51"/>
<wire x1="-2.304" y1="-2.604" x2="-2.604" y2="-2.304" width="0.254" layer="51"/>
<circle x="-2.477" y="2.477" radius="0.15" width="0.254" layer="51"/>
<smd name="1" x="-2.731" y="1.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="2" x="-2.731" y="1.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="3" x="-2.731" y="0.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="4" x="-2.731" y="0.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="5" x="-2.731" y="-0.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="6" x="-2.731" y="-0.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="7" x="-2.731" y="-1.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="8" x="-2.731" y="-1.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="9" x="-1.75" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="10" x="-1.25" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="11" x="-0.75" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="12" x="-0.25" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="13" x="0.25" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="14" x="0.75" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="15" x="1.25" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="16" x="1.75" y="-2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="17" x="2.731" y="-1.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="18" x="2.731" y="-1.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="19" x="2.731" y="-0.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="20" x="2.731" y="-0.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="21" x="2.731" y="0.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="22" x="2.731" y="0.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="23" x="2.731" y="1.25" dx="0.889" dy="0.3" layer="1"/>
<smd name="24" x="2.731" y="1.75" dx="0.889" dy="0.3" layer="1"/>
<smd name="25" x="1.75" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="26" x="1.25" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="27" x="0.75" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="28" x="0.25" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="29" x="-0.25" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="30" x="-0.75" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="31" x="-1.25" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<smd name="32" x="-1.75" y="2.731" dx="0.3" dy="0.889" layer="1"/>
<text x="-2.54" y="3.175" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-4.445" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-2.5" y1="1.6" x2="-2.05" y2="1.9" layer="51"/>
<rectangle x1="-2.5" y1="1.1" x2="-2.05" y2="1.4" layer="51"/>
<rectangle x1="-2.5" y1="0.6" x2="-2.05" y2="0.9" layer="51"/>
<rectangle x1="-2.5" y1="0.1" x2="-2.05" y2="0.4" layer="51"/>
<rectangle x1="-2.5" y1="-0.4" x2="-2.05" y2="-0.1" layer="51"/>
<rectangle x1="-2.5" y1="-0.9" x2="-2.05" y2="-0.6" layer="51"/>
<rectangle x1="-2.5" y1="-1.4" x2="-2.05" y2="-1.1" layer="51"/>
<rectangle x1="-2.5" y1="-1.9" x2="-2.05" y2="-1.6" layer="51"/>
<rectangle x1="-1.9" y1="-2.5" x2="-1.6" y2="-2.05" layer="51"/>
<rectangle x1="-1.4" y1="-2.5" x2="-1.1" y2="-2.05" layer="51"/>
<rectangle x1="-0.9" y1="-2.5" x2="-0.6" y2="-2.05" layer="51"/>
<rectangle x1="-0.4" y1="-2.5" x2="-0.1" y2="-2.05" layer="51"/>
<rectangle x1="0.1" y1="-2.5" x2="0.4" y2="-2.05" layer="51"/>
<rectangle x1="0.6" y1="-2.5" x2="0.9" y2="-2.05" layer="51"/>
<rectangle x1="1.1" y1="-2.5" x2="1.4" y2="-2.05" layer="51"/>
<rectangle x1="1.6" y1="-2.5" x2="1.9" y2="-2.05" layer="51"/>
<rectangle x1="2.05" y1="-1.9" x2="2.5" y2="-1.6" layer="51"/>
<rectangle x1="2.05" y1="-1.4" x2="2.5" y2="-1.1" layer="51"/>
<rectangle x1="2.05" y1="-0.9" x2="2.5" y2="-0.6" layer="51"/>
<rectangle x1="2.05" y1="-0.4" x2="2.5" y2="-0.1" layer="51"/>
<rectangle x1="2.05" y1="0.1" x2="2.5" y2="0.4" layer="51"/>
<rectangle x1="2.05" y1="0.6" x2="2.5" y2="0.9" layer="51"/>
<rectangle x1="2.05" y1="1.1" x2="2.5" y2="1.4" layer="51"/>
<rectangle x1="2.05" y1="1.6" x2="2.5" y2="1.9" layer="51"/>
<rectangle x1="1.6" y1="2.05" x2="1.9" y2="2.5" layer="51"/>
<rectangle x1="1.1" y1="2.05" x2="1.4" y2="2.5" layer="51"/>
<rectangle x1="0.6" y1="2.05" x2="0.9" y2="2.5" layer="51"/>
<rectangle x1="0.1" y1="2.05" x2="0.4" y2="2.5" layer="51"/>
<rectangle x1="-0.4" y1="2.05" x2="-0.1" y2="2.5" layer="51"/>
<rectangle x1="-0.9" y1="2.05" x2="-0.6" y2="2.5" layer="51"/>
<rectangle x1="-1.4" y1="2.05" x2="-1.1" y2="2.5" layer="51"/>
<rectangle x1="-1.9" y1="2.05" x2="-1.6" y2="2.5" layer="51"/>
</package>
<package name="GRM43D">
<wire x1="2.25" y1="1.6" x2="1.1" y2="1.6" width="0.127" layer="51"/>
<wire x1="1.1" y1="1.6" x2="-1.1" y2="1.6" width="0.127" layer="51"/>
<wire x1="-1.1" y1="1.6" x2="-2.25" y2="1.6" width="0.127" layer="51"/>
<wire x1="-2.25" y1="1.6" x2="-2.25" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-2.25" y1="-1.6" x2="-1.1" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-1.1" y1="-1.6" x2="1.1" y2="-1.6" width="0.127" layer="51"/>
<wire x1="1.1" y1="-1.6" x2="2.25" y2="-1.6" width="0.127" layer="51"/>
<wire x1="2.25" y1="-1.6" x2="2.25" y2="1.6" width="0.127" layer="51"/>
<wire x1="1.1" y1="1.6" x2="1.1" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-1.1" y1="1.6" x2="-1.1" y2="-1.6" width="0.127" layer="51"/>
<wire x1="-2.3" y1="1.8" x2="2.3" y2="1.8" width="0.127" layer="21"/>
<wire x1="-2.3" y1="-1.8" x2="2.3" y2="-1.8" width="0.127" layer="21"/>
<smd name="A" x="1.927" y="0" dx="3.2" dy="1.65" layer="1" rot="R90"/>
<smd name="C" x="-1.927" y="0" dx="3.2" dy="1.65" layer="1" rot="R90"/>
<text x="-2" y="2" size="0.4064" layer="25">&gt;NAME</text>
<text x="0" y="-2" size="0.4064" layer="27" rot="R180">&gt;VALUE</text>
<rectangle x1="-2.2" y1="-1.6" x2="-1.1" y2="1.6" layer="51"/>
<rectangle x1="1.1" y1="-1.6" x2="2.2" y2="1.6" layer="51"/>
</package>
<package name="0402-CAP">
<description>&lt;b&gt;CAPACITOR&lt;/b&gt;&lt;p&gt;
SMD</description>
<smd name="1" x="-0.5" y="0" dx="0.6" dy="0.7" layer="1"/>
<smd name="2" x="0.5" y="0" dx="0.6" dy="0.7" layer="1"/>
<text x="-0.889" y="0.6985" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.0795" y="-1.143" size="0.4064" layer="27">&gt;VALUE</text>
<wire x1="-0.245" y1="0.1986" x2="0.245" y2="0.1986" width="0.1" layer="51"/>
<wire x1="0.245" y1="-0.2002" x2="-0.245" y2="-0.2002" width="0.1" layer="51"/>
<rectangle x1="-0.1999" y1="-0.3" x2="0.1999" y2="0.3" layer="35"/>
<wire x1="-0.5" y1="0.25" x2="0.5" y2="0.25" width="0" layer="48"/>
<wire x1="0.5" y1="-0.25" x2="-0.5" y2="-0.25" width="0" layer="48"/>
<wire x1="-0.5" y1="-0.25" x2="-0.5" y2="0.25" width="0" layer="48"/>
<rectangle x1="-0.5" y1="-0.2508" x2="-0.2" y2="0.2492" layer="51"/>
<rectangle x1="0.2" y1="-0.2508" x2="0.5" y2="0.2492" layer="51"/>
<wire x1="-0.762" y1="0.3302" x2="0.762" y2="0.3302" width="0.0254" layer="51"/>
<wire x1="-0.762" y1="0.3302" x2="-0.762" y2="-0.3302" width="0.0254" layer="51"/>
<wire x1="0.762" y1="0.3302" x2="0.762" y2="-0.3302" width="0.0254" layer="51"/>
<wire x1="-0.762" y1="-0.3302" x2="0.762" y2="-0.3302" width="0.0254" layer="51"/>
</package>
<package name="0805-CAP">
<wire x1="-0.2" y1="0.5" x2="-0.2" y2="-0.5" width="0.2" layer="21"/>
<wire x1="0.2" y1="0.5" x2="0.2" y2="-0.5" width="0.2" layer="21"/>
<smd name="1" x="-1" y="0" dx="0.9016" dy="1.3" layer="1"/>
<smd name="2" x="1" y="0" dx="0.9016" dy="1.3" layer="1"/>
<text x="-0.762" y="0.8255" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.016" y="-1.397" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-1" y1="-0.625" x2="1" y2="0.625" layer="51"/>
<wire x1="-0.3" y1="0" x2="-0.5" y2="0" width="0.2" layer="21"/>
<wire x1="0.3" y1="0" x2="0.5" y2="0" width="0.2" layer="21"/>
</package>
<package name="0805-CAP-LARGEPADS">
<wire x1="-0.2" y1="0.5" x2="-0.2" y2="-0.5" width="0.2" layer="21"/>
<wire x1="0.2" y1="0.5" x2="0.2" y2="-0.5" width="0.2" layer="21"/>
<smd name="1" x="-1.127" y="0" dx="1.1556" dy="1.3" layer="1"/>
<smd name="2" x="1.127" y="0" dx="1.1556" dy="1.3" layer="1"/>
<text x="-0.762" y="0.8255" size="0.4064" layer="25">&gt;NAME</text>
<text x="-1.016" y="-1.397" size="0.4064" layer="27">&gt;VALUE</text>
<rectangle x1="-1" y1="-0.625" x2="1" y2="0.625" layer="51"/>
<wire x1="-0.3" y1="0" x2="-0.5" y2="0" width="0.2" layer="21"/>
<wire x1="0.3" y1="0" x2="0.5" y2="0" width="0.2" layer="21"/>
</package>
<package name="R2512">
<wire x1="-2.362" y1="1.473" x2="2.387" y2="1.473" width="0.1524" layer="51"/>
<wire x1="-2.362" y1="-1.473" x2="2.387" y2="-1.473" width="0.1524" layer="51"/>
<smd name="1" x="-2.8" y="0" dx="1.8" dy="3.2" layer="1" cream="no"/>
<smd name="2" x="2.8" y="0" dx="1.8" dy="3.2" layer="1" cream="no"/>
<text x="-2.54" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-3.2004" y1="-1.5494" x2="-2.3505" y2="1.5507" layer="51"/>
<rectangle x1="2.3622" y1="-1.5494" x2="3.2121" y2="1.5507" layer="51"/>
<rectangle x1="-3.683" y1="0.254" x2="-1.9304" y2="1.5748" layer="31"/>
<rectangle x1="-3.683" y1="-1.5748" x2="-1.9304" y2="-0.254" layer="31"/>
<rectangle x1="1.9304" y1="-1.5748" x2="3.683" y2="-0.254" layer="31"/>
<rectangle x1="1.9304" y1="0.254" x2="3.683" y2="1.5748" layer="31"/>
</package>
<package name="RESONATOR-PTH">
<wire x1="-2.286" y1="1.778" x2="-2.286" y2="-1.778" width="0.2032" layer="21" curve="162.403081"/>
<wire x1="2.286" y1="-1.778" x2="2.286" y2="1.778" width="0.2032" layer="21" curve="162.403081"/>
<wire x1="-2.286" y1="-1.778" x2="2.286" y2="-1.778" width="0.2032" layer="21" curve="12.71932"/>
<wire x1="2.286" y1="1.778" x2="-2.286" y2="1.778" width="0.2032" layer="21" curve="12.758496"/>
<pad name="2" x="0" y="0" drill="0.8" diameter="1.8796"/>
<pad name="1" x="-2.54" y="0" drill="0.8" diameter="1.8796"/>
<pad name="3" x="2.54" y="0" drill="0.8" diameter="1.8796"/>
</package>
<package name="POWERPAK">
<description>&lt;b&gt;Small Outline Package&lt;/b&gt; Fits JEDEC packages (narrow SOIC-8)</description>
<wire x1="-2.362" y1="-1.803" x2="2.362" y2="-1.803" width="0.1524" layer="51"/>
<wire x1="2.362" y1="-1.803" x2="2.362" y2="1.803" width="0.1524" layer="51"/>
<wire x1="2.362" y1="1.803" x2="-2.362" y2="1.803" width="0.1524" layer="51"/>
<wire x1="-2.362" y1="1.803" x2="-2.362" y2="-1.803" width="0.1524" layer="51"/>
<circle x="-2.0034" y="-1.3906" radius="0.1436" width="0.2032" layer="51"/>
<smd name="1_S" x="-1.905" y="-2.6162" dx="0.61" dy="1.524" layer="1"/>
<smd name="2_S" x="-0.635" y="-2.6162" dx="0.61" dy="1.524" layer="1"/>
<smd name="3_S" x="0.635" y="-2.6162" dx="0.61" dy="1.524" layer="1"/>
<smd name="4_G" x="1.905" y="-2.6162" dx="0.61" dy="1.524" layer="1"/>
<smd name="5_D" x="1.905" y="2.7162" dx="0.61" dy="1.27" layer="1"/>
<smd name="6_D" x="0.635" y="2.7162" dx="0.61" dy="1.27" layer="1"/>
<smd name="7_D" x="-0.635" y="2.7162" dx="0.61" dy="1.27" layer="1"/>
<smd name="8_D" x="-1.905" y="2.7162" dx="0.61" dy="1.27" layer="1"/>
<text x="-1.27" y="-0.635" size="0.4064" layer="27">&gt;VALUE</text>
<text x="-1.27" y="0" size="0.4064" layer="25">&gt;NAME</text>
<rectangle x1="-2.0828" y1="-2.8702" x2="-1.7272" y2="-1.8542" layer="51"/>
<rectangle x1="-0.8128" y1="-2.8702" x2="-0.4572" y2="-1.8542" layer="51"/>
<rectangle x1="0.4572" y1="-2.8702" x2="0.8128" y2="-1.8542" layer="51"/>
<rectangle x1="1.7272" y1="-2.8702" x2="2.0828" y2="-1.8542" layer="51"/>
<rectangle x1="-2.0828" y1="1.8542" x2="-1.7272" y2="2.8702" layer="51"/>
<rectangle x1="-0.8128" y1="1.8542" x2="-0.4572" y2="2.8702" layer="51"/>
<rectangle x1="0.4572" y1="1.8542" x2="0.8128" y2="2.8702" layer="51"/>
<rectangle x1="1.7272" y1="1.8542" x2="2.0828" y2="2.8702" layer="51"/>
<smd name="THERMAL_D" x="0" y="0.7" dx="3.7" dy="3.9" layer="1" rot="R90" cream="no"/>
<rectangle x1="-1.651" y1="0.5334" x2="-0.381" y2="1.8034" layer="31"/>
<rectangle x1="0.381" y1="0.508" x2="1.651" y2="1.778" layer="31"/>
<rectangle x1="0.381" y1="-1.0922" x2="1.651" y2="0.1778" layer="31"/>
<rectangle x1="-1.651" y1="-1.0922" x2="-0.381" y2="0.1778" layer="31"/>
</package>
<package name="POWERPAK1212/8-POWER-VDFN">
<description>Vishay PowerPAK 1212-8 single device package&lt;br&gt;
High-power, low thermal resistance package.</description>
<smd name="S3" x="-1.4224" y="-0.3302" dx="0.9906" dy="0.4064" layer="1"/>
<smd name="S2" x="-1.4224" y="0.3302" dx="0.9906" dy="0.4064" layer="1"/>
<smd name="S1" x="-1.4224" y="0.9906" dx="0.9906" dy="0.4064" layer="1"/>
<smd name="G" x="-1.4224" y="-0.9906" dx="0.9906" dy="0.4064" layer="1"/>
<smd name="D2" x="1.5494" y="0.3302" dx="0.762" dy="0.4064" layer="1"/>
<smd name="D1" x="1.5494" y="0.9906" dx="0.762" dy="0.4064" layer="1"/>
<smd name="D3" x="1.5494" y="-0.3302" dx="0.762" dy="0.4064" layer="1"/>
<smd name="D4" x="1.5494" y="-0.9906" dx="0.762" dy="0.4064" layer="1"/>
<smd name="DPAD" x="0.5842" y="0" dx="1.7272" dy="2.2352" layer="1" cream="no"/>
<wire x1="-1.5" y1="1.5" x2="1.5" y2="1.5" width="0.127" layer="21"/>
<wire x1="1.5" y1="1.5" x2="1.5" y2="1.35" width="0.127" layer="21"/>
<wire x1="-1.5" y1="1.5" x2="-1.5" y2="1.4" width="0.127" layer="21"/>
<wire x1="-1.5" y1="-1.5" x2="1.5" y2="-1.5" width="0.127" layer="21"/>
<wire x1="1.5" y1="-1.5" x2="1.5" y2="-1.35" width="0.127" layer="21"/>
<wire x1="-1.5" y1="-1.5" x2="-1.5" y2="-1.35" width="0.127" layer="21"/>
<text x="-1.143" y="0.508" size="0.4064" layer="27">&gt;VALUE</text>
<text x="-1.143" y="-0.381" size="0.4064" layer="25">&gt;NAME</text>
<rectangle x1="-0.127" y1="0.127" x2="0.762" y2="1.016" layer="31"/>
<rectangle x1="-0.127" y1="-1.016" x2="0.762" y2="-0.127" layer="31"/>
</package>
<package name="SO08">
<description>&lt;b&gt;Small Outline Package&lt;/b&gt; Fits JEDEC packages (narrow SOIC-8)</description>
<wire x1="-2.362" y1="-1.903" x2="2.362" y2="-1.903" width="0.1524" layer="51"/>
<wire x1="2.362" y1="-1.903" x2="2.362" y2="1.903" width="0.1524" layer="21"/>
<wire x1="2.362" y1="1.903" x2="-2.362" y2="1.903" width="0.1524" layer="51"/>
<wire x1="-2.362" y1="1.903" x2="-2.362" y2="-1.903" width="0.1524" layer="21"/>
<circle x="-1.9034" y="-1.0906" radius="0.12" width="0.25" layer="51"/>
<smd name="1" x="-1.905" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="2" x="-0.635" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="3" x="0.635" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="4" x="1.905" y="-2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="5" x="1.905" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="6" x="0.635" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="7" x="-0.635" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<smd name="8" x="-1.905" y="2.6162" dx="0.6096" dy="2.2098" layer="1"/>
<text x="-1.27" y="-0.635" size="0.4064" layer="27">&gt;VALUE</text>
<text x="-1.27" y="0" size="0.4064" layer="25">&gt;NAME</text>
<rectangle x1="-2.1" y1="1.9" x2="-1.7" y2="3" layer="51"/>
<rectangle x1="-0.85" y1="1.9" x2="-0.45" y2="3" layer="51"/>
<rectangle x1="0.45" y1="1.9" x2="0.85" y2="3" layer="51"/>
<rectangle x1="1.7" y1="1.9" x2="2.1" y2="3" layer="51"/>
<rectangle x1="1.7" y1="-3" x2="2.1" y2="-1.9" layer="51" rot="R180"/>
<rectangle x1="0.45" y1="-3" x2="0.85" y2="-1.9" layer="51" rot="R180"/>
<rectangle x1="-0.85" y1="-3" x2="-0.45" y2="-1.9" layer="51" rot="R180"/>
<rectangle x1="-2.1" y1="-3" x2="-1.7" y2="-1.9" layer="51" rot="R180"/>
</package>
<package name="ANTENNA_THRUHOLE">
<pad name="P$1" x="0" y="0" drill="0.8" diameter="1.4224"/>
</package>
<package name="ANTENNA_HELICAL_433MHZ">
<pad name="P$1" x="-16.65" y="0" drill="0.8" diameter="1.4224"/>
<wire x1="-18" y1="-4" x2="-18" y2="4" width="0.254" layer="21"/>
<wire x1="18" y1="-4" x2="18" y2="4" width="0.254" layer="21"/>
<wire x1="-18" y1="4" x2="18" y2="4" width="0.254" layer="21"/>
<wire x1="18" y1="-4" x2="-18" y2="-4" width="0.254" layer="21"/>
<hole x="-12.5" y="0" drill="2.5"/>
<hole x="12.5" y="0" drill="2.5"/>
</package>
<package name="ANTENNA_THRUHOLE_FAT">
<pad name="P$1" x="0" y="0" drill="0.8" diameter="2.032"/>
</package>
<package name="RFM95_LONGER_WITHRST">
<wire x1="-8.107" y1="-8" x2="7.651" y2="-8" width="0.127" layer="51"/>
<wire x1="7.651" y1="8" x2="-8.107" y2="8" width="0.127" layer="51"/>
<text x="-2.849" y="10.08" size="1.27" layer="25" font="vector" ratio="16">&gt;NAME</text>
<text x="-2.929" y="8.65" size="1.27" layer="27" font="vector" ratio="16">&gt;VALUE</text>
<text x="4.2" y="6.4702" size="0.8" layer="51" ratio="15" rot="R270">XTAL</text>
<smd name="DIO0" x="7.651" y="3" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="3.3V" x="7.651" y="1" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="GND" x="7.651" y="-5" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="ANT" x="7.651" y="-7" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="MISO" x="-8.107" y="5" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="GND1" x="-8.107" y="-7" dx="2" dy="1.27" layer="1" cream="no"/>
<text x="5.275" y="0.203" size="1.5" layer="51" ratio="15">+</text>
<text x="3.7" y="-7.503" size="1" layer="51" ratio="15">ANT</text>
<smd name="MOSI" x="-8.107" y="2.968" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="SCK" x="-8.107" y="0.936" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="NSS" x="-8.107" y="-1.096" dx="2" dy="1.27" layer="1" cream="no"/>
<smd name="GND2" x="-8.107" y="7.032" dx="2" dy="1.27" layer="1" cream="no"/>
<wire x1="3.437" y1="6.735" x2="5.723" y2="6.735" width="0.127" layer="51"/>
<wire x1="5.723" y1="6.735" x2="5.723" y2="3.0012" width="0.127" layer="51"/>
<wire x1="5.723" y1="3.0012" x2="3.437" y2="3.0012" width="0.127" layer="51"/>
<wire x1="3.437" y1="3.0012" x2="3.437" y2="6.735" width="0.127" layer="51"/>
<wire x1="-5.2564" y1="6.8754" x2="0.5602" y2="6.8754" width="0.127" layer="51"/>
<wire x1="0.5602" y1="6.8754" x2="0.5602" y2="1.4906" width="0.127" layer="51"/>
<wire x1="0.5602" y1="1.4906" x2="-5.2564" y2="1.4906" width="0.127" layer="51"/>
<wire x1="-5.2564" y1="1.4906" x2="-5.2564" y2="6.8754" width="0.127" layer="51"/>
<text x="-3.7216" y="3.6506" size="0.8" layer="51" ratio="15">RF95</text>
<smd name="RST" x="-8.107" y="-3.128" dx="2" dy="1.27" layer="1" cream="no"/>
</package>
<package name="PAD_1">
<smd name="P$1" x="0" y="0" dx="0.762" dy="1.27" layer="1" roundness="33" rot="R180"/>
</package>
<package name="PAD_1_BIG">
<smd name="P$1" x="0" y="0" dx="2.54" dy="1.27" layer="1" roundness="25" rot="R90"/>
</package>
<package name="PINHEAD_1_BIG">
<pad name="P$1" x="0" y="0" drill="1.016" shape="octagon"/>
</package>
<package name="PINHEAD_1_LONG">
<pad name="P$1" x="0" y="0" drill="1.016" shape="offset" rot="R90"/>
</package>
<package name="1X01NS">
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8796" rot="R90"/>
</package>
<package name="1X01_THIN_NOSILK">
<pad name="P$1" x="0" y="0" drill="0.762" diameter="1.397"/>
</package>
<package name="1X1.27MMHDR">
<pad name="P$3" x="0" y="0" drill="0.6604" diameter="1.016"/>
</package>
<package name="PINHEAD_1_MED">
<pad name="MINUS" x="0.035" y="0" drill="0.8128" diameter="1.524"/>
</package>
<package name="1X01NS_TERMINALS">
<pad name="1" x="0" y="0" drill="1.27" diameter="2.159" rot="R90"/>
</package>
<package name="1X01NS_RFM69">
<pad name="P$1" x="0" y="0" drill="0.8" diameter="1.25"/>
</package>
<package name="TOUCH_PAD">
<smd name="P$1" x="0" y="0" dx="2.54" dy="2.54" layer="1" rot="R180" stop="no" thermals="no" cream="no"/>
<wire x1="-3.81" y1="3.81" x2="-2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="-2.54" y1="3.81" x2="-1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="3.81" x2="0" y2="3.81" width="0.381" layer="1"/>
<wire x1="0" y1="3.81" x2="1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="3.81" x2="2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="3.81" x2="3.81" y2="3.81" width="0.381" layer="1"/>
<wire x1="3.81" y1="3.81" x2="3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="3.81" y1="2.54" x2="3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="3.81" y1="1.27" x2="3.81" y2="0" width="0.381" layer="1"/>
<wire x1="3.81" y1="0" x2="3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="3.81" y1="-2.54" x2="3.81" y2="-3.81" width="0.381" layer="1"/>
<wire x1="3.81" y1="-3.81" x2="2.54" y2="-3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="-3.81" x2="1.27" y2="-3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="-3.81" x2="0" y2="-3.81" width="0.381" layer="1"/>
<wire x1="0" y1="-3.81" x2="-1.27" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="-3.81" x2="-2.54" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-2.54" y1="-3.81" x2="-3.81" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-3.81" x2="-3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-2.54" x2="-3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-1.27" x2="-3.81" y2="0" width="0.381" layer="1"/>
<wire x1="-3.81" y1="0" x2="-3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="-3.81" y2="3.81" width="0.381" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="1.27" x2="3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="0" x2="3.81" y2="0" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-1.27" x2="3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-2.54" x2="3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="-2.54" y1="-3.81" x2="-2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="-3.81" x2="-1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="0" y1="-3.81" x2="0" y2="3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="-3.81" x2="1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="-3.81" x2="2.54" y2="3.81" width="0.381" layer="1"/>
</package>
<package name="PAD_1_TESTPOINT">
<circle x="0" y="0" radius="0.508" width="0.635" layer="1"/>
<circle x="0" y="0" radius="0.8128" width="0" layer="29"/>
<pad name="TP" x="0" y="0" drill="0.5842" stop="no"/>
</package>
<package name="1X01NS_THINRING">
<pad name="1" x="0" y="0" drill="1.016" diameter="1.8288" rot="R90"/>
</package>
<package name="PAD_1_BIG_RECT">
<smd name="P$1" x="0" y="0" dx="2" dy="2" layer="1" roundness="25" rot="R90"/>
</package>
<package name="TOUCH_PAD_WITHSTOP">
<smd name="P$1" x="0" y="0" dx="2.54" dy="2.54" layer="1" rot="R180" stop="no" thermals="no" cream="no"/>
<polygon width="0.508" layer="29">
<vertex x="-3.81" y="3.81"/>
<vertex x="-3.81" y="-3.81"/>
<vertex x="3.81" y="-3.81"/>
<vertex x="3.81" y="3.81"/>
</polygon>
<wire x1="-3.81" y1="3.81" x2="-2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="-2.54" y1="3.81" x2="-1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="3.81" x2="0" y2="3.81" width="0.381" layer="1"/>
<wire x1="0" y1="3.81" x2="1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="3.81" x2="2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="3.81" x2="3.81" y2="3.81" width="0.381" layer="1"/>
<wire x1="3.81" y1="3.81" x2="3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="3.81" y1="2.54" x2="3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="3.81" y1="1.27" x2="3.81" y2="0" width="0.381" layer="1"/>
<wire x1="3.81" y1="0" x2="3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="3.81" y1="-2.54" x2="3.81" y2="-3.81" width="0.381" layer="1"/>
<wire x1="3.81" y1="-3.81" x2="2.54" y2="-3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="-3.81" x2="1.27" y2="-3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="-3.81" x2="0" y2="-3.81" width="0.381" layer="1"/>
<wire x1="0" y1="-3.81" x2="-1.27" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="-3.81" x2="-2.54" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-2.54" y1="-3.81" x2="-3.81" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-3.81" x2="-3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-2.54" x2="-3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-1.27" x2="-3.81" y2="0" width="0.381" layer="1"/>
<wire x1="-3.81" y1="0" x2="-3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="-3.81" y2="3.81" width="0.381" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="1.27" x2="3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="0" x2="3.81" y2="0" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-1.27" x2="3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-2.54" x2="3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="-2.54" y1="-3.81" x2="-2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="-3.81" x2="-1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="0" y1="-3.81" x2="0" y2="3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="-3.81" x2="1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="-3.81" x2="2.54" y2="3.81" width="0.381" layer="1"/>
<rectangle x1="-3.683" y1="1.4224" x2="-2.6924" y2="2.8956" layer="1" rot="R180"/>
<rectangle x1="2.667" y1="1.4224" x2="3.6576" y2="2.8956" layer="1" rot="R180"/>
<rectangle x1="2.667" y1="-2.8956" x2="3.6576" y2="-1.4224" layer="1" rot="R180"/>
<rectangle x1="-3.683" y1="-2.8956" x2="-2.6924" y2="-1.4224" layer="1" rot="R180"/>
</package>
<package name="TOUCH_PAD_WITHSTOP_2">
<smd name="P$1" x="-3.7846" y="-3.7846" dx="0.254" dy="0.254" layer="1" rot="R180" stop="no" thermals="no" cream="no"/>
<polygon width="0.508" layer="29">
<vertex x="-3.81" y="3.81"/>
<vertex x="-3.81" y="-3.81"/>
<vertex x="3.81" y="-3.81"/>
<vertex x="3.81" y="3.81"/>
</polygon>
<wire x1="-3.81" y1="3.81" x2="-2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="-2.54" y1="3.81" x2="-1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="-1.27" y1="3.81" x2="0" y2="3.81" width="0.381" layer="1"/>
<wire x1="0" y1="3.81" x2="1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="1.27" y1="3.81" x2="2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="3.81" x2="3.81" y2="3.81" width="0.381" layer="1"/>
<wire x1="3.81" y1="3.81" x2="3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="3.81" y1="2.54" x2="3.81" y2="1.2446" width="0.381" layer="1"/>
<wire x1="3.81" y1="1.2446" x2="3.81" y2="0" width="0.381" layer="1"/>
<wire x1="3.81" y1="0" x2="3.81" y2="-1.27" width="0.381" layer="1"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="3.81" y1="-2.54" x2="3.81" y2="-3.81" width="0.381" layer="1"/>
<wire x1="3.81" y1="-3.81" x2="2.54" y2="-3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="-3.81" x2="1.3208" y2="-3.81" width="0.381" layer="1"/>
<wire x1="1.3208" y1="-3.81" x2="0.0254" y2="-3.81" width="0.381" layer="1"/>
<wire x1="0.0254" y1="-3.81" x2="-1.2446" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-1.2446" y1="-3.81" x2="-2.54" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-2.54" y1="-3.81" x2="-3.81" y2="-3.81" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-3.81" x2="-3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-2.54" x2="-3.81" y2="-1.2446" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-1.2446" x2="-3.81" y2="0" width="0.381" layer="1"/>
<wire x1="-3.81" y1="0" x2="-3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="1.27" x2="-3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="-3.81" y2="3.81" width="0.381" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="3.81" y2="2.54" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-2.54" x2="3.81" y2="-2.54" width="0.381" layer="1"/>
<wire x1="-2.54" y1="-3.81" x2="-2.54" y2="3.81" width="0.381" layer="1"/>
<wire x1="2.54" y1="-3.81" x2="2.54" y2="3.81" width="0.381" layer="1"/>
<rectangle x1="-3.683" y1="1.4224" x2="-2.6924" y2="2.8956" layer="1" rot="R180"/>
<rectangle x1="2.667" y1="1.4224" x2="3.6576" y2="2.8956" layer="1" rot="R180"/>
<rectangle x1="2.667" y1="-2.8956" x2="3.6576" y2="-1.4224" layer="1" rot="R180"/>
<rectangle x1="-3.683" y1="-2.8956" x2="-2.6924" y2="-1.4224" layer="1" rot="R180"/>
<wire x1="-3.81" y1="0" x2="-1.4732" y2="0" width="0.381" layer="1"/>
<wire x1="1.4732" y1="0" x2="3.81" y2="0" width="0.381" layer="1"/>
<wire x1="0" y1="1.4732" x2="0" y2="3.81" width="0.381" layer="1"/>
<wire x1="0.0254" y1="-3.81" x2="0.0254" y2="-1.4732" width="0.381" layer="1"/>
<circle x="0" y="0" radius="1.25" width="0" layer="51"/>
<circle x="0" y="0" radius="1.46" width="0.381" layer="1"/>
<wire x1="-1.27" y1="0.7366" x2="-1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="-1.2446" y1="-3.81" x2="-1.2446" y2="-0.7874" width="0.381" layer="1"/>
<wire x1="1.27" y1="0.7366" x2="1.27" y2="3.81" width="0.381" layer="1"/>
<wire x1="1.3208" y1="-3.81" x2="1.3208" y2="-0.6604" width="0.381" layer="1"/>
<wire x1="-4.699" y1="-3.7846" x2="-4.1402" y2="-3.7846" width="0.127" layer="51"/>
<wire x1="-4.1402" y1="-3.7846" x2="-4.318" y2="-3.9116" width="0.127" layer="51"/>
<wire x1="-4.318" y1="-3.6576" x2="-4.1402" y2="-3.7846" width="0.127" layer="51"/>
<text x="-4.064" y="-3.302" size="0.254" layer="51" rot="R180">PAD</text>
<wire x1="-0.7366" y1="1.27" x2="-3.81" y2="1.27" width="0.381" layer="1"/>
<wire x1="3.81" y1="1.2446" x2="0.7366" y2="1.2446" width="0.381" layer="1"/>
<wire x1="3.81" y1="-1.27" x2="0.7366" y2="-1.27" width="0.381" layer="1"/>
<wire x1="-3.81" y1="-1.2446" x2="-0.7366" y2="-1.2446" width="0.381" layer="1"/>
</package>
<package name="FIDUCIAL_1.5MM_SQ">
<rectangle x1="-0.635" y1="-0.635" x2="0.635" y2="0.635" layer="29"/>
<smd name="P$1" x="0" y="0" dx="0.762" dy="0.762" layer="1" stop="no" thermals="no" cream="no"/>
<rectangle x1="-0.635" y1="-0.635" x2="0.635" y2="0.635" layer="41"/>
</package>
</packages>
<symbols>
<symbol name="ATMEGA168">
<wire x1="-17.78" y1="27.94" x2="20.32" y2="27.94" width="0.254" layer="94"/>
<wire x1="20.32" y1="27.94" x2="20.32" y2="-35.56" width="0.254" layer="94"/>
<wire x1="20.32" y1="-35.56" x2="-17.78" y2="-35.56" width="0.254" layer="94"/>
<wire x1="-17.78" y1="-35.56" x2="-17.78" y2="27.94" width="0.254" layer="94"/>
<text x="-17.78" y="-38.1" size="1.778" layer="95">&gt;NAME</text>
<text x="-17.78" y="28.448" size="1.778" layer="96">&gt;VALUE</text>
<pin name="PB5(SCK)" x="25.4" y="-33.02" length="middle" rot="R180"/>
<pin name="PB7(XTAL2/TOSC2)" x="-22.86" y="-5.08" length="middle"/>
<pin name="PB6(XTAL1/TOSC1)" x="-22.86" y="0" length="middle"/>
<pin name="GND@1" x="-22.86" y="-27.94" length="middle"/>
<pin name="GND@2" x="-22.86" y="-30.48" length="middle"/>
<pin name="VCC@1" x="-22.86" y="17.78" length="middle"/>
<pin name="VCC@2" x="-22.86" y="15.24" length="middle"/>
<pin name="AGND" x="-22.86" y="-25.4" length="middle"/>
<pin name="AREF" x="-22.86" y="10.16" length="middle"/>
<pin name="AVCC" x="-22.86" y="20.32" length="middle"/>
<pin name="PB4(MISO)" x="25.4" y="-30.48" length="middle" rot="R180"/>
<pin name="PB3(MOSI/OC2)" x="25.4" y="-27.94" length="middle" rot="R180"/>
<pin name="PB2(SS/OC1B)" x="25.4" y="-25.4" length="middle" rot="R180"/>
<pin name="PB1(OC1A)" x="25.4" y="-22.86" length="middle" rot="R180"/>
<pin name="PB0(ICP)" x="25.4" y="-20.32" length="middle" rot="R180"/>
<pin name="PD7(AIN1)" x="25.4" y="-15.24" length="middle" rot="R180"/>
<pin name="PD6(AIN0)" x="25.4" y="-12.7" length="middle" rot="R180"/>
<pin name="PD5(T1)" x="25.4" y="-10.16" length="middle" rot="R180"/>
<pin name="PD4(XCK/T0)" x="25.4" y="-7.62" length="middle" rot="R180"/>
<pin name="PD3(INT1)" x="25.4" y="-5.08" length="middle" rot="R180"/>
<pin name="PD2(INT0)" x="25.4" y="-2.54" length="middle" rot="R180"/>
<pin name="PD1(TXD)" x="25.4" y="0" length="middle" rot="R180"/>
<pin name="PD0(RXD)" x="25.4" y="2.54" length="middle" rot="R180"/>
<pin name="ADC7" x="25.4" y="7.62" length="middle" rot="R180"/>
<pin name="ADC6" x="25.4" y="10.16" length="middle" rot="R180"/>
<pin name="PC5(ADC5/SCL)" x="25.4" y="12.7" length="middle" rot="R180"/>
<pin name="PC4(ADC4/SDA)" x="25.4" y="15.24" length="middle" rot="R180"/>
<pin name="PC3(ADC3)" x="25.4" y="17.78" length="middle" rot="R180"/>
<pin name="PC2(ADC2)" x="25.4" y="20.32" length="middle" rot="R180"/>
<pin name="PC1(ADC1)" x="25.4" y="22.86" length="middle" rot="R180"/>
<pin name="PC0(ADC0)" x="25.4" y="25.4" length="middle" rot="R180"/>
<pin name="PC6(/RESET)" x="-22.86" y="25.4" length="middle" function="dot"/>
</symbol>
<symbol name="CAP">
<wire x1="0" y1="2.54" x2="0" y2="2.032" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="0.508" width="0.1524" layer="94"/>
<text x="1.524" y="2.921" size="1.778" layer="95">&gt;NAME</text>
<text x="1.524" y="-2.159" size="1.778" layer="96">&gt;VALUE</text>
<rectangle x1="-2.032" y1="0.508" x2="2.032" y2="1.016" layer="94"/>
<rectangle x1="-2.032" y1="1.524" x2="2.032" y2="2.032" layer="94"/>
<pin name="1" x="0" y="5.08" visible="off" length="short" direction="pas" swaplevel="1" rot="R270"/>
<pin name="2" x="0" y="-2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="RESISTOR">
<wire x1="-2.54" y1="0" x2="-2.159" y2="1.016" width="0.1524" layer="94"/>
<wire x1="-2.159" y1="1.016" x2="-1.524" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="-1.524" y1="-1.016" x2="-0.889" y2="1.016" width="0.1524" layer="94"/>
<wire x1="-0.889" y1="1.016" x2="-0.254" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="-0.254" y1="-1.016" x2="0.381" y2="1.016" width="0.1524" layer="94"/>
<wire x1="0.381" y1="1.016" x2="1.016" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="1.016" y1="-1.016" x2="1.651" y2="1.016" width="0.1524" layer="94"/>
<wire x1="1.651" y1="1.016" x2="2.286" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="2.286" y1="-1.016" x2="2.54" y2="0" width="0.1524" layer="94"/>
<text x="-3.81" y="1.4986" size="1.778" layer="95">&gt;NAME</text>
<text x="-3.81" y="-3.302" size="1.778" layer="96">&gt;VALUE</text>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="RESONATOR">
<wire x1="1.016" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.016" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.381" y1="1.524" x2="-0.381" y2="-1.524" width="0.1524" layer="94"/>
<wire x1="-0.381" y1="-1.524" x2="0.381" y2="-1.524" width="0.1524" layer="94"/>
<wire x1="0.381" y1="-1.524" x2="0.381" y2="1.524" width="0.1524" layer="94"/>
<wire x1="0.381" y1="1.524" x2="-0.381" y2="1.524" width="0.1524" layer="94"/>
<wire x1="1.016" y1="1.778" x2="1.016" y2="0" width="0.1524" layer="94"/>
<wire x1="1.016" y1="0" x2="1.016" y2="-1.778" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="1.778" x2="-1.016" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.016" y1="0" x2="-1.016" y2="-1.778" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="3.302" y1="-2.032" x2="2.54" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-2.032" x2="1.778" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="3.302" y1="-3.048" x2="2.54" y2="-3.048" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-3.048" x2="1.778" y2="-3.048" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-3.048" x2="2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="-1.778" y1="-3.048" x2="-2.54" y2="-3.048" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-3.048" x2="-3.302" y2="-3.048" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-3.048" x2="-2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="-1.778" y1="-2.032" x2="-2.54" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-2.032" x2="-3.302" y2="-2.032" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="-2.032" x2="-2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-5.08" x2="0" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="0" y1="-5.08" x2="-2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="0" y1="-5.08" x2="0" y2="-7.62" width="0.1524" layer="94"/>
<text x="2.54" y="1.016" size="1.778" layer="95">&gt;NAME</text>
<text x="2.54" y="-7.62" size="1.778" layer="96">&gt;VALUE</text>
<pin name="XTAL3_OUT" x="2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1" rot="R180"/>
<pin name="XTAL1_IN" x="-2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1"/>
<pin name="XTAL2_GND" x="0" y="-7.62" visible="off" length="point" direction="pas" swaplevel="1" rot="R90"/>
<text x="-4.064" y="-0.762" size="0.762" layer="94" font="vector" ratio="15">IN</text>
<text x="3.048" y="-0.762" size="0.762" layer="94" font="vector" ratio="15">OUT</text>
</symbol>
<symbol name="MOSFET-NCHANNEL">
<wire x1="-3.6576" y1="2.413" x2="-3.6576" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="1.905" x2="-2.0066" y2="1.905" width="0.1524" layer="94"/>
<wire x1="-2.032" y1="-1.905" x2="0" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="-1.905" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="2.032" y1="1.905" x2="2.032" y2="0.762" width="0.1524" layer="94"/>
<wire x1="2.032" y1="0.762" x2="2.032" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="2.032" y1="0.762" x2="1.397" y2="-0.635" width="0.1524" layer="94"/>
<wire x1="1.397" y1="-0.635" x2="2.667" y2="-0.635" width="0.1524" layer="94"/>
<wire x1="2.667" y1="-0.635" x2="2.032" y2="0.762" width="0.1524" layer="94"/>
<wire x1="1.397" y1="0.762" x2="2.032" y2="0.762" width="0.1524" layer="94"/>
<wire x1="2.032" y1="0.762" x2="2.667" y2="0.762" width="0.1524" layer="94"/>
<wire x1="2.667" y1="0.762" x2="2.921" y2="1.016" width="0.1524" layer="94"/>
<wire x1="1.397" y1="0.762" x2="1.143" y2="0.508" width="0.1524" layer="94"/>
<wire x1="-2.032" y1="0" x2="-0.762" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="-0.508" x2="-0.762" y2="0.508" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="0.508" x2="-2.032" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.889" y1="0" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.889" y1="0.254" x2="-1.778" y2="0" width="0.3048" layer="94"/>
<wire x1="-1.778" y1="0" x2="-0.889" y2="-0.254" width="0.3048" layer="94"/>
<wire x1="-0.889" y1="-0.254" x2="-0.889" y2="0" width="0.3048" layer="94"/>
<wire x1="-0.889" y1="0" x2="-1.143" y2="0" width="0.3048" layer="94"/>
<wire x1="-3.81" y1="0" x2="-5.08" y2="0" width="0.1524" layer="94"/>
<circle x="0" y="-1.905" radius="0.127" width="0.4064" layer="94"/>
<circle x="0" y="1.905" radius="0.127" width="0.4064" layer="94"/>
<text x="5.08" y="2.54" size="1.778" layer="95">&gt;NAME</text>
<text x="5.08" y="0" size="1.778" layer="96">&gt;VALUE</text>
<text x="-1.27" y="2.54" size="0.8128" layer="94">D</text>
<text x="-1.27" y="-3.556" size="0.8128" layer="94">S</text>
<text x="-5.08" y="-1.27" size="0.8128" layer="94">G</text>
<rectangle x1="-2.794" y1="-2.54" x2="-2.032" y2="-1.27" layer="94"/>
<rectangle x1="-2.794" y1="1.27" x2="-2.032" y2="2.54" layer="94"/>
<rectangle x1="-2.794" y1="-0.889" x2="-2.032" y2="0.889" layer="94"/>
<pin name="G" x="-7.62" y="0" visible="off" length="short" direction="pas"/>
<pin name="D" x="0" y="5.08" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="S" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
<wire x1="0" y1="-1.905" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="0" y1="-1.905" x2="2.032" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="1.905" x2="2.032" y2="1.905" width="0.1524" layer="94"/>
</symbol>
<symbol name="FIDUCIAL">
<pin name="FIDUCIAL" x="0" y="0" visible="off" length="point"/>
<circle x="0" y="0" radius="3.5921" width="0.254" layer="94"/>
</symbol>
<symbol name="LED-TRICOLOR-WS28X1">
<description>&lt;h3&gt;WS28X1 RGB LED - I2C Control&lt;/h3&gt;
&lt;p&gt;4 pin RGB LED with I2C Controller built-in&lt;/p&gt;</description>
<wire x1="10.16" y1="7.62" x2="10.16" y2="-5.08" width="0.254" layer="94"/>
<wire x1="10.16" y1="-5.08" x2="2.54" y2="-5.08" width="0.254" layer="94"/>
<wire x1="2.54" y1="-5.08" x2="-2.54" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-5.08" x2="-5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-5.08" y1="-5.08" x2="-12.7" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-12.7" y1="-5.08" x2="-12.7" y2="7.62" width="0.254" layer="94"/>
<wire x1="-12.7" y1="7.62" x2="-5.08" y2="7.62" width="0.254" layer="94"/>
<wire x1="-5.08" y1="7.62" x2="-2.54" y2="7.62" width="0.254" layer="94"/>
<wire x1="-2.54" y1="7.62" x2="2.54" y2="7.62" width="0.254" layer="94"/>
<wire x1="2.54" y1="7.62" x2="10.16" y2="7.62" width="0.254" layer="94"/>
<wire x1="-0.508" y1="1.27" x2="-0.508" y2="0" width="0.254" layer="94"/>
<wire x1="-0.508" y1="0" x2="-0.508" y2="-1.27" width="0.254" layer="94"/>
<wire x1="-0.508" y1="-1.27" x2="0.762" y2="0" width="0.254" layer="94"/>
<wire x1="0.762" y1="0" x2="-0.508" y2="1.27" width="0.254" layer="94"/>
<wire x1="0.762" y1="1.27" x2="0.762" y2="0" width="0.254" layer="94"/>
<wire x1="0.762" y1="0" x2="0.762" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0.762" y1="0" x2="2.032" y2="0" width="0.254" layer="94"/>
<wire x1="-0.508" y1="0" x2="-1.778" y2="0" width="0.254" layer="94"/>
<wire x1="-0.508" y1="-1.778" x2="-0.508" y2="-3.048" width="0.254" layer="94"/>
<wire x1="-0.508" y1="-3.048" x2="-0.508" y2="-4.318" width="0.254" layer="94"/>
<wire x1="-0.508" y1="-4.318" x2="0.762" y2="-3.048" width="0.254" layer="94"/>
<wire x1="0.762" y1="-3.048" x2="-0.508" y2="-1.778" width="0.254" layer="94"/>
<wire x1="0.762" y1="-1.778" x2="0.762" y2="-3.048" width="0.254" layer="94"/>
<wire x1="0.762" y1="-3.048" x2="0.762" y2="-4.318" width="0.254" layer="94"/>
<wire x1="0.762" y1="-3.048" x2="2.032" y2="-3.048" width="0.254" layer="94"/>
<wire x1="-0.508" y1="-3.048" x2="-1.778" y2="-3.048" width="0.254" layer="94"/>
<wire x1="-0.508" y1="4.318" x2="-0.508" y2="3.048" width="0.254" layer="94"/>
<wire x1="-0.508" y1="3.048" x2="-0.508" y2="1.778" width="0.254" layer="94"/>
<wire x1="-0.508" y1="1.778" x2="0.762" y2="3.048" width="0.254" layer="94"/>
<wire x1="0.762" y1="3.048" x2="-0.508" y2="4.318" width="0.254" layer="94"/>
<wire x1="0.762" y1="4.318" x2="0.762" y2="3.048" width="0.254" layer="94"/>
<wire x1="0.762" y1="3.048" x2="0.762" y2="1.778" width="0.254" layer="94"/>
<wire x1="0.762" y1="3.048" x2="2.032" y2="3.048" width="0.254" layer="94"/>
<wire x1="-0.508" y1="3.048" x2="-1.778" y2="3.048" width="0.254" layer="94"/>
<pin name="VDD" x="-15.24" y="5.08" visible="pin" length="short"/>
<pin name="VSS" x="12.7" y="5.08" visible="pin" length="short" rot="R180"/>
<pin name="DI" x="-15.24" y="-2.54" visible="pin" length="short"/>
<pin name="DO" x="12.7" y="-2.54" visible="pin" length="short" rot="R180"/>
<text x="-2.54" y="8.382" size="1.778" layer="95" font="vector" align="bottom-center">&gt;NAME</text>
<text x="-2.54" y="-7.62" size="1.778" layer="95" font="vector" align="bottom-center">&gt;VALUE</text>
<wire x1="-2.54" y1="7.62" x2="-2.54" y2="-5.08" width="0.254" layer="94" style="shortdash"/>
<wire x1="2.54" y1="7.62" x2="2.54" y2="-5.08" width="0.254" layer="94" style="shortdash"/>
<text x="-1.524" y="5.5118" size="1.27" layer="94">RGB</text>
<text x="-3.175" y="-2.159" size="1.27" layer="94" rot="R90">WS28x1</text>
<wire x1="-5.08" y1="7.62" x2="-5.08" y2="-5.08" width="0.254" layer="94" style="shortdash"/>
</symbol>
<symbol name="MOSFET-PCHANNEL">
<wire x1="-3.6576" y1="2.413" x2="-3.6576" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0" y1="1.905" x2="-2.0066" y2="1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="-2.032" y1="-1.905" x2="0" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="2.54" x2="0" y2="1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="1.905" x2="2.54" y2="1.905" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-1.905" x2="0" y2="-1.905" width="0.1524" layer="94"/>
<wire x1="0" y1="-1.905" x2="0" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-1.905" x2="2.54" y2="-0.762" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-0.762" x2="2.54" y2="1.905" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-0.762" x2="3.175" y2="0.635" width="0.1524" layer="94"/>
<wire x1="3.175" y1="0.635" x2="1.905" y2="0.635" width="0.1524" layer="94"/>
<wire x1="1.905" y1="0.635" x2="2.54" y2="-0.762" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-0.762" x2="2.54" y2="-0.762" width="0.1524" layer="94"/>
<wire x1="2.54" y1="-0.762" x2="1.905" y2="-0.762" width="0.1524" layer="94"/>
<wire x1="1.905" y1="-0.762" x2="1.651" y2="-1.016" width="0.1524" layer="94"/>
<wire x1="3.175" y1="-0.762" x2="3.429" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="-1.27" y2="0.508" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0.508" x2="-1.27" y2="-0.508" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="-0.508" x2="0" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.143" y1="0" x2="-2.032" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.143" y1="-0.254" x2="-0.254" y2="0" width="0.3048" layer="94"/>
<wire x1="-0.254" y1="0" x2="-1.143" y2="0.254" width="0.3048" layer="94"/>
<wire x1="-1.143" y1="0.254" x2="-1.143" y2="0" width="0.3048" layer="94"/>
<wire x1="-1.143" y1="0" x2="-0.889" y2="0" width="0.3048" layer="94"/>
<wire x1="-3.81" y1="0" x2="-5.08" y2="0" width="0.1524" layer="94"/>
<circle x="0" y="-1.905" radius="0.127" width="0.4064" layer="94"/>
<circle x="0" y="1.905" radius="0.127" width="0.4064" layer="94"/>
<text x="5.08" y="2.54" size="1.778" layer="95">&gt;NAME</text>
<text x="5.08" y="0" size="1.778" layer="96">&gt;VALUE</text>
<text x="0.254" y="2.286" size="0.508" layer="94">D</text>
<text x="0.254" y="-2.794" size="0.508" layer="94">S</text>
<text x="-4.572" y="0.254" size="0.508" layer="94">G</text>
<rectangle x1="-2.794" y1="-2.54" x2="-2.032" y2="-1.27" layer="94"/>
<rectangle x1="-2.794" y1="1.27" x2="-2.032" y2="2.54" layer="94"/>
<rectangle x1="-2.794" y1="-0.889" x2="-2.032" y2="0.889" layer="94"/>
<pin name="G" x="-7.62" y="0" visible="off" length="short" direction="pas"/>
<pin name="D" x="0" y="5.08" visible="off" length="short" direction="pas" rot="R270"/>
<pin name="S" x="0" y="-5.08" visible="off" length="short" direction="pas" rot="R90"/>
</symbol>
<symbol name="RFM12B_ANTENNA">
<circle x="0" y="0" radius="2.54" width="0.254" layer="94"/>
<pin name="1" x="-5.08" y="0" visible="off" length="middle"/>
</symbol>
<symbol name="RFM95_WITHRST">
<wire x1="-10.16" y1="12.7" x2="10.16" y2="12.7" width="0.254" layer="94"/>
<wire x1="10.16" y1="12.7" x2="10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="10.16" y1="-10.16" x2="-10.16" y2="-10.16" width="0.254" layer="94"/>
<wire x1="-10.16" y1="-10.16" x2="-10.16" y2="12.7" width="0.254" layer="94"/>
<text x="-7.62" y="0" size="1.778" layer="94">RFM95_LMIC</text>
<pin name="SEL" x="-12.7" y="7.62" visible="pad" length="short" direction="in"/>
<pin name="SCK" x="-12.7" y="5.08" visible="pad" length="short" direction="in"/>
<pin name="MISO" x="-12.7" y="2.54" visible="pad" length="short" direction="in"/>
<pin name="MOSI" x="-12.7" y="0" visible="pad" length="short" direction="out"/>
<pin name="ANT" x="12.7" y="2.54" visible="pad" length="short" direction="pas" rot="R180"/>
<pin name="VCC" x="0" y="15.24" length="short" direction="pwr" rot="R270"/>
<pin name="GND" x="0" y="-12.7" length="short" direction="pwr" rot="R90"/>
<pin name="DIO0" x="-12.7" y="-5.08" visible="pad" length="short" direction="oc"/>
<pin name="GND1" x="2.54" y="-12.7" length="short" direction="pwr" rot="R90"/>
<pin name="GND2" x="5.08" y="-12.7" length="short" direction="pwr" rot="R90"/>
<pin name="RST" x="-12.7" y="10.16" visible="pad" length="short" direction="pas"/>
</symbol>
<symbol name="PAD_1">
<pin name="P$1" x="-2.54" y="0" visible="off" length="short"/>
<wire x1="0" y1="1.27" x2="0" y2="-1.27" width="0.254" layer="94"/>
<wire x1="0" y1="-1.27" x2="2.54" y2="-1.27" width="0.254" layer="94"/>
<wire x1="2.54" y1="-1.27" x2="2.54" y2="1.27" width="0.254" layer="94"/>
<wire x1="2.54" y1="1.27" x2="0" y2="1.27" width="0.254" layer="94"/>
<text x="-5.08" y="2.54" size="1.778" layer="95">&gt;NAME</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="ATMEGA168/328" prefix="U">
<description>Atmel 32-pin 8-bit micro, 16k flash.</description>
<gates>
<gate name="G$1" symbol="ATMEGA168" x="0" y="0"/>
</gates>
<devices>
<device name="MLF" package="MLF32">
<connects>
<connect gate="G$1" pin="ADC6" pad="19"/>
<connect gate="G$1" pin="ADC7" pad="22"/>
<connect gate="G$1" pin="AGND" pad="21"/>
<connect gate="G$1" pin="AREF" pad="20"/>
<connect gate="G$1" pin="AVCC" pad="18"/>
<connect gate="G$1" pin="GND@1" pad="3"/>
<connect gate="G$1" pin="GND@2" pad="5"/>
<connect gate="G$1" pin="PB0(ICP)" pad="12"/>
<connect gate="G$1" pin="PB1(OC1A)" pad="13"/>
<connect gate="G$1" pin="PB2(SS/OC1B)" pad="14"/>
<connect gate="G$1" pin="PB3(MOSI/OC2)" pad="15"/>
<connect gate="G$1" pin="PB4(MISO)" pad="16"/>
<connect gate="G$1" pin="PB5(SCK)" pad="17"/>
<connect gate="G$1" pin="PB6(XTAL1/TOSC1)" pad="7"/>
<connect gate="G$1" pin="PB7(XTAL2/TOSC2)" pad="8"/>
<connect gate="G$1" pin="PC0(ADC0)" pad="23"/>
<connect gate="G$1" pin="PC1(ADC1)" pad="24"/>
<connect gate="G$1" pin="PC2(ADC2)" pad="25"/>
<connect gate="G$1" pin="PC3(ADC3)" pad="26"/>
<connect gate="G$1" pin="PC4(ADC4/SDA)" pad="27"/>
<connect gate="G$1" pin="PC5(ADC5/SCL)" pad="28"/>
<connect gate="G$1" pin="PC6(/RESET)" pad="29"/>
<connect gate="G$1" pin="PD0(RXD)" pad="30"/>
<connect gate="G$1" pin="PD1(TXD)" pad="31"/>
<connect gate="G$1" pin="PD2(INT0)" pad="32"/>
<connect gate="G$1" pin="PD3(INT1)" pad="1"/>
<connect gate="G$1" pin="PD4(XCK/T0)" pad="2"/>
<connect gate="G$1" pin="PD5(T1)" pad="9"/>
<connect gate="G$1" pin="PD6(AIN0)" pad="10"/>
<connect gate="G$1" pin="PD7(AIN1)" pad="11"/>
<connect gate="G$1" pin="VCC@1" pad="4"/>
<connect gate="G$1" pin="VCC@2" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TQFP32" package="TQFP32-08">
<connects>
<connect gate="G$1" pin="ADC6" pad="19"/>
<connect gate="G$1" pin="ADC7" pad="22"/>
<connect gate="G$1" pin="AGND" pad="5"/>
<connect gate="G$1" pin="AREF" pad="20"/>
<connect gate="G$1" pin="AVCC" pad="18"/>
<connect gate="G$1" pin="GND@1" pad="3"/>
<connect gate="G$1" pin="GND@2" pad="21"/>
<connect gate="G$1" pin="PB0(ICP)" pad="12"/>
<connect gate="G$1" pin="PB1(OC1A)" pad="13"/>
<connect gate="G$1" pin="PB2(SS/OC1B)" pad="14"/>
<connect gate="G$1" pin="PB3(MOSI/OC2)" pad="15"/>
<connect gate="G$1" pin="PB4(MISO)" pad="16"/>
<connect gate="G$1" pin="PB5(SCK)" pad="17"/>
<connect gate="G$1" pin="PB6(XTAL1/TOSC1)" pad="7"/>
<connect gate="G$1" pin="PB7(XTAL2/TOSC2)" pad="8"/>
<connect gate="G$1" pin="PC0(ADC0)" pad="23"/>
<connect gate="G$1" pin="PC1(ADC1)" pad="24"/>
<connect gate="G$1" pin="PC2(ADC2)" pad="25"/>
<connect gate="G$1" pin="PC3(ADC3)" pad="26"/>
<connect gate="G$1" pin="PC4(ADC4/SDA)" pad="27"/>
<connect gate="G$1" pin="PC5(ADC5/SCL)" pad="28"/>
<connect gate="G$1" pin="PC6(/RESET)" pad="29"/>
<connect gate="G$1" pin="PD0(RXD)" pad="30"/>
<connect gate="G$1" pin="PD1(TXD)" pad="31"/>
<connect gate="G$1" pin="PD2(INT0)" pad="32"/>
<connect gate="G$1" pin="PD3(INT1)" pad="1"/>
<connect gate="G$1" pin="PD4(XCK/T0)" pad="2"/>
<connect gate="G$1" pin="PD5(T1)" pad="9"/>
<connect gate="G$1" pin="PD6(AIN0)" pad="10"/>
<connect gate="G$1" pin="PD7(AIN1)" pad="11"/>
<connect gate="G$1" pin="VCC@1" pad="4"/>
<connect gate="G$1" pin="VCC@2" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="MLF_RECTPADS" package="MLF32_RECTPADS">
<connects>
<connect gate="G$1" pin="ADC6" pad="19"/>
<connect gate="G$1" pin="ADC7" pad="22"/>
<connect gate="G$1" pin="AGND" pad="21"/>
<connect gate="G$1" pin="AREF" pad="20"/>
<connect gate="G$1" pin="AVCC" pad="18"/>
<connect gate="G$1" pin="GND@1" pad="3"/>
<connect gate="G$1" pin="GND@2" pad="5"/>
<connect gate="G$1" pin="PB0(ICP)" pad="12"/>
<connect gate="G$1" pin="PB1(OC1A)" pad="13"/>
<connect gate="G$1" pin="PB2(SS/OC1B)" pad="14"/>
<connect gate="G$1" pin="PB3(MOSI/OC2)" pad="15"/>
<connect gate="G$1" pin="PB4(MISO)" pad="16"/>
<connect gate="G$1" pin="PB5(SCK)" pad="17"/>
<connect gate="G$1" pin="PB6(XTAL1/TOSC1)" pad="7"/>
<connect gate="G$1" pin="PB7(XTAL2/TOSC2)" pad="8"/>
<connect gate="G$1" pin="PC0(ADC0)" pad="23"/>
<connect gate="G$1" pin="PC1(ADC1)" pad="24"/>
<connect gate="G$1" pin="PC2(ADC2)" pad="25"/>
<connect gate="G$1" pin="PC3(ADC3)" pad="26"/>
<connect gate="G$1" pin="PC4(ADC4/SDA)" pad="27"/>
<connect gate="G$1" pin="PC5(ADC5/SCL)" pad="28"/>
<connect gate="G$1" pin="PC6(/RESET)" pad="29"/>
<connect gate="G$1" pin="PD0(RXD)" pad="30"/>
<connect gate="G$1" pin="PD1(TXD)" pad="31"/>
<connect gate="G$1" pin="PD2(INT0)" pad="32"/>
<connect gate="G$1" pin="PD3(INT1)" pad="1"/>
<connect gate="G$1" pin="PD4(XCK/T0)" pad="2"/>
<connect gate="G$1" pin="PD5(T1)" pad="9"/>
<connect gate="G$1" pin="PD6(AIN0)" pad="10"/>
<connect gate="G$1" pin="PD7(AIN1)" pad="11"/>
<connect gate="G$1" pin="VCC@1" pad="4"/>
<connect gate="G$1" pin="VCC@2" pad="6"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CAP" prefix="C" uservalue="yes">
<description>&lt;b&gt;Capacitor&lt;/b&gt;
Standard 0603 ceramic capacitor, and 0.1" leaded capacitor.</description>
<gates>
<gate name="G$1" symbol="CAP" x="0" y="0"/>
</gates>
<devices>
<device name="PTH" package="CAP-PTH-SMALL">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH2" package="CAP-PTH-SMALL2">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805" package="0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH3" package="CAP-PTH-LARGE">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SMD" package="GRM43D">
<connects>
<connect gate="G$1" pin="1" pad="A"/>
<connect gate="G$1" pin="2" pad="C"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0603-CAP" package="0603-CAP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0402-CAP" package="0402-CAP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH1" package="CAP-PTH-5MM">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="_" package="AXIAL-5MM">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1210" package="1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1206" package="1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="ASMD" package="CTZ3">
<connects>
<connect gate="G$1" pin="1" pad="+"/>
<connect gate="G$1" pin="2" pad="-"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="KIT" package="CAP-PTH-SMALL-KIT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805-CAP" package="0805-CAP">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805-CAP-LARGEPADS" package="0805-CAP-LARGEPADS">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RESISTOR" prefix="R" uservalue="yes">
<description>&lt;b&gt;Resistor&lt;/b&gt;
Basic schematic elements and footprints for 0603, 1206, and PTH resistors.</description>
<gates>
<gate name="G$1" symbol="RESISTOR" x="0" y="0"/>
</gates>
<devices>
<device name="1206" package="1206">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="AXIAL-0.3" package="AXIAL-0.3">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="2010" package="R2010">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805" package="0805">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0603-RES" package="0603-RES">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0402-RES" package="0402-RES">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH-1/6W" package="1/6W-RES">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="2512" package="R2512">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH-1/4W" package="AXIAL-0.4">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH-1/2W" package="AXIAL-0.5">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH-1W" package="AXIAL-0.6">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH-2W" package="AXIAL-0.8">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="KIT" package="AXIAL-0.3-KIT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="0805-RES" package="0805-RES">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1/4W" package="AXIAL-1/4W">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
<connect gate="G$1" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="UPRIGHT" package="RES_UPRIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1/6W-6MMSPACED" package="1/6W-RES_6MMSPACED">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="FUSE" package="FUSE_UPRIGHT">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="VARISTOR" package="VAR_RADIAL">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1210_RES" package="1210_RES">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1210" package="1210">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RESONATOR" prefix="Y">
<description>&lt;b&gt;Resonator&lt;/b&gt;
Small SMD resonator. This is the itty bitty 10/20MHz resonators with built in caps. CSTCE10M0G55 and CSTCE20M0V53. Footprint has been reviewed closely but hasn't been tested yet.</description>
<gates>
<gate name="G$1" symbol="RESONATOR" x="0" y="0"/>
</gates>
<devices>
<device name="SMD" package="RESONATOR-SMD">
<connects>
<connect gate="G$1" pin="XTAL1_IN" pad="XTAL1_IN"/>
<connect gate="G$1" pin="XTAL2_GND" pad="XTAL2_GND"/>
<connect gate="G$1" pin="XTAL3_OUT" pad="XTAL3_OUTPUT"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PTH" package="RESONATOR-PTH">
<connects>
<connect gate="G$1" pin="XTAL1_IN" pad="1"/>
<connect gate="G$1" pin="XTAL2_GND" pad="2"/>
<connect gate="G$1" pin="XTAL3_OUT" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MOSFET-NCHANNEL" prefix="Q">
<description>Generic PMOSFET</description>
<gates>
<gate name="G$1" symbol="MOSFET-NCHANNEL" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23-3">
<connects>
<connect gate="G$1" pin="D" pad="3"/>
<connect gate="G$1" pin="G" pad="1"/>
<connect gate="G$1" pin="S" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="VDFN" package="POWERPAK1212/8-POWER-VDFN">
<connects>
<connect gate="G$1" pin="D" pad="D1 D2 D3 D4"/>
<connect gate="G$1" pin="G" pad="G"/>
<connect gate="G$1" pin="S" pad="S1 S2 S3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="FIDUCIAL">
<gates>
<gate name="G$1" symbol="FIDUCIAL" x="5.08" y="0"/>
</gates>
<devices>
<device name="1.2MM" package="FIDUCIAL_MOTEINO">
<connects>
<connect gate="G$1" pin="FIDUCIAL" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1.5MM" package="FIDUCIAL_1.5MM">
<connects>
<connect gate="G$1" pin="FIDUCIAL" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1.7MM" package="FIDUCIAL_1.7MM">
<connects>
<connect gate="G$1" pin="FIDUCIAL" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SQ" package="FIDUCIAL_1.5MM_SQ">
<connects>
<connect gate="G$1" pin="FIDUCIAL" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="WS2812-2020">
<gates>
<gate name="G$1" symbol="LED-TRICOLOR-WS28X1" x="0" y="0"/>
</gates>
<devices>
<device name="2020" package="WS2812-2020">
<connects>
<connect gate="G$1" pin="DI" pad="3"/>
<connect gate="G$1" pin="DO" pad="1"/>
<connect gate="G$1" pin="VDD" pad="4"/>
<connect gate="G$1" pin="VSS" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="" package="WS2812-1515">
<connects>
<connect gate="G$1" pin="DI" pad="DIN"/>
<connect gate="G$1" pin="DO" pad="DOUT"/>
<connect gate="G$1" pin="VDD" pad="VDD"/>
<connect gate="G$1" pin="VSS" pad="GND"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="MOSFET-PCHANNEL" prefix="Q">
<description>Generic PMOSFET</description>
<gates>
<gate name="G$1" symbol="MOSFET-PCHANNEL" x="0" y="0"/>
</gates>
<devices>
<device name="SMD" package="SOT23-3">
<connects>
<connect gate="G$1" pin="D" pad="3"/>
<connect gate="G$1" pin="G" pad="1"/>
<connect gate="G$1" pin="S" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SO8" package="SO08">
<connects>
<connect gate="G$1" pin="D" pad="5"/>
<connect gate="G$1" pin="G" pad="4"/>
<connect gate="G$1" pin="S" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="POWERPAK" package="POWERPAK">
<connects>
<connect gate="G$1" pin="D" pad="5_D"/>
<connect gate="G$1" pin="G" pad="4_G"/>
<connect gate="G$1" pin="S" pad="1_S"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="SI7615ADN" package="POWERPAK1212/8-POWER-VDFN">
<connects>
<connect gate="G$1" pin="D" pad="D1 D2 D3 D4 DPAD"/>
<connect gate="G$1" pin="G" pad="G"/>
<connect gate="G$1" pin="S" pad="S1 S2 S3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RFM12B_ANTENNA">
<gates>
<gate name="G$1" symbol="RFM12B_ANTENNA" x="0" y="0"/>
</gates>
<devices>
<device name="" package="ANTENNA_THRUHOLE">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="HELICAL" package="ANTENNA_HELICAL_433MHZ">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="FAT" package="ANTENNA_THRUHOLE_FAT">
<connects>
<connect gate="G$1" pin="1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="RFM95_WITHRST">
<gates>
<gate name="G$1" symbol="RFM95_WITHRST" x="0" y="0"/>
</gates>
<devices>
<device name="" package="RFM95_LONGER_WITHRST">
<connects>
<connect gate="G$1" pin="ANT" pad="ANT"/>
<connect gate="G$1" pin="DIO0" pad="DIO0"/>
<connect gate="G$1" pin="GND" pad="GND"/>
<connect gate="G$1" pin="GND1" pad="GND1"/>
<connect gate="G$1" pin="GND2" pad="GND2"/>
<connect gate="G$1" pin="MISO" pad="MISO"/>
<connect gate="G$1" pin="MOSI" pad="MOSI"/>
<connect gate="G$1" pin="RST" pad="RST"/>
<connect gate="G$1" pin="SCK" pad="SCK"/>
<connect gate="G$1" pin="SEL" pad="NSS"/>
<connect gate="G$1" pin="VCC" pad="3.3V"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PAD_OR_PIN_1">
<gates>
<gate name="G$1" symbol="PAD_1" x="0" y="0"/>
</gates>
<devices>
<device name="PAD_SMALL" package="PAD_1">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PAD_BIG" package="PAD_1_BIG">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PIN_BIG" package="PINHEAD_1_BIG">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="PIN_OFFSET" package="PINHEAD_1_LONG">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="ANTENNA_PAD" package="ANTENNA_THRUHOLE">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="NOSILK" package="1X01NS">
<connects>
<connect gate="G$1" pin="P$1" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="THIN_NOSILK" package="1X01_THIN_NOSILK">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="1.27&quot;" package="1X1.27MMHDR">
<connects>
<connect gate="G$1" pin="P$1" pad="P$3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="MED" package="PINHEAD_1_MED">
<connects>
<connect gate="G$1" pin="P$1" pad="MINUS"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TERMINALS" package="1X01NS_TERMINALS">
<connects>
<connect gate="G$1" pin="P$1" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="RFM69" package="1X01NS_RFM69">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TOUCH" package="TOUCH_PAD">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TP" package="PAD_1_TESTPOINT">
<connects>
<connect gate="G$1" pin="P$1" pad="TP"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="THIN" package="1X01NS_THINRING">
<connects>
<connect gate="G$1" pin="P$1" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="BIG_RECT" package="PAD_1_BIG_RECT">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TOUCHSTOP" package="TOUCH_PAD_WITHSTOP">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="TOUCHSTOP2" package="TOUCH_PAD_WITHSTOP_2">
<connects>
<connect gate="G$1" pin="P$1" pad="P$1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="linear" urn="urn:adsk.eagle:library:262">
<packages>
<package name="SOT23" urn="urn:adsk.eagle:footprint:16354/1" library_version="7">
<description>&lt;b&gt;SMALL OUTLINE TRANSISTOR&lt;/b&gt;&lt;p&gt;
reflow soldering</description>
<wire x1="-1.973" y1="1.983" x2="1.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="-1.983" x2="-1.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="-1.973" y1="-1.983" x2="-1.973" y2="1.983" width="0.0508" layer="39"/>
<wire x1="1.973" y1="1.983" x2="1.973" y2="-1.983" width="0.0508" layer="39"/>
<wire x1="1.422" y1="0.66" x2="1.422" y2="-0.66" width="0.1524" layer="51"/>
<wire x1="1.422" y1="-0.66" x2="-1.422" y2="-0.66" width="0.1524" layer="51"/>
<wire x1="-1.422" y1="-0.66" x2="-1.422" y2="0.66" width="0.1524" layer="51"/>
<wire x1="-1.422" y1="0.66" x2="1.422" y2="0.66" width="0.1524" layer="51"/>
<wire x1="-1.422" y1="-0.152" x2="-1.422" y2="0.66" width="0.1524" layer="21"/>
<wire x1="-1.422" y1="0.66" x2="-0.864" y2="0.66" width="0.1524" layer="21"/>
<wire x1="0.864" y1="0.66" x2="1.422" y2="0.66" width="0.1524" layer="21"/>
<wire x1="1.422" y1="0.66" x2="1.422" y2="-0.152" width="0.1524" layer="21"/>
<smd name="3" x="0" y="1.1" dx="1" dy="1.4" layer="1"/>
<smd name="2" x="0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<smd name="1" x="-0.95" y="-1.1" dx="1" dy="1.4" layer="1"/>
<text x="-1.905" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-3.175" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-0.2286" y1="0.7112" x2="0.2286" y2="1.2954" layer="51"/>
<rectangle x1="0.7112" y1="-1.2954" x2="1.1684" y2="-0.7112" layer="51"/>
<rectangle x1="-1.1684" y1="-1.2954" x2="-0.7112" y2="-0.7112" layer="51"/>
<rectangle x1="-0.5001" y1="-0.3" x2="0.5001" y2="0.3" layer="35"/>
</package>
<package name="SOT223" urn="urn:adsk.eagle:footprint:28484/1" library_version="7">
<description>&lt;b&gt;Small Outline Transistor&lt;/b&gt;</description>
<wire x1="3.2766" y1="1.778" x2="3.2766" y2="-1.778" width="0.2032" layer="21"/>
<wire x1="3.2766" y1="-1.778" x2="-3.2766" y2="-1.778" width="0.2032" layer="21"/>
<wire x1="-3.2766" y1="-1.778" x2="-3.2766" y2="1.778" width="0.2032" layer="21"/>
<wire x1="-3.2766" y1="1.778" x2="3.2766" y2="1.778" width="0.2032" layer="21"/>
<smd name="1" x="-2.3114" y="-3.0988" dx="1.2192" dy="2.2352" layer="1"/>
<smd name="2" x="0" y="-3.0988" dx="1.2192" dy="2.2352" layer="1"/>
<smd name="3" x="2.3114" y="-3.0988" dx="1.2192" dy="2.2352" layer="1"/>
<smd name="4" x="0" y="3.099" dx="3.6" dy="2.2" layer="1"/>
<text x="1.0208" y="-4.318" size="0.8128" layer="21" ratio="12">3</text>
<text x="1.905" y="2.54" size="0.8128" layer="21" ratio="12">4</text>
<text x="-3.4526" y="-4.318" size="0.8128" layer="21" ratio="12">1</text>
<text x="-1.2906" y="-4.3274" size="0.8128" layer="21" ratio="12">2</text>
<text x="-2.54" y="0.0508" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.3208" size="1.27" layer="27">&gt;VALUE</text>
<rectangle x1="-1.6002" y1="1.8034" x2="1.6002" y2="3.6576" layer="51"/>
<rectangle x1="-0.4318" y1="-3.6576" x2="0.4318" y2="-1.8034" layer="51"/>
<rectangle x1="-2.7432" y1="-3.6576" x2="-1.8796" y2="-1.8034" layer="51"/>
<rectangle x1="1.8796" y1="-3.6576" x2="2.7432" y2="-1.8034" layer="51"/>
<rectangle x1="-1.6002" y1="1.8034" x2="1.6002" y2="3.6576" layer="51"/>
<rectangle x1="-0.4318" y1="-3.6576" x2="0.4318" y2="-1.8034" layer="51"/>
<rectangle x1="-2.7432" y1="-3.6576" x2="-1.8796" y2="-1.8034" layer="51"/>
<rectangle x1="1.8796" y1="-3.6576" x2="2.7432" y2="-1.8034" layer="51"/>
</package>
</packages>
<packages3d>
<package3d name="SOT23" urn="urn:adsk.eagle:package:16489/2" type="model" library_version="7">
<description>SMALL OUTLINE TRANSISTOR
reflow soldering</description>
<packageinstances>
<packageinstance name="SOT23"/>
</packageinstances>
</package3d>
<package3d name="SOT223" urn="urn:adsk.eagle:package:28541/2" type="model" library_version="7">
<description>Small Outline Transistor</description>
<packageinstances>
<packageinstance name="SOT223"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="78XX" urn="urn:adsk.eagle:symbol:16149/1" library_version="7">
<wire x1="-7.62" y1="-5.08" x2="7.62" y2="-5.08" width="0.4064" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="7.62" y2="2.54" width="0.4064" layer="94"/>
<wire x1="7.62" y1="2.54" x2="-7.62" y2="2.54" width="0.4064" layer="94"/>
<wire x1="-7.62" y1="2.54" x2="-7.62" y2="-5.08" width="0.4064" layer="94"/>
<text x="-7.62" y="5.715" size="1.778" layer="95">&gt;NAME</text>
<text x="-7.62" y="3.175" size="1.778" layer="96">&gt;VALUE</text>
<text x="-2.032" y="-4.318" size="1.524" layer="95">GND</text>
<pin name="VI" x="-10.16" y="0" length="short" direction="in"/>
<pin name="GND" x="0" y="-7.62" visible="pad" length="short" direction="pas" rot="R90"/>
<pin name="VO" x="10.16" y="0" length="short" direction="pas" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MCP1703" urn="urn:adsk.eagle:component:16824/5" prefix="IC" library_version="7">
<description>&lt;b&gt;250 mA, 16V, Low Quiescent Current LDO Regulator&lt;/b&gt;&lt;p&gt;
Source: http://ww1.microchip.com/downloads/en/DeviceDoc/22049b.pdf</description>
<gates>
<gate name="G$1" symbol="78XX" x="0" y="0"/>
</gates>
<devices>
<device name="DB" package="SOT223">
<connects>
<connect gate="G$1" pin="GND" pad="2"/>
<connect gate="G$1" pin="VI" pad="1"/>
<connect gate="G$1" pin="VO" pad="3"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:28541/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="3" constant="no"/>
</technology>
</technologies>
</device>
<device name="CB" package="SOT23">
<connects>
<connect gate="G$1" pin="GND" pad="1"/>
<connect gate="G$1" pin="VI" pad="3"/>
<connect gate="G$1" pin="VO" pad="2"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:16489/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="POPULARITY" value="19" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="microbuilder">
<description>&lt;h2&gt;&lt;b&gt;microBuilder.eu&lt;/b&gt; Eagle Footprint Library&lt;/h2&gt;

&lt;p&gt;Footprints for common components used in our projects and products.  This is the same library that we use internally, and it is regularly updated.  The newest version can always be found at &lt;b&gt;www.microBuilder.eu&lt;/b&gt;.  If you find this library useful, please feel free to purchase something from our online store. Please also note that all holes are optimised for metric drill bits!&lt;/p&gt;

&lt;h3&gt;Obligatory Warning&lt;/h3&gt;
&lt;p&gt;While it probably goes without saying, there are no guarantees that the footprints or schematic symbols in this library are flawless, and we make no promises of fitness for production, prototyping or any other purpose. These libraries are provided for information puposes only, and are used at your own discretion.  While we make every effort to produce accurate footprints, and many of the items found in this library have be proven in production, we can't make any promises of suitability for a specific purpose. If you do find any errors, though, please feel free to contact us at www.microbuilder.eu to let us know about it so that we can update the library accordingly!&lt;/p&gt;

&lt;h3&gt;License&lt;/h3&gt;
&lt;p&gt;This work is placed in the public domain, and may be freely used for commercial and non-commercial work with the following conditions:&lt;/p&gt;
&lt;p&gt;THIS SOFTWARE IS PROVIDED ''AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE INSTITUTE OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
&lt;/p&gt;</description>
<packages>
<package name="LGA16_3X3MM">
<wire x1="-1.5" y1="1.5" x2="1.5" y2="1.5" width="0.0508" layer="51"/>
<wire x1="1.5" y1="1.5" x2="1.5" y2="-1.5" width="0.0508" layer="51"/>
<wire x1="1.5" y1="-1.5" x2="-1.5" y2="-1.5" width="0.0508" layer="51"/>
<wire x1="-1.5" y1="-1.5" x2="-1.5" y2="1.5" width="0.0508" layer="51"/>
<wire x1="-0.9" y1="1.7" x2="-1.7" y2="1.7" width="0.2032" layer="21"/>
<wire x1="-1.7" y1="1.7" x2="-1.7" y2="1.35" width="0.2032" layer="21"/>
<wire x1="-0.9" y1="-1.7" x2="-1.7" y2="-1.7" width="0.2032" layer="21"/>
<wire x1="-1.7" y1="-1.7" x2="-1.7" y2="-1.35" width="0.2032" layer="21"/>
<wire x1="1.7" y1="-1.35" x2="1.7" y2="-1.7" width="0.2032" layer="21"/>
<wire x1="1.7" y1="-1.7" x2="0.9" y2="-1.7" width="0.2032" layer="21"/>
<wire x1="0.9" y1="1.7" x2="1.7" y2="1.7" width="0.2032" layer="21"/>
<wire x1="1.7" y1="1.7" x2="1.7" y2="1.35" width="0.2032" layer="21"/>
<smd name="1" x="-1.45" y="1" dx="0.8" dy="0.25" layer="1"/>
<smd name="2" x="-1.45" y="0.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="3" x="-1.45" y="0" dx="0.8" dy="0.25" layer="1"/>
<smd name="4" x="-1.45" y="-0.5" dx="0.8" dy="0.25" layer="1"/>
<smd name="5" x="-1.45" y="-1" dx="0.8" dy="0.25" layer="1"/>
<smd name="6" x="-0.5" y="-1.45" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="7" x="0" y="-1.45" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="8" x="0.5" y="-1.45" dx="0.8" dy="0.25" layer="1" rot="R90"/>
<smd name="9" x="1.45" y="-1" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="10" x="1.45" y="-0.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="11" x="1.45" y="0" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="12" x="1.45" y="0.5" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="13" x="1.45" y="1" dx="0.8" dy="0.25" layer="1" rot="R180"/>
<smd name="14" x="0.5" y="1.45" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="15" x="0" y="1.45" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<smd name="16" x="-0.5" y="1.45" dx="0.8" dy="0.25" layer="1" rot="R270"/>
<text x="-1.7" y="2.1" size="0.8128" layer="25" ratio="18">&gt;NAME</text>
<text x="-1.7" y="-2.4" size="0.4064" layer="27" ratio="12">&gt;VALUE</text>
<circle x="-2.25" y="1.55" radius="0.1" width="0.4064" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="LIS3DHTR">
<pin name="VDDIO" x="-15.24" y="5.08" length="short" direction="sup"/>
<pin name="NC@1" x="-15.24" y="2.54" length="short" direction="nc"/>
<pin name="NC@2" x="-15.24" y="0" length="short" direction="nc"/>
<pin name="SCL" x="-15.24" y="-2.54" length="short"/>
<pin name="GND@1" x="-15.24" y="-5.08" length="short" direction="sup"/>
<pin name="SDA" x="-2.54" y="-15.24" length="short" rot="R90"/>
<pin name="SDO" x="0" y="-15.24" length="short" rot="R90"/>
<pin name="CS" x="2.54" y="-15.24" length="short" direction="in" rot="R90"/>
<pin name="INT2" x="15.24" y="-5.08" length="short" direction="out" rot="R180"/>
<pin name="RES(GND)" x="15.24" y="-2.54" length="short" rot="R180"/>
<pin name="INT1" x="15.24" y="0" length="short" direction="out" rot="R180"/>
<pin name="GND@2" x="15.24" y="2.54" length="short" direction="sup" rot="R180"/>
<pin name="ADC3" x="15.24" y="5.08" length="short" direction="in" rot="R180"/>
<pin name="VDD" x="2.54" y="15.24" length="short" direction="sup" rot="R270"/>
<pin name="ADC2" x="0" y="15.24" length="short" direction="in" rot="R270"/>
<pin name="ADC1" x="-2.54" y="15.24" length="short" direction="in" rot="R270"/>
<wire x1="-12.7" y1="12.7" x2="12.7" y2="12.7" width="0.254" layer="94"/>
<wire x1="12.7" y1="12.7" x2="12.7" y2="-12.7" width="0.254" layer="94"/>
<wire x1="12.7" y1="-12.7" x2="-12.7" y2="-12.7" width="0.254" layer="94"/>
<wire x1="-12.7" y1="-12.7" x2="-12.7" y2="12.7" width="0.254" layer="94"/>
<text x="-12.7" y="15.24" size="1.27" layer="95">&gt;NAME</text>
<text x="5.08" y="-15.24" size="1.27" layer="95">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="ACCEL_LIS3DHTR" prefix="U" uservalue="yes">
<description>&lt;b&gt;LIS3DHTR 3-Axis Accelerometer with I2C/SPI Interface&lt;/b&gt;

&lt;p&gt;
&lt;ul&gt;
&lt;li&gt;&lt;b&gt;VDD&lt;/b&gt;: 1.71-3.6V&lt;/li&gt;
&lt;li&gt;&lt;b&gt;VDDIO&lt;/b&gt;: 1.71-VDD+0.1V&lt;/li&gt;
&lt;li&gt;&lt;b&gt;Scale&lt;/b&gt;: +/-2g, 4g, 8g, 16g with 16--bit data output&lt;/li&gt;
&lt;li&gt;&lt;b&gt;Temp:&lt;/b&gt;: -40°C - 85°C&lt;/li&gt;
&lt;/ul&gt;
&lt;/p&gt;
&lt;p&gt;Mouser: 511-LIS3DHTR&lt;br/&gt;Digikey: 497-10613-1-ND&lt;/p&gt;</description>
<gates>
<gate name="G$1" symbol="LIS3DHTR" x="0" y="0"/>
</gates>
<devices>
<device name="" package="LGA16_3X3MM">
<connects>
<connect gate="G$1" pin="ADC1" pad="16"/>
<connect gate="G$1" pin="ADC2" pad="15"/>
<connect gate="G$1" pin="ADC3" pad="13"/>
<connect gate="G$1" pin="CS" pad="8"/>
<connect gate="G$1" pin="GND@1" pad="5"/>
<connect gate="G$1" pin="GND@2" pad="12"/>
<connect gate="G$1" pin="INT1" pad="11"/>
<connect gate="G$1" pin="INT2" pad="9"/>
<connect gate="G$1" pin="NC@1" pad="2"/>
<connect gate="G$1" pin="NC@2" pad="3"/>
<connect gate="G$1" pin="RES(GND)" pad="10"/>
<connect gate="G$1" pin="SCL" pad="4"/>
<connect gate="G$1" pin="SDA" pad="6"/>
<connect gate="G$1" pin="SDO" pad="7"/>
<connect gate="G$1" pin="VDD" pad="14"/>
<connect gate="G$1" pin="VDDIO" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SparkFun-PowerIC">
<description>&lt;h3&gt;SparkFun Electronics' preferred foot prints&lt;/h3&gt;
In this library you'll find drivers, regulators, and amplifiers.&lt;br&gt;&lt;br&gt;
We've spent an enormous amount of time creating and checking these footprints and parts, but it is the end user's responsibility to ensure correctness and suitablity for a given componet or application. If you enjoy using this library, please buy one of our products at www.sparkfun.com.
&lt;br&gt;&lt;br&gt;
&lt;b&gt;Licensing:&lt;/b&gt; Creative Commons ShareAlike 4.0 International - https://creativecommons.org/licenses/by-sa/4.0/ 
&lt;br&gt;&lt;br&gt;
You are welcome to use this library for commercial purposes. For attribution, we ask that when you begin to sell your device using our footprint, you email us with a link to the product being sold. We want bragging rights that we helped (in a very small part) to create your 8th world wonder. We would like the opportunity to feature your device on our homepage.</description>
<packages>
<package name="SOT23-5">
<description>&lt;b&gt;Small Outline Transistor&lt;/b&gt;</description>
<wire x1="1.27" y1="0.4294" x2="1.27" y2="-0.4294" width="0.2032" layer="21"/>
<wire x1="1.4" y1="-0.8" x2="-1.4" y2="-0.8" width="0.1524" layer="51"/>
<wire x1="-1.27" y1="-0.4294" x2="-1.27" y2="0.4294" width="0.2032" layer="21"/>
<wire x1="-1.4" y1="0.8" x2="1.4" y2="0.8" width="0.1524" layer="51"/>
<wire x1="-0.2684" y1="0.7088" x2="0.2684" y2="0.7088" width="0.2032" layer="21"/>
<wire x1="1.4" y1="0.8" x2="1.4" y2="-0.8" width="0.1524" layer="51"/>
<wire x1="-1.4" y1="0.8" x2="-1.4" y2="-0.8" width="0.1524" layer="51"/>
<rectangle x1="-1.2" y1="-1.5" x2="-0.7" y2="-0.85" layer="51"/>
<rectangle x1="-0.25" y1="-1.5" x2="0.25" y2="-0.85" layer="51"/>
<rectangle x1="0.7" y1="-1.5" x2="1.2" y2="-0.85" layer="51"/>
<rectangle x1="0.7" y1="0.85" x2="1.2" y2="1.5" layer="51"/>
<rectangle x1="-1.2" y1="0.85" x2="-0.7" y2="1.5" layer="51"/>
<smd name="1" x="-0.95" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="2" x="0" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="3" x="0.95" y="-1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="4" x="0.95" y="1.3001" dx="0.55" dy="1.2" layer="1"/>
<smd name="5" x="-0.95" y="1.3001" dx="0.55" dy="1.2" layer="1"/>
<text x="-0.889" y="2.159" size="0.4064" layer="25">&gt;NAME</text>
<text x="-0.9525" y="-0.1905" size="0.4064" layer="27">&gt;VALUE</text>
<circle x="-1.6002" y="-1.016" radius="0.127" width="0" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="MCP73831">
<wire x1="-7.62" y1="5.08" x2="7.62" y2="5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="5.08" x2="7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="-7.62" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-7.62" y1="-5.08" x2="-7.62" y2="5.08" width="0.254" layer="94"/>
<text x="-7.62" y="5.588" size="1.778" layer="95">&gt;Name</text>
<text x="-7.62" y="-7.62" size="1.778" layer="96">&gt;Value</text>
<pin name="VIN" x="-10.16" y="2.54" length="short" direction="pwr"/>
<pin name="STAT" x="-10.16" y="-2.54" length="short" direction="out"/>
<pin name="VBAT" x="10.16" y="2.54" length="short" direction="pwr" rot="R180"/>
<pin name="PROG" x="10.16" y="0" length="short" direction="in" rot="R180"/>
<pin name="VSS" x="10.16" y="-2.54" length="short" direction="pwr" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MCP73831" prefix="U">
<description>&lt;b&gt;Miniature single cell, fully integrated Li-Ion, Li-polymer charge management controller&lt;/b&gt;&lt;br&gt;
http://ww1.microchip.com/downloads/en/DeviceDoc/20001984g.pdf&lt;br&gt;
IC-09995</description>
<gates>
<gate name="G$1" symbol="MCP73831" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT23-5">
<connects>
<connect gate="G$1" pin="PROG" pad="5"/>
<connect gate="G$1" pin="STAT" pad="1"/>
<connect gate="G$1" pin="VBAT" pad="3"/>
<connect gate="G$1" pin="VIN" pad="4"/>
<connect gate="G$1" pin="VSS" pad="2"/>
</connects>
<technologies>
<technology name="">
<attribute name="PROD_ID" value="IC-09995"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="sparkfun_photon_temp">
<packages>
</packages>
<symbols>
<symbol name="VUSB">
<wire x1="0.762" y1="1.27" x2="0" y2="2.54" width="0.254" layer="94"/>
<wire x1="0" y1="2.54" x2="-0.762" y2="1.27" width="0.254" layer="94"/>
<text x="-1.016" y="3.556" size="1.778" layer="96">&gt;VALUE</text>
<pin name="VUSB" x="0" y="0" visible="off" length="short" direction="sup" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="VUSB" prefix="SUPPLY">
<description>&lt;b&gt;SUPPLY SYMBOL&lt;/b&gt;</description>
<gates>
<gate name="G$1" symbol="VUSB" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="M40-4010246">
<description>&lt;Headers &amp; Wire Housings 2P SIL SMT HORIZ SHROUDED TAB HEADER&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by SamacSys&lt;/author&gt;</description>
<packages>
<package name="M404010246">
<description>&lt;b&gt;M40-4010246-2&lt;/b&gt;&lt;br&gt;</description>
<wire x1="-2.15" y1="1.962" x2="2.15" y2="1.962" width="0.2" layer="51"/>
<wire x1="2.15" y1="1.962" x2="2.15" y2="-2.287" width="0.2" layer="51"/>
<wire x1="2.15" y1="-2.287" x2="-2.15" y2="-2.287" width="0.2" layer="51"/>
<wire x1="-2.15" y1="-2.287" x2="-2.15" y2="1.962" width="0.2" layer="51"/>
<wire x1="-1" y1="-2.287" x2="1" y2="-2.287" width="0.1" layer="21"/>
<wire x1="-2.15" y1="1.962" x2="-2.15" y2="0" width="0.1" layer="21"/>
<wire x1="2.15" y1="2" x2="2.15" y2="0" width="0.1" layer="21"/>
<smd name="1" x="-0.754" y="2.415" dx="1.9" dy="1.1" layer="1" rot="R90"/>
<smd name="2" x="0.754" y="2.415" dx="1.9" dy="1.1" layer="1" rot="R90"/>
<smd name="MP1" x="1.927" y="-1.841" dx="2.2" dy="1.4" layer="1" rot="R90"/>
<smd name="MP2" x="-1.927" y="-1.841" dx="2.2" dy="1.4" layer="1" rot="R90"/>
<text x="0" y="5.636" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="-4.524" size="1.27" layer="27" align="center">&gt;VALUE</text>
<circle x="-1.778" y="2.667" radius="0.254" width="0" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="M40-4010246">
<wire x1="5.08" y1="2.54" x2="17.78" y2="2.54" width="0.254" layer="94"/>
<wire x1="17.78" y1="-5.08" x2="17.78" y2="2.54" width="0.254" layer="94"/>
<wire x1="17.78" y1="-5.08" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-5.08" width="0.254" layer="94"/>
<pin name="1" x="22.86" y="0" length="middle" rot="R180"/>
<pin name="2" x="22.86" y="-2.54" length="middle" rot="R180"/>
<pin name="MP1" x="0" y="-2.54" length="middle"/>
<pin name="MP2" x="0" y="0" length="middle"/>
<text x="19.05" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="19.05" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
</symbol>
</symbols>
<devicesets>
<deviceset name="M40-4010246" prefix="J">
<description>&lt;b&gt;Headers &amp; Wire Housings 2P SIL SMT HORIZ SHROUDED TAB HEADER&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://componentsearchengine.com/Datasheets/2/M40-4010246.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="M40-4010246" x="0" y="0"/>
</gates>
<devices>
<device name="" package="M404010246">
<connects>
<connect gate="G$1" pin="1" pad="1"/>
<connect gate="G$1" pin="2" pad="2"/>
<connect gate="G$1" pin="MP1" pad="MP1"/>
<connect gate="G$1" pin="MP2" pad="MP2"/>
</connects>
<technologies>
<technology name="">
<attribute name="ARROW_PART_NUMBER" value="" constant="no"/>
<attribute name="ARROW_PRICE-STOCK" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Headers &amp; Wire Housings 2P SIL SMT HORIZ SHROUDED TAB HEADER" constant="no"/>
<attribute name="HEIGHT" value="3.15mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Harwin" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="M40-4010246" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="855-M40-4010246" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Harwin/M40-4010246?qs=%252Bk6%2F5FB6qrkoTdPFThSz5A%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="VSMY2941RGX01">
<packages>
<package name="DIO_VSMY2941RGX01">
<wire x1="-1.15" y1="1.15" x2="1.15" y2="1.15" width="0.127" layer="51"/>
<wire x1="1.15" y1="1.15" x2="1.15" y2="-1.15" width="0.127" layer="51"/>
<wire x1="1.15" y1="-1.15" x2="-1.15" y2="-1.15" width="0.127" layer="51"/>
<wire x1="-1.15" y1="-1.15" x2="-1.15" y2="1.15" width="0.127" layer="51"/>
<wire x1="-3.602" y1="1.4" x2="3.602" y2="1.4" width="0.05" layer="39"/>
<wire x1="3.602" y1="1.4" x2="3.602" y2="-1.4" width="0.05" layer="39"/>
<wire x1="3.602" y1="-1.4" x2="-3.602" y2="-1.4" width="0.05" layer="39"/>
<wire x1="-3.602" y1="-1.4" x2="-3.602" y2="1.4" width="0.05" layer="39"/>
<wire x1="-1.15" y1="0.75" x2="-1.15" y2="1.15" width="0.127" layer="21"/>
<wire x1="-1.15" y1="1.15" x2="-0.75" y2="1.15" width="0.127" layer="21"/>
<wire x1="0.75" y1="1.15" x2="1.15" y2="1.15" width="0.127" layer="21"/>
<wire x1="1.15" y1="1.15" x2="1.15" y2="0.75" width="0.127" layer="21"/>
<wire x1="1.15" y1="-0.75" x2="1.15" y2="-1.15" width="0.127" layer="21"/>
<wire x1="1.15" y1="-1.15" x2="0.75" y2="-1.15" width="0.127" layer="21"/>
<wire x1="-0.75" y1="-1.15" x2="-1.15" y2="-1.15" width="0.127" layer="21"/>
<wire x1="-1.15" y1="-1.15" x2="-1.15" y2="-0.75" width="0.127" layer="21"/>
<text x="-3.75" y="-3" size="1.27" layer="27"></text>
<text x="-3.75" y="1.75" size="1.27" layer="25"></text>
<wire x1="-1.15" y1="0" x2="1.15" y2="0" width="0" layer="46" curve="-180"/>
<wire x1="1.15" y1="0" x2="-1.15" y2="0" width="0" layer="46" curve="-180"/>
<smd name="C" x="2.5" y="0" dx="1.7" dy="0.75" layer="1"/>
<smd name="A" x="-2.5" y="0" dx="1.7" dy="0.75" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="VSMY2941RGX01">
<wire x1="-2.54" y1="1.524" x2="-2.54" y2="0" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="-1.524" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-1.524" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-2.54" y2="1.524" width="0.254" layer="94"/>
<wire x1="0" y1="1.524" x2="0" y2="-1.524" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0" x2="-5.08" y2="0" width="0.1524" layer="94"/>
<text x="-3.556" y="4.826" size="1.27" layer="95">&gt;NAME</text>
<text x="-3.556" y="-3.302" size="1.27" layer="96">&gt;VALUE</text>
<text x="1.016" y="2.032" size="1.016" layer="94">IR</text>
<wire x1="1.016" y1="4.064" x2="-0.762" y2="2.032" width="0.254" layer="94"/>
<wire x1="0.6858" y1="3.0988" x2="0.127" y2="3.5814" width="0.254" layer="94"/>
<wire x1="0.127" y1="3.5814" x2="1.016" y2="4.064" width="0.254" layer="94"/>
<wire x1="1.016" y1="4.064" x2="0.6858" y2="3.0988" width="0.254" layer="94"/>
<wire x1="0.6858" y1="3.0988" x2="0.7112" y2="3.8354" width="0.254" layer="94"/>
<wire x1="0.7112" y1="3.8354" x2="0.5842" y2="3.8354" width="0.254" layer="94"/>
<wire x1="0.3048" y1="3.5052" x2="0.5334" y2="3.6576" width="0.254" layer="94"/>
<wire x1="-0.2286" y1="4.1656" x2="-2.0066" y2="2.1336" width="0.254" layer="94"/>
<wire x1="-0.5588" y1="3.2004" x2="-1.1176" y2="3.683" width="0.254" layer="94"/>
<wire x1="-1.1176" y1="3.683" x2="-0.2286" y2="4.1656" width="0.254" layer="94"/>
<wire x1="-0.2286" y1="4.1656" x2="-0.5588" y2="3.2004" width="0.254" layer="94"/>
<wire x1="-0.5588" y1="3.2004" x2="-0.5334" y2="3.937" width="0.254" layer="94"/>
<wire x1="-0.5334" y1="3.937" x2="-0.6604" y2="3.937" width="0.254" layer="94"/>
<wire x1="-0.9398" y1="3.6068" x2="-0.7112" y2="3.7592" width="0.254" layer="94"/>
<pin name="C" x="5.08" y="0" visible="pad" length="middle" direction="pas" rot="R180"/>
<pin name="A" x="-7.62" y="0" visible="pad" length="short" direction="pas"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="VSMY2941RGX01" prefix="D">
<description>Infrared Emitters - High Power IR Emtr 940nm; 5ns 160mW/sr; rev-gwing &lt;a href="https://pricing.snapeda.com/parts/VSMY2941RGX01/Vishay%20Semiconductor/view-part?ref=eda"&gt;Check availability&lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="VSMY2941RGX01" x="0" y="0"/>
</gates>
<devices>
<device name="" package="DIO_VSMY2941RGX01">
<connects>
<connect gate="G$1" pin="A" pad="A"/>
<connect gate="G$1" pin="C" pad="C"/>
</connects>
<technologies>
<technology name="">
<attribute name="AVAILABILITY" value="In Stock"/>
<attribute name="CHECK_PRICES" value="https://www.snapeda.com/parts/VSMY2941RGX01/Vishay+Semiconductor+Opto+Division/view-part/?ref=eda"/>
<attribute name="DESCRIPTION" value=" IR Emitter: 940nm, SMD, 160mW/sr, +/-8degrees "/>
<attribute name="MF" value="Vishay Semiconductor"/>
<attribute name="MP" value="VSMY2941RGX01"/>
<attribute name="PACKAGE" value="SMD-2 Vishay Semiconductor"/>
<attribute name="PRICE" value="None"/>
<attribute name="PURCHASE-URL" value="https://www.snapeda.com/api/url_track_click_mouser/?unipart_id=3622774&amp;manufacturer=Vishay Semiconductor&amp;part_name=VSMY2941RGX01&amp;search_term=None"/>
<attribute name="SNAPEDA_LINK" value="https://www.snapeda.com/parts/VSMY2941RGX01/Vishay+Semiconductor+Opto+Division/view-part/?ref=snap"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="tag-connect">
<description>&lt;h3&gt;TAG-CONNECT ICSP Connector&lt;/h3&gt;&lt;BR&gt;&lt;I&gt;Manufacturer:&lt;/I&gt; &lt;a href="http://www.tag-connect.com"&gt;Tag-Connect&lt;/a&gt;&lt;BR&gt;
&lt;BR&gt;Cable for easy In-Circuit Serial Programming. Designed for Microchip ICD2, suitable for many others.&lt;BR&gt;
Two variants - one "with legs" (for hands-free fit on PCB) and another "without legs" for quick programming.

&lt;p&gt;
&lt;TABLE cellspacing=0 cellpadding=0 border=0&gt;
&lt;TR&gt;&lt;TD width=20&gt;&lt;/TD&gt;&lt;TD&gt;
&lt;TABLE cellspacing=0 cellpadding=1 border=1&gt;
&lt;TR bgcolor=silver&gt;&lt;TD align=center&gt;PAD&lt;/TD&gt;&lt;TD align=center&gt;Description&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;1&lt;/TD&gt;&lt;TD&gt;MCLR/Vpp&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;2&lt;/TD&gt;&lt;TD&gt;Vdd&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;3&lt;/TD&gt;&lt;TD&gt;GND&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;4&lt;/TD&gt;&lt;TD&gt;PGD (ISPDAT)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;5&lt;/TD&gt;&lt;TD&gt;PGC (ISPCLK)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;6&lt;/TD&gt;&lt;TD&gt;nc (used for LVP)&lt;/TD&gt;&lt;/TR&gt;
&lt;/TABLE&gt;
&lt;/TD&gt;&lt;/TR&gt;&lt;/TABLE&gt;&lt;BR&gt;&lt;BR&gt;

©2009 ROFA.cz - modified and updated by Robert Darlington &amp;#8249;rdarlington@gmail.com&amp;#8250;</description>
<packages>
<package name="TC2030-MCP-NL">
<description>&lt;B&gt;TAG-CONNECT ICSP Connector&lt;/B&gt;&lt;BR&gt;&lt;I&gt;Manufacturer:&lt;/I&gt; &lt;a href="www.tag-connect.com"&gt;Tag-Connect&lt;/a&gt;&lt;BR&gt;
&lt;BR&gt;Cable for easy In-Circuit Serial Programming. Designed for Microchip ICD2, suitable for many others.&lt;BR&gt;

&lt;TABLE cellspacing=0 cellpadding=0 border=0&gt;
&lt;TR&gt;&lt;TD width=20&gt;&lt;/TD&gt;&lt;TD&gt;
&lt;TABLE cellspacing=0 cellpadding=1 border=1&gt;
&lt;TR bgcolor=silver&gt;&lt;TD align=center&gt;PAD&lt;/TD&gt;&lt;TD align=center&gt;Description&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;1&lt;/TD&gt;&lt;TD&gt;MCLR/Vpp&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;2&lt;/TD&gt;&lt;TD&gt;Vdd&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;3&lt;/TD&gt;&lt;TD&gt;GND&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;4&lt;/TD&gt;&lt;TD&gt;PGD (ISPDAT)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;5&lt;/TD&gt;&lt;TD&gt;PGC (ISPCLK)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;6&lt;/TD&gt;&lt;TD&gt;nc (used for LVP)&lt;/TD&gt;&lt;/TR&gt;
&lt;/TABLE&gt;
&lt;/TD&gt;&lt;/TR&gt;&lt;/TABLE&gt;&lt;BR&gt;&lt;BR&gt;

©2009 ROFA.cz - modified and updated by Robert Darlington &amp;#8249;rdarlington@gmail.com&amp;#8250;</description>
<smd name="2" x="1.27" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="4" x="2.54" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="6" x="3.81" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="5" x="3.81" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="3" x="2.54" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="1" x="1.27" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<text x="-0.635" y="1.27" size="1.27" layer="25">&gt;name</text>
<hole x="0" y="0" drill="0.9398"/>
<hole x="5.08" y="-1.016" drill="0.9398"/>
<hole x="5.08" y="1.016" drill="0.9398"/>
<polygon width="0.0254" layer="39">
<vertex x="1.27" y="-0.2413"/>
<vertex x="1.6637" y="-0.2413"/>
<vertex x="1.6637" y="-0.635"/>
<vertex x="2.1463" y="-0.635"/>
<vertex x="2.1463" y="-0.2413"/>
<vertex x="2.9337" y="-0.2413"/>
<vertex x="2.9337" y="-0.635"/>
<vertex x="3.4163" y="-0.635"/>
<vertex x="3.4163" y="-0.2413"/>
<vertex x="3.81" y="-0.2413"/>
<vertex x="3.81" y="0.2413"/>
<vertex x="3.4163" y="0.2413"/>
<vertex x="3.4163" y="0.635"/>
<vertex x="2.9337" y="0.635"/>
<vertex x="2.9337" y="0.2413"/>
<vertex x="2.1463" y="0.2413"/>
<vertex x="2.1463" y="0.635"/>
<vertex x="1.6637" y="0.635"/>
<vertex x="1.6637" y="0.2413"/>
<vertex x="1.27" y="0.2413"/>
</polygon>
<text x="1.397" y="-1.397" size="0.2032" layer="51" rot="R90">1</text>
<text x="1.27" y="1.27" size="0.2032" layer="51" rot="R90">2</text>
<text x="2.54" y="1.27" size="0.2032" layer="51" rot="R90">4</text>
<text x="2.667" y="-1.397" size="0.2032" layer="51" rot="R90">3</text>
<text x="3.81" y="1.27" size="0.2032" layer="51" rot="R90">6</text>
<text x="3.937" y="-1.397" size="0.2032" layer="51" rot="R90">5</text>
</package>
<package name="TC2030-MCP">
<description>&lt;b&gt;TAG-CONNECT ICSP Connector&lt;/b&gt; - Legged version&lt;BR&gt;&lt;I&gt;Manufacturer:&lt;/I&gt; &lt;a href="http://www.tag-connect.com"&gt;Tag-Connect&lt;/a&gt;
&lt;p&gt;
Cable for easy In-Circuit Serial Programming. Designed for Microchip ICD2, suitable for many others.
&lt;p&gt;
&lt;b&gt;NOTE:&lt;/b&gt; Eagle's default spacing for drill holes does not leave sufficent room for routing traces for this footprint and should be adjusted. &lt;br&gt;
This setting can be found in the board layout editor under the Edit menu.  Select "Design Rules" and then the Distance tab.  8 mils for Drill/Hole works well.
&lt;br&gt;
&lt;TABLE cellspacing=0 cellpadding=0 border=0&gt;
&lt;TR&gt;&lt;TD width=20&gt;&lt;/TD&gt;&lt;TD&gt;
&lt;TABLE cellspacing=0 cellpadding=1 border=1&gt;
&lt;TR bgcolor=silver&gt;&lt;TD align=center&gt;PAD&lt;/TD&gt;&lt;TD align=center&gt;Description&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;1&lt;/TD&gt;&lt;TD&gt;MCLR/Vpp&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;2&lt;/TD&gt;&lt;TD&gt;Vdd&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;3&lt;/TD&gt;&lt;TD&gt;GND&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;4&lt;/TD&gt;&lt;TD&gt;PGD (ISPDAT)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;5&lt;/TD&gt;&lt;TD&gt;PGC (ISPCLK)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;6&lt;/TD&gt;&lt;TD&gt;nc (used for LVP)&lt;/TD&gt;&lt;/TR&gt;
&lt;/TABLE&gt;
&lt;/TD&gt;&lt;/TR&gt;&lt;/TABLE&gt;&lt;BR&gt;&lt;BR&gt;
©2009 ROFA.cz - modified and updated by Robert Darlington &amp;#8249;rdarlington@gmail.com&amp;#8250;</description>
<smd name="2" x="1.27" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="4" x="2.54" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="6" x="3.81" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="5" x="3.81" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="3" x="2.54" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="1" x="1.27" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<text x="-1.27" y="-2.54" size="1.27" layer="25" rot="R90">&gt;name</text>
<hole x="0" y="0" drill="0.889"/>
<hole x="5.08" y="-1.016" drill="0.889"/>
<hole x="5.08" y="1.016" drill="0.889"/>
<hole x="0" y="2.54" drill="2.3748"/>
<hole x="0" y="-2.54" drill="2.3748"/>
<hole x="3.175" y="-2.54" drill="2.3748"/>
<hole x="3.175" y="2.54" drill="2.3748"/>
<polygon width="0.0254" layer="39">
<vertex x="1.27" y="-0.2413"/>
<vertex x="1.6637" y="-0.2413"/>
<vertex x="1.6637" y="-0.635"/>
<vertex x="2.1463" y="-0.635"/>
<vertex x="2.1463" y="-0.2413"/>
<vertex x="2.9337" y="-0.2413"/>
<vertex x="2.9337" y="-0.635"/>
<vertex x="3.4163" y="-0.635"/>
<vertex x="3.4163" y="-0.2413"/>
<vertex x="3.81" y="-0.2413"/>
<vertex x="3.81" y="0.2413"/>
<vertex x="3.4163" y="0.2413"/>
<vertex x="3.4163" y="0.635"/>
<vertex x="2.9337" y="0.635"/>
<vertex x="2.9337" y="0.2413"/>
<vertex x="2.1463" y="0.2413"/>
<vertex x="2.1463" y="0.635"/>
<vertex x="1.6637" y="0.635"/>
<vertex x="1.6637" y="0.2413"/>
<vertex x="1.27" y="0.2413"/>
</polygon>
</package>
<package name="TC2030-MCP-NL-CP">
<description>&lt;B&gt;TAG-CONNECT ICSP Connector&lt;/B&gt;&lt;I&gt;- with optional copper pads for steel alignment pins&lt;/I&gt;&lt;BR&gt;&lt;I&gt;Manufacturer:&lt;/I&gt; &lt;a href="http://www.tag-connect.com"&gt;Tag-Connect&lt;/a&gt;&lt;BR&gt;
&lt;BR&gt;Cable for easy In-Circuit Serial Programming. Designed for Microchip ICD2, suitable for many others.
&lt;p&gt;
&lt;b&gt;NOTE:&lt;/b&gt; Eagle's default spacing for drill holes does not leave sufficent room for routing traces for this footprint and should be adjusted. &lt;br&gt;
This setting can be found in the board layout editor under the Edit menu.  Select "Design Rules" and then the Distance tab.  8 mils for Drill/Hole works well.
&lt;br&gt;
&lt;TABLE cellspacing=0 cellpadding=0 border=0&gt;
&lt;TR&gt;&lt;TD width=20&gt;&lt;/TD&gt;&lt;TD&gt;
&lt;TABLE cellspacing=0 cellpadding=1 border=1&gt;
&lt;TR bgcolor=silver&gt;&lt;TD align=center&gt;PAD&lt;/TD&gt;&lt;TD align=center&gt;Description&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;1&lt;/TD&gt;&lt;TD&gt;MCLR/Vpp&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;2&lt;/TD&gt;&lt;TD&gt;Vdd&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;3&lt;/TD&gt;&lt;TD&gt;GND&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;4&lt;/TD&gt;&lt;TD&gt;PGD (ISPDAT)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;5&lt;/TD&gt;&lt;TD&gt;PGC (ISPCLK)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;6&lt;/TD&gt;&lt;TD&gt;nc (used for LVP)&lt;/TD&gt;&lt;/TR&gt;
&lt;/TABLE&gt;
&lt;/TD&gt;&lt;/TR&gt;&lt;/TABLE&gt;&lt;BR&gt;&lt;BR&gt;

&lt;B&gt;Note:&lt;/B&gt; Suitable Receptacle pins are 0295-0-15-xx-06-xx-10-0 series from &lt;a href="www.mill-max.com"&gt;Mill-Max&lt;/a&gt;&lt;BR&gt;&lt;BR&gt;

©2009 ROFA.cz - modified and updated by Robert Darlington &amp;#8249;rdarlington@gmail.com&amp;#8250;</description>
<smd name="2" x="1.27" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="4" x="2.54" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="6" x="3.81" y="0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="5" x="3.81" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="3" x="2.54" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<smd name="1" x="1.27" y="-0.635" dx="0.7874" dy="0.7874" layer="1" roundness="100" cream="no"/>
<text x="-1.27" y="1.905" size="1.27" layer="25">&gt;name</text>
<hole x="0" y="0" drill="1.6"/>
<hole x="5.08" y="1.016" drill="1.6"/>
<hole x="5.08" y="-1.016" drill="1.6"/>
<polygon width="0.0254" layer="39">
<vertex x="1.27" y="-0.2413"/>
<vertex x="1.6637" y="-0.2413"/>
<vertex x="1.6637" y="-0.635"/>
<vertex x="2.1463" y="-0.635"/>
<vertex x="2.1463" y="-0.2413"/>
<vertex x="2.9337" y="-0.2413"/>
<vertex x="2.9337" y="-0.635"/>
<vertex x="3.4163" y="-0.635"/>
<vertex x="3.4163" y="-0.2413"/>
<vertex x="3.81" y="-0.2413"/>
<vertex x="3.81" y="0.2413"/>
<vertex x="3.4163" y="0.2413"/>
<vertex x="3.4163" y="0.635"/>
<vertex x="2.9337" y="0.635"/>
<vertex x="2.9337" y="0.2413"/>
<vertex x="2.1463" y="0.2413"/>
<vertex x="2.1463" y="0.635"/>
<vertex x="1.6637" y="0.635"/>
<vertex x="1.6637" y="0.2413"/>
<vertex x="1.27" y="0.2413"/>
</polygon>
<polygon width="0.0254" layer="16">
<vertex x="3.556" y="-1.016" curve="90"/>
<vertex x="5.08" y="-2.54" curve="90"/>
<vertex x="6.604" y="-1.016"/>
<vertex x="6.604" y="1.016" curve="90"/>
<vertex x="5.08" y="2.54" curve="90"/>
<vertex x="3.556" y="1.016"/>
</polygon>
<polygon width="0.0254" layer="16">
<vertex x="-1.524" y="0" curve="-90"/>
<vertex x="0" y="1.524" curve="-90"/>
<vertex x="1.524" y="0" curve="-90"/>
<vertex x="0" y="-1.524" curve="-90"/>
</polygon>
<polygon width="0.254" layer="30">
<vertex x="3.556" y="-1.016" curve="90"/>
<vertex x="5.08" y="-2.54" curve="90"/>
<vertex x="6.604" y="-1.016"/>
<vertex x="6.604" y="1.016" curve="90"/>
<vertex x="5.08" y="2.54" curve="90"/>
<vertex x="3.556" y="1.016"/>
</polygon>
<polygon width="0.254" layer="30">
<vertex x="-1.524" y="0" curve="-90"/>
<vertex x="0" y="1.524" curve="-90"/>
<vertex x="1.524" y="0" curve="-90"/>
<vertex x="0" y="-1.524" curve="-90"/>
</polygon>
<rectangle x1="-1.77" y1="-2.5" x2="6.73" y2="2.5" layer="40"/>
</package>
</packages>
<symbols>
<symbol name="ICSP">
<wire x1="-10.16" y1="10.16" x2="-10.16" y2="-7.62" width="0.254" layer="94"/>
<wire x1="-10.16" y1="-7.62" x2="8.89" y2="-7.62" width="0.254" layer="94"/>
<wire x1="8.89" y1="-7.62" x2="8.89" y2="10.16" width="0.254" layer="94"/>
<wire x1="8.89" y1="10.16" x2="-10.16" y2="10.16" width="0.254" layer="94"/>
<circle x="5.842" y="9.144" radius="0.5679" width="0.254" layer="94"/>
<circle x="4.826" y="3.048" radius="0.5679" width="0.254" layer="94"/>
<circle x="6.858" y="3.048" radius="0.5679" width="0.254" layer="94"/>
<pin name="VPP/MCLR" x="-12.7" y="7.62" length="short" direction="pas"/>
<pin name="VDD" x="-12.7" y="5.08" length="short" direction="pwr"/>
<pin name="VSS(GND)" x="-12.7" y="2.54" length="short" direction="pwr"/>
<pin name="ICSP_DAT/PGD" x="-12.7" y="0" length="short"/>
<pin name="ICSP_CLK/PGC" x="-12.7" y="-2.54" length="short" direction="out"/>
<pin name="LVP" x="-12.7" y="-5.08" length="short"/>
<polygon width="0.254" layer="94">
<vertex x="6.096" y="7.62" curve="-90"/>
<vertex x="6.604" y="8.128" curve="-90"/>
<vertex x="7.112" y="7.62" curve="-90"/>
<vertex x="6.604" y="7.112" curve="-90"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="4.572" y="7.62" curve="-90"/>
<vertex x="5.08" y="8.128" curve="-90"/>
<vertex x="5.588" y="7.62" curve="-90"/>
<vertex x="5.08" y="7.112" curve="-90"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="6.096" y="6.096" curve="-90"/>
<vertex x="6.604" y="6.604" curve="-90"/>
<vertex x="7.112" y="6.096" curve="-90"/>
<vertex x="6.604" y="5.588" curve="-90"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="4.572" y="6.096" curve="-90"/>
<vertex x="5.08" y="6.604" curve="-90"/>
<vertex x="5.588" y="6.096" curve="-90"/>
<vertex x="5.08" y="5.588" curve="-90"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="4.572" y="4.572" curve="-90"/>
<vertex x="5.08" y="5.08" curve="-90"/>
<vertex x="5.588" y="4.572" curve="-90"/>
<vertex x="5.08" y="4.064" curve="-90"/>
</polygon>
<polygon width="0.254" layer="94">
<vertex x="6.096" y="4.572" curve="-90"/>
<vertex x="6.604" y="5.08" curve="-90"/>
<vertex x="7.112" y="4.572" curve="-90"/>
<vertex x="6.604" y="4.064" curve="-90"/>
</polygon>
</symbol>
</symbols>
<devicesets>
<deviceset name="TC2030_ICSP" prefix="J" uservalue="yes">
<description>&lt;h3&gt;TAG-CONNECT ICSP Connector&lt;/h3&gt;&lt;BR&gt;&lt;I&gt;Manufacturer:&lt;/I&gt; &lt;a href="http://www.tag-connect.com"&gt;Tag-Connect&lt;/a&gt;&lt;BR&gt;
&lt;BR&gt;Cable for easy In-Circuit Serial Programming. Designed for Microchip ICD2, suitable for many others.&lt;BR&gt;
Two variants - one "with legs" (for hands-free fit on PCB) and another "without legs" for quick programming.

&lt;p&gt;
&lt;TABLE cellspacing=0 cellpadding=0 border=0&gt;
&lt;TR&gt;&lt;TD width=20&gt;&lt;/TD&gt;&lt;TD&gt;
&lt;TABLE cellspacing=0 cellpadding=1 border=1&gt;
&lt;TR bgcolor=silver&gt;&lt;TD align=center&gt;PAD&lt;/TD&gt;&lt;TD align=center&gt;Description&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;1&lt;/TD&gt;&lt;TD&gt;MCLR/Vpp&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;2&lt;/TD&gt;&lt;TD&gt;Vdd&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;3&lt;/TD&gt;&lt;TD&gt;GND&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;4&lt;/TD&gt;&lt;TD&gt;PGD (ISPDAT)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;5&lt;/TD&gt;&lt;TD&gt;PGC (ISPCLK)&lt;/TD&gt;&lt;/TR&gt;
&lt;TR&gt;&lt;TD align=center&gt;6&lt;/TD&gt;&lt;TD&gt;nc (used for LVP)&lt;/TD&gt;&lt;/TR&gt;
&lt;/TABLE&gt;
&lt;/TD&gt;&lt;/TR&gt;&lt;/TABLE&gt;&lt;BR&gt;&lt;BR&gt;

©2009 ROFA.cz - modified and updated by Robert Darlington &amp;#8249;rdarlington@gmail.com&amp;#8250;</description>
<gates>
<gate name="G$1" symbol="ICSP" x="0" y="0"/>
</gates>
<devices>
<device name="-MCP" package="TC2030-MCP">
<connects>
<connect gate="G$1" pin="ICSP_CLK/PGC" pad="5"/>
<connect gate="G$1" pin="ICSP_DAT/PGD" pad="4"/>
<connect gate="G$1" pin="LVP" pad="6"/>
<connect gate="G$1" pin="VDD" pad="2"/>
<connect gate="G$1" pin="VPP/MCLR" pad="1"/>
<connect gate="G$1" pin="VSS(GND)" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-MCP-NL" package="TC2030-MCP-NL">
<connects>
<connect gate="G$1" pin="ICSP_CLK/PGC" pad="5"/>
<connect gate="G$1" pin="ICSP_DAT/PGD" pad="4"/>
<connect gate="G$1" pin="LVP" pad="6"/>
<connect gate="G$1" pin="VDD" pad="2"/>
<connect gate="G$1" pin="VPP/MCLR" pad="1"/>
<connect gate="G$1" pin="VSS(GND)" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="" package="TC2030-MCP-NL-CP">
<connects>
<connect gate="G$1" pin="ICSP_CLK/PGC" pad="5"/>
<connect gate="G$1" pin="ICSP_DAT/PGD" pad="4"/>
<connect gate="G$1" pin="LVP" pad="6"/>
<connect gate="G$1" pin="VDD" pad="2"/>
<connect gate="G$1" pin="VPP/MCLR" pad="1"/>
<connect gate="G$1" pin="VSS(GND)" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="snaptron_Alan">
<packages>
<package name="GX10700">
<hole x="0.8" y="1" drill="0.89"/>
<smd name="OUTER" x="-3.815" y="0" dx="1" dy="1" layer="1" stop="no" cream="no"/>
<polygon width="0.127" layer="1">
<vertex x="3.17" y="1.5"/>
<vertex x="4.59" y="1.5"/>
<vertex x="4.59" y="3.17"/>
<vertex x="3.17" y="4.59"/>
<vertex x="-3.17" y="4.59"/>
<vertex x="-4.59" y="3.17"/>
<vertex x="-4.59" y="-3.17"/>
<vertex x="-3.17" y="-4.59"/>
<vertex x="3.17" y="-4.59"/>
<vertex x="4.59" y="-3.17"/>
<vertex x="4.59" y="-1.5"/>
<vertex x="3.17" y="-1.5"/>
<vertex x="3.17" y="-2.4"/>
<vertex x="2.4" y="-3.17"/>
<vertex x="-2.4" y="-3.17"/>
<vertex x="-3.17" y="-2.4"/>
<vertex x="-3.17" y="2.4"/>
<vertex x="-2.4" y="3.17"/>
<vertex x="2.4" y="3.17"/>
<vertex x="3.17" y="2.4"/>
</polygon>
<hole x="-2.173" y="2.173" drill="0.89"/>
<polygon width="0.127" layer="29">
<vertex x="-4.718" y="3.194"/>
<vertex x="-3.194" y="4.718"/>
<vertex x="3.194" y="4.718"/>
<vertex x="4.718" y="3.194"/>
<vertex x="4.718" y="1.397"/>
<vertex x="3.067" y="1.397"/>
<vertex x="3.067" y="2.432"/>
<vertex x="2.432" y="3.067"/>
<vertex x="-2.432" y="3.067"/>
<vertex x="-3.067" y="2.432"/>
<vertex x="-3.067" y="-2.432"/>
<vertex x="-2.432" y="-3.067"/>
<vertex x="2.305" y="-3.067"/>
<vertex x="3.067" y="-2.305"/>
<vertex x="3.067" y="-1.397"/>
<vertex x="4.718" y="-1.397"/>
<vertex x="4.718" y="-3.194"/>
<vertex x="3.194" y="-4.718"/>
<vertex x="-3.194" y="-4.718"/>
<vertex x="-4.718" y="-3.194"/>
</polygon>
<circle x="0" y="0" radius="2.1" width="0" layer="29"/>
<circle x="0" y="0" radius="3.15" width="0.1" layer="51"/>
<circle x="0" y="0" radius="4.67" width="0.1" layer="51"/>
<smd name="INNER" x="3.2" y="0" dx="3" dy="1.1" layer="1" stop="no" cream="no"/>
<circle x="0" y="0" radius="2.04" width="0" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="S">
<wire x1="0" y1="-3.175" x2="0" y2="-1.905" width="0.254" layer="94"/>
<wire x1="0" y1="-1.905" x2="-1.27" y2="1.905" width="0.254" layer="94"/>
<wire x1="0" y1="1.905" x2="0" y2="3.175" width="0.254" layer="94"/>
<text x="-2.54" y="-3.81" size="1.778" layer="95" rot="R90">&gt;NAME</text>
<text x="3.81" y="-3.81" size="1.778" layer="96" rot="R90">&gt;VALUE</text>
<pin name="P" x="0" y="-5.08" visible="pad" length="short" direction="pas" rot="R90"/>
<pin name="S" x="0" y="5.08" visible="pad" length="short" direction="pas" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GX10700" prefix="S">
<gates>
<gate name="G$1" symbol="S" x="0" y="0"/>
</gates>
<devices>
<device name="" package="GX10700">
<connects>
<connect gate="G$1" pin="P" pad="INNER"/>
<connect gate="G$1" pin="S" pad="OUTER"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Kris">
<packages>
<package name="JOHANSON0900AT43A0070">
<description>Johanson dual wide band antenna
http://www.mouser.com/new/Johanson/johanson-0900at43a0070/</description>
<wire x1="-3.5" y1="1" x2="3.5" y2="1" width="0.127" layer="51"/>
<wire x1="3.5" y1="1" x2="3.5" y2="-1" width="0.127" layer="51"/>
<wire x1="3.5" y1="-1" x2="-3.5" y2="-1" width="0.127" layer="51"/>
<wire x1="-3.5" y1="-1" x2="-3.5" y2="1" width="0.127" layer="51"/>
<smd name="P$1" x="-3.5" y="0" dx="1" dy="1.8" layer="1"/>
<smd name="P$2" x="3.7" y="0" dx="1.4" dy="1.8" layer="1"/>
</package>
</packages>
<symbols>
<symbol name="JOHANSON0900AT43A0070">
<description>Johanson dual wide band antenna
http://www.mouser.com/new/Johanson/johanson-0900at43a0070/</description>
<wire x1="-10.16" y1="2.54" x2="10.16" y2="2.54" width="0.254" layer="94"/>
<wire x1="10.16" y1="2.54" x2="10.16" y2="-2.54" width="0.254" layer="94"/>
<wire x1="10.16" y1="-2.54" x2="-10.16" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-10.16" y1="-2.54" x2="-10.16" y2="2.54" width="0.254" layer="94"/>
<pin name="FEED" x="-15.24" y="0" length="middle"/>
<pin name="TRACE" x="15.24" y="0" length="middle" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="JOHANSON0900AT43A0070">
<description>Johanson dual wide band antenna
http://www.mouser.com/new/Johanson/johanson-0900at43a0070/</description>
<gates>
<gate name="G$1" symbol="JOHANSON0900AT43A0070" x="0" y="0"/>
</gates>
<devices>
<device name="" package="JOHANSON0900AT43A0070">
<connects>
<connect gate="G$1" pin="FEED" pad="P$1"/>
<connect gate="G$1" pin="TRACE" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="Connector_USB" urn="urn:adsk.eagle:library:27510300">
<description>&lt;b&gt;USB Connectors TypeA- B- C- MiniB- MicroB</description>
<packages>
<package name="12401832E402A" urn="urn:adsk.eagle:footprint:27659476/1" library_version="26">
<wire x1="-4.6" y1="-5.25" x2="-4.6" y2="-4.11" width="0.12" layer="51"/>
<wire x1="-4.6" y1="-4.11" x2="-4.6" y2="5.25" width="0.12" layer="51"/>
<wire x1="-4.6" y1="5.25" x2="4.6" y2="5.25" width="0.12" layer="51"/>
<wire x1="4.6" y1="5.25" x2="4.6" y2="-4.11" width="0.12" layer="51"/>
<wire x1="4.6" y1="-4.11" x2="4.6" y2="-5.25" width="0.12" layer="51"/>
<wire x1="4.6" y1="-5.25" x2="-4.6" y2="-5.25" width="0.12" layer="51"/>
<wire x1="-3.23" y1="5.25" x2="-4.6" y2="5.25" width="0.12" layer="21"/>
<wire x1="-4.6" y1="5.25" x2="-4.6" y2="4.14" width="0.12" layer="21"/>
<wire x1="-4.6" y1="2.02" x2="-4.6" y2="-1.73" width="0.12" layer="21"/>
<wire x1="-4.6" y1="-4.11" x2="4.6" y2="-4.11" width="0.12" layer="21"/>
<wire x1="4.6" y1="-1.73" x2="4.6" y2="2.02" width="0.12" layer="21"/>
<wire x1="4.6" y1="4.14" x2="4.6" y2="5.25" width="0.12" layer="21"/>
<wire x1="4.6" y1="5.25" x2="3.23" y2="5.25" width="0.12" layer="21"/>
<wire x1="-4.6" y1="-4.11" x2="4.6" y2="-4.11" width="0.12" layer="51"/>
<wire x1="-4.74" y1="-3.16" x2="-4.74" y2="-2.56" width="0" layer="46"/>
<wire x1="-4.74" y1="-2.56" x2="-4.24" y2="-2.56" width="0" layer="46" curve="-180"/>
<wire x1="-4.24" y1="-2.56" x2="-4.24" y2="-3.16" width="0" layer="46"/>
<wire x1="-4.24" y1="-3.16" x2="-4.74" y2="-3.16" width="0" layer="46" curve="-180"/>
<wire x1="4.24" y1="-3.16" x2="4.24" y2="-2.56" width="0" layer="46"/>
<wire x1="4.24" y1="-2.56" x2="4.74" y2="-2.56" width="0" layer="46" curve="-180"/>
<wire x1="4.74" y1="-2.56" x2="4.74" y2="-3.16" width="0" layer="46"/>
<wire x1="4.74" y1="-3.16" x2="4.24" y2="-3.16" width="0" layer="46" curve="-180"/>
<wire x1="3.88" y1="2.79" x2="3.88" y2="3.39" width="0" layer="46"/>
<wire x1="3.88" y1="3.39" x2="4.38" y2="3.39" width="0" layer="46" curve="-180"/>
<wire x1="4.38" y1="3.39" x2="4.38" y2="2.79" width="0" layer="46"/>
<wire x1="4.38" y1="2.79" x2="3.88" y2="2.79" width="0" layer="46" curve="-180"/>
<wire x1="-4.38" y1="2.79" x2="-4.38" y2="3.39" width="0" layer="46"/>
<wire x1="-4.38" y1="3.39" x2="-3.88" y2="3.39" width="0" layer="46" curve="-180"/>
<wire x1="-3.88" y1="3.39" x2="-3.88" y2="2.79" width="0" layer="46"/>
<wire x1="-3.88" y1="2.79" x2="-4.38" y2="2.79" width="0" layer="46" curve="-180"/>
<wire x1="3.45" y1="4.665" x2="3.75" y2="4.665" width="0" layer="46"/>
<wire x1="3.75" y1="4.665" x2="3.75" y2="4.015" width="0" layer="46" curve="-180"/>
<wire x1="3.75" y1="4.015" x2="3.45" y2="4.015" width="0" layer="46"/>
<wire x1="3.45" y1="4.015" x2="3.45" y2="4.665" width="0" layer="46" curve="-180"/>
<wire x1="4.6" y1="-4" x2="4.6" y2="-4.11" width="0.12" layer="21"/>
<wire x1="-4.6" y1="-4" x2="-4.6" y2="-4.11" width="0.12" layer="21"/>
<text x="-0.22758125" y="6.15876875" size="0.813984375" layer="25" align="center">&gt;NAME</text>
<text x="-0.227640625" y="-5.9757" size="0.813971875" layer="27" align="center">&gt;VALUE</text>
<text x="-2" y="-3.81" size="0.6096" layer="51">PCB Edge</text>
<circle x="-2.8" y="5.84" radius="0.25" width="0" layer="21"/>
<circle x="-2.8" y="5.84" radius="0.25" width="0" layer="51"/>
<pad name="SH4" x="-4.49" y="-2.86" drill="0.5" diameter="0.8" shape="long" rot="R90"/>
<pad name="SH3" x="4.49" y="-2.86" drill="0.5" diameter="0.8" shape="long" rot="R90"/>
<pad name="SH2" x="4.13" y="3.09" drill="0.5" diameter="0.8" shape="long" rot="R90"/>
<pad name="SH1" x="-4.13" y="3.09" drill="0.5" diameter="0.8" shape="long" rot="R90"/>
<smd name="A1" x="-2.75" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B1" x="2.5" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B2" x="2" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B3" x="1.5" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B4" x="1" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B5" x="0.5" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B6" x="0" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B7" x="-0.5" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B8" x="-1" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B9" x="-1.5" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B10" x="-2" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B11" x="-2.5" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="B12" x="-3" y="3.3" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A2" x="-2.25" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A3" x="-1.75" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A4" x="-1.25" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A5" x="-0.75" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A6" x="-0.25" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A7" x="0.25" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A8" x="0.75" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A9" x="1.25" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A10" x="1.75" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A11" x="2.25" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<smd name="A12" x="2.75" y="5" dx="0.7" dy="0.3" layer="1" rot="R90"/>
<hole x="-3.6" y="4.34" drill="0.65"/>
</package>
</packages>
<packages3d>
<package3d name="12401832E402A" urn="urn:adsk.eagle:package:27659500/2" type="model" library_version="26">
<packageinstances>
<packageinstance name="12401832E402A"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="USB_TYPE_C" urn="urn:adsk.eagle:symbol:27659484/1" library_version="26">
<wire x1="-12.7" y1="20.32" x2="12.7" y2="20.32" width="0.254" layer="94"/>
<wire x1="12.7" y1="20.32" x2="12.7" y2="-22.86" width="0.254" layer="94"/>
<wire x1="12.7" y1="-22.86" x2="-12.7" y2="-22.86" width="0.254" layer="94"/>
<wire x1="-12.7" y1="-22.86" x2="-12.7" y2="20.32" width="0.254" layer="94"/>
<wire x1="-3.62" y1="0" x2="-3.12" y2="0" width="0.254" layer="94"/>
<wire x1="-3.12" y1="0" x2="-2.62" y2="0" width="0.254" layer="94"/>
<wire x1="-2.62" y1="0" x2="-1.12" y2="1.5" width="0.254" layer="94"/>
<wire x1="-1.12" y1="1.5" x2="-0.12" y2="1.5" width="0.254" layer="94"/>
<wire x1="-2.62" y1="0" x2="1.38" y2="0" width="0.254" layer="94"/>
<wire x1="-3.12" y1="0" x2="-1.62" y2="-1.5" width="0.254" layer="94"/>
<wire x1="0.88" y1="0.5" x2="1.38" y2="0" width="0.254" layer="94"/>
<wire x1="1.38" y1="0" x2="0.88" y2="-0.5" width="0.254" layer="94"/>
<wire x1="-1.62" y1="-1.5" x2="-0.12" y2="-1.5" width="0.254" layer="94"/>
<wire x1="0.88" y1="0.5" x2="0.88" y2="-0.5" width="0.254" layer="94"/>
<text x="0" y="22.86" size="1.778" layer="95" align="center">&gt;NAME</text>
<text x="0" y="-25.4" size="1.778" layer="96" rot="MR180" align="center">&gt;VALUE</text>
<pin name="GND4" x="-15.24" y="-17.78" length="short" direction="pwr"/>
<pin name="TX1-" x="-15.24" y="7.62" length="short"/>
<pin name="TX1+" x="-15.24" y="10.16" length="short"/>
<pin name="VBUS1" x="-15.24" y="17.78" length="short" direction="pwr"/>
<pin name="D+1" x="-15.24" y="2.54" length="short"/>
<pin name="CC1" x="-15.24" y="5.08" length="short"/>
<pin name="SBU1" x="-15.24" y="-2.54" length="short"/>
<pin name="D-1" x="-15.24" y="0" length="short"/>
<pin name="RX2-" x="-15.24" y="-5.08" length="short"/>
<pin name="RX2+" x="-15.24" y="-7.62" length="short"/>
<pin name="SHIELD1" x="15.24" y="-12.7" length="short" direction="sup" rot="R180"/>
<pin name="GND2" x="-15.24" y="-15.24" length="short" direction="pwr"/>
<pin name="TX2-" x="15.24" y="-5.08" length="short" rot="R180"/>
<pin name="TX2+" x="15.24" y="-7.62" length="short" rot="R180"/>
<pin name="VBUS2" x="-15.24" y="15.24" length="short" direction="pwr"/>
<pin name="D+2" x="15.24" y="0" length="short" rot="R180"/>
<pin name="CC2" x="15.24" y="-2.54" length="short" rot="R180"/>
<pin name="SBU2" x="15.24" y="5.08" length="short" rot="R180"/>
<pin name="D-2" x="15.24" y="2.54" length="short" rot="R180"/>
<pin name="RX1-" x="15.24" y="7.62" length="short" rot="R180"/>
<pin name="RX1+" x="15.24" y="10.16" length="short" rot="R180"/>
<pin name="GND1" x="-15.24" y="-12.7" length="short" direction="pwr"/>
<pin name="GND3" x="-15.24" y="-20.32" length="short" direction="pwr"/>
<pin name="VBUS3" x="15.24" y="17.78" length="short" direction="pwr" rot="R180"/>
<pin name="VBUS4" x="15.24" y="15.24" length="short" direction="pwr" rot="R180"/>
<pin name="SHIELD2" x="15.24" y="-15.24" length="short" direction="sup" rot="R180"/>
<pin name="SHIELD3" x="15.24" y="-17.78" length="short" direction="sup" rot="R180"/>
<pin name="SHIELD4" x="15.24" y="-20.32" length="short" direction="sup" rot="R180"/>
<circle x="-4.12" y="0" radius="0.3" width="0.5" layer="94"/>
<circle x="0.38" y="1.5" radius="0.3" width="0.5" layer="94"/>
<rectangle x1="-0.12" y1="-2" x2="0.88" y2="-1" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="12401832E402A" urn="urn:adsk.eagle:component:27659505/6" prefix="J" library_version="26">
<description>USB(3.1) Type-C- RCPT- 24POS- SMD-THT-R/A

&lt;br&gt;&lt;a href="https://cdn.amphenol-icc.com/media/wysiwyg/files/documentation/datasheet/inputoutput/io_usb_type_c.pdf"&gt; Datasheet&lt;/a&lt;br&gt;

&lt;br&gt;&lt;a href="https://cdn.amphenol-icc.com/media/wysiwyg/files/drawing/c12401832e402a.pdf"&gt; Drawing&lt;/a</description>
<gates>
<gate name="G$1" symbol="USB_TYPE_C" x="0" y="0"/>
</gates>
<devices>
<device name="" package="12401832E402A">
<connects>
<connect gate="G$1" pin="CC1" pad="A5"/>
<connect gate="G$1" pin="CC2" pad="B5"/>
<connect gate="G$1" pin="D+1" pad="A6"/>
<connect gate="G$1" pin="D+2" pad="B6"/>
<connect gate="G$1" pin="D-1" pad="A7"/>
<connect gate="G$1" pin="D-2" pad="B7"/>
<connect gate="G$1" pin="GND1" pad="A1"/>
<connect gate="G$1" pin="GND2" pad="A12"/>
<connect gate="G$1" pin="GND3" pad="B1"/>
<connect gate="G$1" pin="GND4" pad="B12"/>
<connect gate="G$1" pin="RX1+" pad="B11"/>
<connect gate="G$1" pin="RX1-" pad="B10"/>
<connect gate="G$1" pin="RX2+" pad="A11"/>
<connect gate="G$1" pin="RX2-" pad="A10"/>
<connect gate="G$1" pin="SBU1" pad="A8"/>
<connect gate="G$1" pin="SBU2" pad="B8"/>
<connect gate="G$1" pin="SHIELD1" pad="SH1"/>
<connect gate="G$1" pin="SHIELD2" pad="SH2"/>
<connect gate="G$1" pin="SHIELD3" pad="SH3"/>
<connect gate="G$1" pin="SHIELD4" pad="SH4"/>
<connect gate="G$1" pin="TX1+" pad="A2"/>
<connect gate="G$1" pin="TX1-" pad="A3"/>
<connect gate="G$1" pin="TX2+" pad="B2"/>
<connect gate="G$1" pin="TX2-" pad="B3"/>
<connect gate="G$1" pin="VBUS1" pad="A4"/>
<connect gate="G$1" pin="VBUS2" pad="A9"/>
<connect gate="G$1" pin="VBUS3" pad="B4"/>
<connect gate="G$1" pin="VBUS4" pad="B9"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:27659500/2"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="CATEGORY" value="USB Connector" constant="no"/>
<attribute name="CONTACTS" value="24" constant="no"/>
<attribute name="CURRENT_RATING" value="5A" constant="no"/>
<attribute name="DATASHEET" value="https://cdn.amphenol-cs.com/media/wysiwyg/files/documentation/datasheet/inputoutput/io_usb_3_2_type_c.pdf" constant="no"/>
<attribute name="DESCRIPTION" value="USB-C (USB TYPE-C) USB 3.2 Gen 2 (USB 3.1 Gen 2- Superspeed + (USB 3.1)) Receptacle Connector 24 Position Surface Mount- Right Angle- Through Hole" constant="no"/>
<attribute name="GENDER" value="Receptacle" constant="no"/>
<attribute name="MANUFACTURER" value="Amphenol ICC (Commercial Products)" constant="no"/>
<attribute name="MPN" value="12401832E402A" constant="no"/>
<attribute name="OPERATING_TEMPERATURE" value="-40℃ ~ 85℃" constant="no"/>
<attribute name="PACKAGE_SIZE" value="NA" constant="no"/>
<attribute name="PACKAGE_TYPE" value="SMD" constant="no"/>
<attribute name="PART_STATUS" value="ACTIVE" constant="no"/>
<attribute name="ROHS" value="COMPLIANT" constant="no"/>
<attribute name="SERIES" value="NA" constant="no"/>
<attribute name="SUBCATEGORY" value="USB TYPE-C" constant="no"/>
<attribute name="THERMALLOSS" value="" constant="no"/>
<attribute name="TYPE" value="Surface Mount-Right Angle-Through Hole" constant="no"/>
<attribute name="VOLTAGE_RATING" value="NA" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
<class number="1" name="power" width="0.381" drill="0">
<clearance class="1" value="0.254"/>
</class>
</classes>
<parts>
<part name="FRAME1" library="frames" library_urn="urn:adsk.eagle:library:229" deviceset="A4L-LOC" device="" value="Moteino"/>
<part name="SUPPLY4" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="SUPPLY14" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="ATMEGA328" library="LowPowerLab" deviceset="ATMEGA168/328" device="TQFP32" value="ATMega-328"/>
<part name="R1" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="SUPPLY2" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="Y1" library="LowPowerLab" deviceset="RESONATOR" device="SMD"/>
<part name="LIS3DH" library="microbuilder" deviceset="ACCEL_LIS3DHTR" device="" value="LIS3DHTR"/>
<part name="R12" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="SUPPLY22" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="SUPPLY23" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="SUPPLY24" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="SUPPLY25" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="SUPPLY16" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="R5" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="1M"/>
<part name="R6" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="1M"/>
<part name="SUPPLY41" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="C2" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="0u1"/>
<part name="LDO" library="linear" library_urn="urn:adsk.eagle:library:262" deviceset="MCP1703" device="CB" package3d_urn="urn:adsk.eagle:package:16489/2"/>
<part name="C13" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="0u1"/>
<part name="C14" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="1u"/>
<part name="SUPPLY9" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="C3" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="1u"/>
<part name="C7" library="LowPowerLab" deviceset="CAP" device="0805-CAP" value="10u"/>
<part name="MCP73831" library="SparkFun-PowerIC" deviceset="MCP73831" device=""/>
<part name="SUPPLY27" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="RCHRG" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="2.2K"/>
<part name="SUPPLY28" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="C8" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="4.7uF"/>
<part name="SUPPLY29" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="SUPPLY30" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="R7" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="SUPPLY33" library="sparkfun_photon_temp" deviceset="VUSB" device=""/>
<part name="SUPPLY34" library="sparkfun_photon_temp" deviceset="VUSB" device=""/>
<part name="SUPPLY1" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="R9" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="R10" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="SUPPLY3" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="SUPPLY12" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="R4" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="1K"/>
<part name="N-FET" library="LowPowerLab" deviceset="MOSFET-NCHANNEL" device="" value="N-CH"/>
<part name="JST" library="M40-4010246" deviceset="M40-4010246" device=""/>
<part name="SUPPLY7" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="R17" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="TAG-ICSP" library="tag-connect" deviceset="TC2030_ICSP" device="-MCP-NL" value="TAG-Connect"/>
<part name="TL_FIDUCIAL" library="LowPowerLab" deviceset="FIDUCIAL" device="1.5MM"/>
<part name="BR_FIDUCIAL" library="LowPowerLab" deviceset="FIDUCIAL" device="1.5MM"/>
<part name="SUPPLY8" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="IR2-BTM" library="VSMY2941RGX01" deviceset="VSMY2941RGX01" device="" value="VSMY2941RGX01"/>
<part name="RGB_LED" library="LowPowerLab" deviceset="WS2812-2020" device="2020"/>
<part name="PFET" library="LowPowerLab" deviceset="MOSFET-PCHANNEL" device="SMD"/>
<part name="R8" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="1K!!!"/>
<part name="SUPPLY10" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="C1" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="0u1"/>
<part name="SUPPLY5" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="IRLED-TOP" library="VSMY2941RGX01" deviceset="VSMY2941RGX01" device="" value="VSMY2941RGX01"/>
<part name="U$1" library="LowPowerLab" deviceset="RFM12B_ANTENNA" device="" value="RFM12B_ANTENNA"/>
<part name="SUPPLY13" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="P+6" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="U$11" library="LowPowerLab" deviceset="RFM95_WITHRST" device=""/>
<part name="C5" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="0u1"/>
<part name="SUPPLY19" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="R3" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="R20" library="LowPowerLab" deviceset="RESISTOR" device="0603-RES" value="10k"/>
<part name="SUPPLY20" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="SW1" library="snaptron_Alan" deviceset="GX10700" device=""/>
<part name="SW2" library="snaptron_Alan" deviceset="GX10700" device=""/>
<part name="SUPPLY6" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="SUPPLY15" library="SparkFun" deviceset="VCC" device="" value="3.3V"/>
<part name="U$5" library="Kris" deviceset="JOHANSON0900AT43A0070" device=""/>
<part name="ANTC1" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="2p2"/>
<part name="ANTC2" library="LowPowerLab" deviceset="CAP" device="0402-CAP" value="DNP"/>
<part name="R2" library="LowPowerLab" deviceset="RESISTOR" device="0402-RES" value="JMP"/>
<part name="SUPPLY17" library="supply2" library_urn="urn:adsk.eagle:library:372" deviceset="GND" device=""/>
<part name="C4" library="LowPowerLab" deviceset="CAP" device="0603-CAP" value="4.7uF"/>
<part name="ANTC3" library="LowPowerLab" deviceset="CAP" device="0402-CAP" value="2p2"/>
<part name="TP1" library="LowPowerLab" deviceset="PAD_OR_PIN_1" device="TP"/>
<part name="TP2" library="LowPowerLab" deviceset="PAD_OR_PIN_1" device="TP"/>
<part name="FIDUCIAL_BOTTOMRIGHT" library="LowPowerLab" deviceset="FIDUCIAL" device="SQ"/>
<part name="FIDUCIAL_TOPLEFT" library="LowPowerLab" deviceset="FIDUCIAL" device="SQ"/>
<part name="J1" library="Connector_USB" library_urn="urn:adsk.eagle:library:27510300" deviceset="12401832E402A" device="" package3d_urn="urn:adsk.eagle:package:27659500/2"/>
</parts>
<sheets>
<sheet>
<plain>
<text x="167.386" y="18.288" size="3.81" layer="94" font="vector" ratio="10">ALAN - DURESS</text>
<text x="217.678" y="20.32" size="2.54" layer="94" font="vector">author: Felix Rusu</text>
<text x="224.79" y="151.13" size="1.778" layer="97">I2C</text>
<text x="209.55" y="147.32" size="1.778" layer="97">SCL (Pin 4) = Serial Clock</text>
<text x="209.55" y="144.78" size="1.778" layer="97">SDA (Pin 6) = Serial Data</text>
<text x="209.55" y="142.24" size="1.778" layer="97">SD0 (Pin 7) = SA0/Address LSB</text>
<text x="209.55" y="166.37" size="1.778" layer="97">* CS needs to be set off board
to select SPI or I2C</text>
<text x="209.55" y="163.83" size="1.778" layer="97">CS High = I2C, Low = SPI</text>
<text x="209.55" y="161.29" size="1.778" layer="97">Defaults to I2C as-is (R12)</text>
<text x="209.55" y="134.62" size="1.778" layer="97">SDO pulled low by default (R13)
to set I2C address LSB to 0</text>
<text x="217.17" y="172.72" size="1.778" layer="97">Bus Selection</text>
<text x="224.79" y="127" size="1.778" layer="97">SPI</text>
<text x="209.55" y="124.46" size="1.778" layer="97">SCL (Pin 4) = Serial Clock</text>
<text x="209.55" y="121.92" size="1.778" layer="97">SDA (Pin 6) = Data In (MOSI)</text>
<text x="209.55" y="119.38" size="1.778" layer="97">SDO (Pin 7) = Data Out (MISO)</text>
<text x="215.9" y="114.3" size="1.778" layer="97">Set SJ1 to make I2C</text>
<text x="218.44" y="111.76" size="1.778" layer="97">address LSB 1</text>
<text x="162.56" y="113.03" size="3.048" layer="94" ratio="17" align="top-left">Batt Monitor</text>
<text x="148.59" y="83.82" size="1.778" layer="94" rot="R180">Charge Current:
~454mA (1000V/2.2K)
~212mA (4.7K)
~100mA (10K)</text>
<text x="129.54" y="104.14" size="3.048" layer="94" ratio="17" align="top-left">CHARGER</text>
<text x="160.02" y="173.99" size="3.048" layer="94" ratio="17" align="top-left">ACCEL</text>
<text x="195.58" y="52.07" size="1.778" layer="91" font="vector">RFM69HCW
RFM95/LoRa</text>
<text x="229.616" y="76.708" size="2.54" layer="94" font="vector" ratio="17">TAG-Connect
(ICSP)</text>
<text x="169.926" y="34.798" size="3.81" layer="94" font="vector" ratio="10">Radio-HCW</text>
<text x="93.98" y="33.02" size="3.048" layer="94" ratio="17" align="top-left">IR LED
DRIVER</text>
</plain>
<instances>
<instance part="FRAME1" gate="G$1" x="0" y="0" smashed="yes">
<attribute name="DRAWING_NAME" x="217.17" y="15.24" size="2.54" layer="94" font="vector"/>
<attribute name="LAST_DATE_TIME" x="217.17" y="10.16" size="2.286" layer="94" font="vector"/>
<attribute name="SHEET" x="230.505" y="5.08" size="2.54" layer="94" font="vector"/>
</instance>
<instance part="SUPPLY4" gate="1" x="10.16" y="165.1" smashed="yes">
<attribute name="VALUE" x="9.144" y="168.656" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY14" gate="GND" x="20.32" y="102.87" smashed="yes">
<attribute name="VALUE" x="15.875" y="99.695" size="1.778" layer="96"/>
</instance>
<instance part="ATMEGA328" gate="G$1" x="45.72" y="138.43" smashed="yes">
<attribute name="NAME" x="38.1" y="168.91" size="1.778" layer="95" font="vector"/>
</instance>
<instance part="R1" gate="G$1" x="15.24" y="163.83" smashed="yes">
<attribute name="NAME" x="11.43" y="165.3286" size="1.778" layer="95"/>
<attribute name="VALUE" x="11.43" y="160.528" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY2" gate="1" x="218.44" y="96.52" smashed="yes">
<attribute name="VALUE" x="217.424" y="100.076" size="1.778" layer="96"/>
</instance>
<instance part="Y1" gate="G$1" x="20.32" y="128.27" smashed="yes">
<attribute name="NAME" x="22.86" y="129.286" size="1.778" layer="95"/>
<attribute name="VALUE" x="22.86" y="120.65" size="1.778" layer="96"/>
</instance>
<instance part="LIS3DH" gate="G$1" x="176.53" y="153.67" smashed="yes">
<attribute name="NAME" x="163.83" y="168.91" size="1.27" layer="95"/>
<attribute name="VALUE" x="171.45" y="153.67" size="1.27" layer="95"/>
</instance>
<instance part="R12" gate="G$1" x="191.77" y="138.43" smashed="yes" rot="R180">
<attribute name="NAME" x="195.58" y="136.9314" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="195.58" y="141.732" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="SUPPLY22" gate="1" x="154.94" y="161.29" smashed="yes">
<attribute name="VALUE" x="153.924" y="164.846" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY23" gate="GND" x="207.01" y="148.59" smashed="yes">
<attribute name="VALUE" x="205.105" y="145.415" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY24" gate="1" x="199.39" y="138.43" smashed="yes">
<attribute name="VALUE" x="198.374" y="141.986" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY25" gate="GND" x="158.75" y="146.05" smashed="yes">
<attribute name="VALUE" x="156.845" y="142.875" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY16" gate="1" x="179.07" y="170.18" smashed="yes">
<attribute name="VALUE" x="178.054" y="173.736" size="1.778" layer="96"/>
</instance>
<instance part="R5" gate="G$1" x="180.34" y="118.11" smashed="yes" rot="R180">
<attribute name="NAME" x="184.15" y="116.6114" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="184.15" y="121.412" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="R6" gate="G$1" x="170.18" y="118.11" smashed="yes" rot="R180">
<attribute name="NAME" x="173.99" y="116.6114" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="173.99" y="121.412" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="SUPPLY41" gate="GND" x="187.96" y="118.11" smashed="yes" rot="R90">
<attribute name="VALUE" x="191.135" y="116.205" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="C2" gate="G$1" x="180.34" y="124.46" smashed="yes" rot="MR270">
<attribute name="NAME" x="177.419" y="124.206" size="1.778" layer="95" rot="MR270"/>
<attribute name="VALUE" x="180.594" y="127.889" size="1.778" layer="96" rot="MR180"/>
</instance>
<instance part="LDO" gate="G$1" x="175.26" y="95.25" smashed="yes">
<attribute name="NAME" x="167.64" y="100.965" size="3.048" layer="94" ratio="17"/>
<attribute name="VALUE" x="167.64" y="98.425" size="1.778" layer="96"/>
</instance>
<instance part="C13" gate="G$1" x="190.5" y="90.17" smashed="yes" rot="MR0">
<attribute name="NAME" x="188.976" y="93.091" size="1.778" layer="95" rot="MR0"/>
<attribute name="VALUE" x="188.976" y="90.551" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="C14" gate="G$1" x="163.83" y="90.17" smashed="yes" rot="MR0">
<attribute name="VALUE" x="167.386" y="88.011" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="SUPPLY9" gate="GND" x="175.26" y="85.09" smashed="yes" rot="MR0">
<attribute name="VALUE" x="179.705" y="81.915" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="C3" gate="G$1" x="73.66" y="76.2" smashed="yes" rot="R90">
<attribute name="NAME" x="74.676" y="80.899" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="77.216" y="75.819" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="C7" gate="G$1" x="195.58" y="90.17" smashed="yes" rot="MR0">
<attribute name="NAME" x="199.136" y="93.091" size="1.778" layer="95" rot="MR0"/>
<attribute name="VALUE" x="200.406" y="88.011" size="1.778" layer="96" rot="MR0"/>
</instance>
<instance part="MCP73831" gate="G$1" x="137.16" y="92.71" smashed="yes">
<attribute name="NAME" x="129.54" y="98.298" size="1.778" layer="95"/>
<attribute name="VALUE" x="129.54" y="85.09" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY27" gate="GND" x="154.94" y="80.01" smashed="yes">
<attribute name="VALUE" x="153.035" y="76.835" size="1.778" layer="96"/>
</instance>
<instance part="RCHRG" gate="G$1" x="154.94" y="87.63" smashed="yes" rot="R90">
<attribute name="NAME" x="153.4414" y="83.82" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="158.242" y="83.82" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="SUPPLY28" gate="GND" x="147.32" y="87.63" smashed="yes">
<attribute name="VALUE" x="145.415" y="84.455" size="1.778" layer="96"/>
</instance>
<instance part="C8" gate="G$1" x="124.46" y="95.25" smashed="yes" rot="MR270">
<attribute name="VALUE" x="120.904" y="99.949" size="1.778" layer="96" rot="MR180"/>
</instance>
<instance part="SUPPLY29" gate="GND" x="116.84" y="95.25" smashed="yes" rot="R270">
<attribute name="VALUE" x="113.665" y="97.155" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="SUPPLY30" gate="GND" x="66.04" y="58.42" smashed="yes">
<attribute name="VALUE" x="64.135" y="55.245" size="1.778" layer="96"/>
</instance>
<instance part="R7" gate="G$1" x="111.76" y="101.6" smashed="yes" rot="R90">
<attribute name="NAME" x="116.84" y="105.1814" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="118.11" y="102.362" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="SUPPLY33" gate="G$1" x="66.04" y="90.17" smashed="yes">
<attribute name="VALUE" x="65.024" y="93.726" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY34" gate="G$1" x="127" y="104.14" smashed="yes">
<attribute name="VALUE" x="125.984" y="107.696" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY1" gate="1" x="195.58" y="95.25" smashed="yes">
<attribute name="VALUE" x="194.564" y="98.806" size="1.778" layer="96"/>
</instance>
<instance part="R9" gate="G$1" x="95.25" y="158.75" smashed="yes" rot="R90">
<attribute name="NAME" x="99.06" y="155.9814" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="100.33" y="163.322" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="R10" gate="G$1" x="101.6" y="158.75" smashed="yes" rot="R90">
<attribute name="NAME" x="107.95" y="155.9814" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="106.68" y="163.322" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="SUPPLY3" gate="1" x="95.25" y="163.83" smashed="yes">
<attribute name="VALUE" x="94.234" y="167.386" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY12" gate="GND" x="123.19" y="6.35" smashed="yes">
<attribute name="VALUE" x="121.285" y="3.175" size="1.778" layer="96"/>
</instance>
<instance part="R4" gate="G$1" x="102.87" y="21.59" smashed="yes" rot="R180">
<attribute name="VALUE" x="101.6" y="18.288" size="1.778" layer="96" font="vector"/>
</instance>
<instance part="N-FET" gate="G$1" x="123.19" y="21.59" smashed="yes">
<attribute name="NAME" x="128.27" y="21.59" size="1.778" layer="95"/>
<attribute name="VALUE" x="128.27" y="19.05" size="1.778" layer="96"/>
</instance>
<instance part="JST" gate="G$1" x="204.47" y="78.74" smashed="yes" rot="R180">
<attribute name="NAME" x="191.77" y="85.09" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="203.2" y="74.93" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="SUPPLY7" gate="GND" x="181.102" y="76.2" smashed="yes">
<attribute name="VALUE" x="179.197" y="73.025" size="1.778" layer="96"/>
</instance>
<instance part="R17" gate="G$1" x="113.03" y="16.51" smashed="yes" rot="R180">
<attribute name="NAME" x="116.84" y="15.0114" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="116.84" y="19.812" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="TAG-ICSP" gate="G$1" x="245.11" y="91.44" smashed="yes"/>
<instance part="TL_FIDUCIAL" gate="G$1" x="170.18" y="7.62" smashed="yes"/>
<instance part="BR_FIDUCIAL" gate="G$1" x="180.34" y="7.62" smashed="yes"/>
<instance part="SUPPLY8" gate="1" x="111.76" y="106.68" smashed="yes">
<attribute name="VALUE" x="110.744" y="110.236" size="1.778" layer="96"/>
</instance>
<instance part="IR2-BTM" gate="G$1" x="140.97" y="34.29" smashed="yes" rot="R270">
<attribute name="NAME" x="145.796" y="37.846" size="1.27" layer="95" rot="R270"/>
<attribute name="VALUE" x="142.748" y="45.466" size="1.27" layer="96" rot="R270"/>
</instance>
<instance part="RGB_LED" gate="G$1" x="58.42" y="21.59" smashed="yes">
<attribute name="NAME" x="55.88" y="29.972" size="1.778" layer="95" font="vector" align="bottom-center"/>
<attribute name="VALUE" x="55.88" y="13.97" size="1.778" layer="95" font="vector" align="bottom-center"/>
</instance>
<instance part="PFET" gate="G$1" x="38.1" y="36.83" smashed="yes" rot="MR90">
<attribute name="NAME" x="48.26" y="38.1" size="1.778" layer="95" rot="MR0"/>
</instance>
<instance part="R8" gate="G$1" x="29.21" y="31.75" smashed="yes" rot="R90">
<attribute name="NAME" x="27.7114" y="27.94" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="32.512" y="27.94" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="SUPPLY10" gate="GND" x="71.12" y="24.13" smashed="yes">
<attribute name="VALUE" x="69.215" y="20.955" size="1.778" layer="96"/>
</instance>
<instance part="C1" gate="G$1" x="80.01" y="73.66" smashed="yes" rot="MR180">
<attribute name="NAME" x="80.264" y="75.819" size="1.778" layer="95" rot="MR180"/>
<attribute name="VALUE" x="80.264" y="70.739" size="1.778" layer="96" rot="MR180"/>
</instance>
<instance part="SUPPLY5" gate="GND" x="80.01" y="63.5" smashed="yes">
<attribute name="VALUE" x="78.105" y="60.325" size="1.778" layer="96"/>
</instance>
<instance part="IRLED-TOP" gate="G$1" x="115.57" y="34.29" smashed="yes" rot="R270">
<attribute name="NAME" x="120.396" y="37.846" size="1.27" layer="95" rot="R270"/>
<attribute name="VALUE" x="112.268" y="45.466" size="1.27" layer="96" rot="R270"/>
</instance>
<instance part="U$1" gate="G$1" x="219.71" y="57.15" smashed="yes" rot="R90"/>
<instance part="SUPPLY13" gate="GND" x="205.74" y="29.21" smashed="yes">
<attribute name="VALUE" x="203.835" y="26.035" size="1.778" layer="96"/>
</instance>
<instance part="P+6" gate="1" x="203.2" y="66.04" smashed="yes">
<attribute name="VALUE" x="202.184" y="69.596" size="1.778" layer="96"/>
</instance>
<instance part="U$11" gate="G$1" x="203.327" y="49.53" smashed="yes"/>
<instance part="C5" gate="G$1" x="93.98" y="130.81" smashed="yes" rot="MR180">
<attribute name="NAME" x="94.234" y="127.889" size="1.778" layer="95" rot="MR180"/>
<attribute name="VALUE" x="94.234" y="132.969" size="1.778" layer="96" rot="MR180"/>
</instance>
<instance part="SUPPLY19" gate="GND" x="93.98" y="120.65" smashed="yes">
<attribute name="VALUE" x="92.075" y="117.475" size="1.778" layer="96"/>
</instance>
<instance part="R3" gate="G$1" x="88.9" y="128.27" smashed="yes" rot="R90">
<attribute name="NAME" x="87.4014" y="124.46" size="1.778" layer="95" rot="R90"/>
<attribute name="VALUE" x="92.202" y="124.46" size="1.778" layer="96" rot="R90"/>
</instance>
<instance part="R20" gate="G$1" x="95.25" y="113.03" smashed="yes">
<attribute name="NAME" x="90.17" y="109.4486" size="1.778" layer="95"/>
<attribute name="VALUE" x="97.79" y="109.728" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY20" gate="1" x="101.6" y="113.03" smashed="yes">
<attribute name="VALUE" x="100.584" y="116.586" size="1.778" layer="96"/>
</instance>
<instance part="SW1" gate="G$1" x="104.14" y="133.35" smashed="yes" rot="R270">
<attribute name="NAME" x="100.33" y="135.89" size="1.778" layer="95"/>
<attribute name="VALUE" x="100.33" y="129.54" size="1.778" layer="96"/>
</instance>
<instance part="SW2" gate="G$1" x="91.44" y="76.2" smashed="yes" rot="R270">
<attribute name="NAME" x="87.63" y="80.01" size="1.778" layer="95"/>
<attribute name="VALUE" x="85.09" y="72.39" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY6" gate="GND" x="96.52" y="63.5" smashed="yes">
<attribute name="VALUE" x="94.615" y="60.325" size="1.778" layer="96"/>
</instance>
<instance part="SUPPLY15" gate="1" x="109.22" y="139.7" smashed="yes">
<attribute name="VALUE" x="108.204" y="143.256" size="1.778" layer="96"/>
</instance>
<instance part="U$5" gate="G$1" x="234.95" y="35.56" smashed="yes" rot="MR180"/>
<instance part="ANTC1" gate="G$1" x="232.41" y="52.07" smashed="yes" rot="R270">
<attribute name="NAME" x="232.156" y="51.689" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="232.156" y="54.229" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="ANTC2" gate="G$1" x="232.41" y="41.91" smashed="yes" rot="R270">
<attribute name="NAME" x="232.156" y="41.529" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="232.156" y="44.069" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="R2" gate="G$1" x="219.71" y="46.99" smashed="yes" rot="MR270">
<attribute name="NAME" x="218.2114" y="50.8" size="1.778" layer="95" rot="MR270"/>
<attribute name="VALUE" x="223.012" y="50.8" size="1.778" layer="96" rot="MR270"/>
</instance>
<instance part="SUPPLY17" gate="GND" x="241.3" y="44.45" smashed="yes" rot="MR180">
<attribute name="VALUE" x="239.395" y="47.625" size="1.778" layer="96" rot="MR180"/>
</instance>
<instance part="C4" gate="G$1" x="205.74" y="92.71" smashed="yes" rot="MR180">
<attribute name="VALUE" x="201.041" y="89.154" size="1.778" layer="96" rot="MR90"/>
</instance>
<instance part="ANTC3" gate="G$1" x="232.41" y="55.88" smashed="yes" rot="R270">
<attribute name="NAME" x="232.156" y="55.499" size="1.778" layer="95" rot="R180"/>
<attribute name="VALUE" x="232.156" y="58.039" size="1.778" layer="96" rot="R180"/>
</instance>
<instance part="TP1" gate="G$1" x="194.31" y="162.56" smashed="yes" rot="R90">
<attribute name="NAME" x="191.77" y="166.37" size="1.778" layer="95"/>
</instance>
<instance part="TP2" gate="G$1" x="204.47" y="162.56" smashed="yes" rot="R90">
<attribute name="NAME" x="207.01" y="167.64" size="1.778" layer="95" rot="R180"/>
</instance>
<instance part="FIDUCIAL_BOTTOMRIGHT" gate="G$1" x="196.85" y="7.62" smashed="yes" rot="R90"/>
<instance part="FIDUCIAL_TOPLEFT" gate="G$1" x="204.47" y="7.62" smashed="yes" rot="R90"/>
<instance part="J1" gate="G$1" x="40.64" y="71.12" smashed="yes">
<attribute name="NAME" x="40.64" y="93.98" size="1.778" layer="95" align="center"/>
<attribute name="VALUE" x="35.56" y="45.72" size="1.778" layer="96" rot="MR180" align="center"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="GND" class="1">
<segment>
<wire x1="20.32" y1="105.41" x2="20.32" y2="107.95" width="0.1524" layer="91"/>
<wire x1="20.32" y1="107.95" x2="20.32" y2="110.49" width="0.1524" layer="91"/>
<wire x1="20.32" y1="110.49" x2="20.32" y2="113.03" width="0.1524" layer="91"/>
<wire x1="20.32" y1="113.03" x2="20.32" y2="120.65" width="0.1524" layer="91"/>
<wire x1="20.32" y1="113.03" x2="22.86" y2="113.03" width="0.1524" layer="91"/>
<wire x1="20.32" y1="110.49" x2="22.86" y2="110.49" width="0.1524" layer="91"/>
<wire x1="20.32" y1="107.95" x2="22.86" y2="107.95" width="0.1524" layer="91"/>
<junction x="20.32" y="113.03"/>
<junction x="20.32" y="110.49"/>
<junction x="20.32" y="107.95"/>
<pinref part="SUPPLY14" gate="GND" pin="GND"/>
<pinref part="ATMEGA328" gate="G$1" pin="GND@1"/>
<pinref part="ATMEGA328" gate="G$1" pin="GND@2"/>
<pinref part="ATMEGA328" gate="G$1" pin="AGND"/>
<pinref part="Y1" gate="G$1" pin="XTAL2_GND"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="GND@1"/>
<wire x1="161.29" y1="148.59" x2="158.75" y2="148.59" width="0.1524" layer="91"/>
<pinref part="SUPPLY25" gate="GND" pin="GND"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="RES(GND)"/>
<wire x1="191.77" y1="151.13" x2="207.01" y2="151.13" width="0.1524" layer="91"/>
<pinref part="LIS3DH" gate="G$1" pin="GND@2"/>
<wire x1="191.77" y1="156.21" x2="207.01" y2="156.21" width="0.1524" layer="91"/>
<wire x1="207.01" y1="156.21" x2="207.01" y2="151.13" width="0.1524" layer="91"/>
<pinref part="SUPPLY23" gate="GND" pin="GND"/>
<junction x="207.01" y="151.13"/>
<pinref part="TP2" gate="G$1" pin="P$1"/>
<wire x1="207.01" y1="156.21" x2="204.47" y2="160.02" width="0.1524" layer="91"/>
<junction x="207.01" y="156.21"/>
</segment>
<segment>
<pinref part="R5" gate="G$1" pin="1"/>
<wire x1="185.42" y1="118.11" x2="185.42" y2="124.46" width="0.1524" layer="91"/>
<pinref part="C2" gate="G$1" pin="2"/>
<wire x1="185.42" y1="124.46" x2="182.88" y2="124.46" width="0.1524" layer="91"/>
<pinref part="SUPPLY41" gate="GND" pin="GND"/>
<junction x="185.42" y="118.11"/>
</segment>
<segment>
<wire x1="190.5" y1="87.63" x2="175.26" y2="87.63" width="0.1524" layer="91"/>
<wire x1="175.26" y1="87.63" x2="163.83" y2="87.63" width="0.1524" layer="91"/>
<junction x="175.26" y="87.63"/>
<pinref part="LDO" gate="G$1" pin="GND"/>
<pinref part="C13" gate="G$1" pin="2"/>
<pinref part="C14" gate="G$1" pin="2"/>
<pinref part="SUPPLY9" gate="GND" pin="GND"/>
<pinref part="C7" gate="G$1" pin="2"/>
<wire x1="190.5" y1="87.63" x2="195.58" y2="87.63" width="0.1524" layer="91"/>
<pinref part="C4" gate="G$1" pin="1"/>
<wire x1="205.74" y1="87.63" x2="195.58" y2="87.63" width="0.1524" layer="91"/>
<junction x="195.58" y="87.63"/>
<junction x="190.5" y="87.63"/>
</segment>
<segment>
<pinref part="MCP73831" gate="G$1" pin="VSS"/>
<pinref part="SUPPLY28" gate="GND" pin="GND"/>
</segment>
<segment>
<pinref part="RCHRG" gate="G$1" pin="1"/>
<pinref part="SUPPLY27" gate="GND" pin="GND"/>
</segment>
<segment>
<pinref part="C8" gate="G$1" pin="1"/>
<pinref part="SUPPLY29" gate="GND" pin="GND"/>
</segment>
<segment>
<pinref part="N-FET" gate="G$1" pin="S"/>
<pinref part="SUPPLY12" gate="GND" pin="GND"/>
<pinref part="R17" gate="G$1" pin="1"/>
<wire x1="123.19" y1="16.51" x2="123.19" y2="8.89" width="0.1524" layer="91"/>
<wire x1="118.11" y1="16.51" x2="123.19" y2="16.51" width="0.1524" layer="91"/>
<junction x="123.19" y="16.51"/>
</segment>
<segment>
<pinref part="JST" gate="G$1" pin="1"/>
<wire x1="181.61" y1="78.74" x2="181.102" y2="78.74" width="0.1524" layer="91"/>
<pinref part="SUPPLY7" gate="GND" pin="GND"/>
</segment>
<segment>
<pinref part="TAG-ICSP" gate="G$1" pin="LVP"/>
<wire x1="232.41" y1="86.36" x2="229.87" y2="86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="RGB_LED" gate="G$1" pin="VSS"/>
<pinref part="SUPPLY10" gate="GND" pin="GND"/>
</segment>
<segment>
<pinref part="C1" gate="G$1" pin="1"/>
<pinref part="SUPPLY5" gate="GND" pin="GND"/>
<wire x1="80.01" y1="66.04" x2="80.01" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="205.867" y1="36.83" x2="205.74" y2="31.75" width="0.1524" layer="91"/>
<pinref part="SUPPLY13" gate="GND" pin="GND"/>
<junction x="205.74" y="31.75"/>
<wire x1="203.327" y1="36.83" x2="203.2" y2="31.75" width="0.1524" layer="91"/>
<wire x1="203.2" y1="31.75" x2="205.74" y2="31.75" width="0.1524" layer="91"/>
<wire x1="205.74" y1="31.75" x2="208.28" y2="31.75" width="0.1524" layer="91"/>
<wire x1="208.28" y1="31.75" x2="208.407" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U$11" gate="G$1" pin="GND"/>
<pinref part="U$11" gate="G$1" pin="GND1"/>
<pinref part="U$11" gate="G$1" pin="GND2"/>
</segment>
<segment>
<pinref part="C5" gate="G$1" pin="1"/>
<pinref part="SUPPLY19" gate="GND" pin="GND"/>
<wire x1="93.98" y1="123.19" x2="93.98" y2="125.73" width="0.1524" layer="91"/>
<pinref part="R3" gate="G$1" pin="1"/>
<wire x1="88.9" y1="123.19" x2="93.98" y2="123.19" width="0.1524" layer="91"/>
<junction x="93.98" y="123.19"/>
</segment>
<segment>
<pinref part="SW2" gate="G$1" pin="S"/>
<wire x1="96.52" y1="76.2" x2="96.52" y2="66.04" width="0.1524" layer="91"/>
<pinref part="SUPPLY6" gate="GND" pin="GND"/>
</segment>
<segment>
<wire x1="237.49" y1="52.07" x2="237.49" y2="41.91" width="0.1524" layer="91"/>
<pinref part="ANTC1" gate="G$1" pin="1"/>
<pinref part="ANTC2" gate="G$1" pin="1"/>
<junction x="237.49" y="41.91"/>
<wire x1="237.49" y1="41.91" x2="241.3" y2="41.91" width="0.1524" layer="91"/>
<pinref part="SUPPLY17" gate="GND" pin="GND"/>
<pinref part="ANTC3" gate="G$1" pin="1"/>
<wire x1="237.49" y1="55.88" x2="237.49" y2="52.07" width="0.1524" layer="91"/>
<junction x="237.49" y="52.07"/>
</segment>
<segment>
<pinref part="J1" gate="G$1" pin="GND2"/>
<wire x1="25.4" y1="55.88" x2="22.86" y2="55.88" width="0.1524" layer="91"/>
<wire x1="22.86" y1="55.88" x2="22.86" y2="53.34" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="GND1"/>
<wire x1="25.4" y1="58.42" x2="22.86" y2="58.42" width="0.1524" layer="91"/>
<wire x1="22.86" y1="58.42" x2="22.86" y2="55.88" width="0.1524" layer="91"/>
<junction x="22.86" y="55.88"/>
<pinref part="J1" gate="G$1" pin="GND4"/>
<wire x1="25.4" y1="53.34" x2="22.86" y2="53.34" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="GND3"/>
<wire x1="25.4" y1="50.8" x2="22.86" y2="50.8" width="0.1524" layer="91"/>
<wire x1="22.86" y1="50.8" x2="22.86" y2="53.34" width="0.1524" layer="91"/>
<junction x="22.86" y="53.34"/>
<wire x1="22.86" y1="53.34" x2="22.86" y2="45.72" width="0.1524" layer="91"/>
<wire x1="22.86" y1="45.72" x2="60.96" y2="45.72" width="0.1524" layer="91"/>
<wire x1="60.96" y1="45.72" x2="60.96" y2="60.96" width="0.1524" layer="91"/>
<wire x1="66.04" y1="60.96" x2="60.96" y2="60.96" width="0.1524" layer="91"/>
<pinref part="SUPPLY30" gate="GND" pin="GND"/>
</segment>
</net>
<net name="D10_SS" class="0">
<segment>
<wire x1="71.12" y1="113.03" x2="90.17" y2="113.03" width="0.1524" layer="91"/>
<label x="73.66" y="113.03" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PB2(SS/OC1B)"/>
<pinref part="R20" gate="G$1" pin="1"/>
</segment>
<segment>
<wire x1="190.627" y1="57.15" x2="175.26" y2="57.15" width="0.1524" layer="91"/>
<label x="173.99" y="57.15" size="1.778" layer="95"/>
<pinref part="U$11" gate="G$1" pin="SEL"/>
</segment>
</net>
<net name="RST" class="0">
<segment>
<label x="21.336" y="161.798" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC6(/RESET)"/>
<wire x1="20.32" y1="163.83" x2="22.86" y2="163.83" width="0.1524" layer="91"/>
<pinref part="R1" gate="G$1" pin="2"/>
<wire x1="20.32" y1="163.83" x2="20.32" y2="170.18" width="0.1524" layer="91"/>
<junction x="20.32" y="163.83"/>
<label x="20.32" y="170.18" size="1.27" layer="95" xref="yes"/>
</segment>
<segment>
<pinref part="TAG-ICSP" gate="G$1" pin="ICSP_CLK/PGC"/>
<wire x1="232.41" y1="88.9" x2="229.87" y2="88.9" width="0.1524" layer="91"/>
<label x="229.87" y="88.9" size="1.016" layer="95" rot="R180" xref="yes"/>
</segment>
<segment>
<wire x1="86.36" y1="76.2" x2="80.01" y2="76.2" width="0.1524" layer="91"/>
<pinref part="C1" gate="G$1" pin="2"/>
<pinref part="SW2" gate="G$1" pin="P"/>
<pinref part="C3" gate="G$1" pin="2"/>
<label x="80.01" y="86.36" size="1.27" layer="95" xref="yes"/>
<junction x="80.01" y="76.2"/>
<wire x1="80.01" y1="76.2" x2="76.2" y2="76.2" width="0.1524" layer="91"/>
<wire x1="80.01" y1="86.36" x2="80.01" y2="76.2" width="0.1524" layer="91"/>
<junction x="80.01" y="76.2"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<wire x1="17.78" y1="138.43" x2="17.78" y2="128.27" width="0.1524" layer="91"/>
<wire x1="17.78" y1="138.43" x2="22.86" y2="138.43" width="0.1524" layer="91"/>
<pinref part="ATMEGA328" gate="G$1" pin="PB6(XTAL1/TOSC1)"/>
<pinref part="Y1" gate="G$1" pin="XTAL1_IN"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<wire x1="22.86" y1="133.35" x2="22.86" y2="128.27" width="0.1524" layer="91"/>
<pinref part="ATMEGA328" gate="G$1" pin="PB7(XTAL2/TOSC2)"/>
<pinref part="Y1" gate="G$1" pin="XTAL3_OUT"/>
</segment>
</net>
<net name="VCC" class="0">
<segment>
<pinref part="SUPPLY4" gate="1" pin="VCC"/>
<wire x1="10.16" y1="165.1" x2="10.16" y2="163.83" width="0.2032" layer="91"/>
<pinref part="ATMEGA328" gate="G$1" pin="VCC@2"/>
<pinref part="ATMEGA328" gate="G$1" pin="AVCC"/>
<wire x1="10.16" y1="163.83" x2="10.16" y2="158.75" width="0.2032" layer="91"/>
<wire x1="22.86" y1="153.67" x2="22.86" y2="156.21" width="0.2032" layer="91"/>
<wire x1="22.86" y1="156.21" x2="22.86" y2="158.75" width="0.2032" layer="91"/>
<wire x1="10.16" y1="158.75" x2="22.86" y2="158.75" width="0.2032" layer="91"/>
<junction x="22.86" y="158.75"/>
<pinref part="ATMEGA328" gate="G$1" pin="VCC@1"/>
<junction x="22.86" y="156.21"/>
<junction x="22.86" y="153.67"/>
<pinref part="R1" gate="G$1" pin="1"/>
<junction x="10.16" y="163.83"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="VDDIO"/>
<wire x1="161.29" y1="158.75" x2="154.94" y2="158.75" width="0.1524" layer="91"/>
<wire x1="154.94" y1="158.75" x2="154.94" y2="161.29" width="0.1524" layer="91"/>
<pinref part="SUPPLY22" gate="1" pin="VCC"/>
</segment>
<segment>
<pinref part="R12" gate="G$1" pin="1"/>
<pinref part="SUPPLY24" gate="1" pin="VCC"/>
<wire x1="199.39" y1="138.43" x2="196.85" y2="138.43" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="VDD"/>
<wire x1="179.07" y1="168.91" x2="179.07" y2="170.18" width="0.1524" layer="91"/>
<pinref part="SUPPLY16" gate="1" pin="VCC"/>
</segment>
<segment>
<pinref part="LDO" gate="G$1" pin="VO"/>
<pinref part="C13" gate="G$1" pin="1"/>
<pinref part="C7" gate="G$1" pin="1"/>
<pinref part="SUPPLY1" gate="1" pin="VCC"/>
<wire x1="190.5" y1="95.25" x2="185.42" y2="95.25" width="0.1524" layer="91"/>
<wire x1="195.58" y1="95.25" x2="190.5" y2="95.25" width="0.1524" layer="91"/>
<junction x="195.58" y="95.25"/>
<junction x="190.5" y="95.25"/>
<pinref part="C4" gate="G$1" pin="2"/>
<wire x1="195.58" y1="95.25" x2="205.74" y2="95.25" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R9" gate="G$1" pin="2"/>
<pinref part="SUPPLY3" gate="1" pin="VCC"/>
<pinref part="R10" gate="G$1" pin="2"/>
<wire x1="95.25" y1="163.83" x2="101.6" y2="163.83" width="0.1524" layer="91"/>
<junction x="95.25" y="163.83"/>
</segment>
<segment>
<pinref part="TAG-ICSP" gate="G$1" pin="VDD"/>
<pinref part="SUPPLY2" gate="1" pin="VCC"/>
<wire x1="218.44" y1="96.52" x2="232.41" y2="96.52" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R7" gate="G$1" pin="2"/>
<pinref part="SUPPLY8" gate="1" pin="VCC"/>
</segment>
<segment>
<pinref part="P+6" gate="1" pin="VCC"/>
<wire x1="203.2" y1="66.04" x2="203.327" y2="64.77" width="0.1524" layer="91"/>
<pinref part="U$11" gate="G$1" pin="VCC"/>
</segment>
<segment>
<pinref part="SUPPLY20" gate="1" pin="VCC"/>
<pinref part="R20" gate="G$1" pin="2"/>
<wire x1="100.33" y1="113.03" x2="101.6" y2="113.03" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="SW1" gate="G$1" pin="S"/>
<pinref part="SUPPLY15" gate="1" pin="VCC"/>
<wire x1="109.22" y1="133.35" x2="109.22" y2="139.7" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D1_TX" class="0">
<segment>
<wire x1="71.12" y1="138.43" x2="82.55" y2="138.43" width="0.1524" layer="91"/>
<label x="73.66" y="138.43" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PD1(TXD)"/>
</segment>
<segment>
<label x="60.96" y="73.66" size="1.27" layer="95" xref="yes"/>
<pinref part="J1" gate="G$1" pin="D-2"/>
<wire x1="55.88" y1="73.66" x2="60.96" y2="73.66" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D0_RX" class="0">
<segment>
<wire x1="71.12" y1="140.97" x2="82.55" y2="140.97" width="0.1524" layer="91"/>
<label x="73.66" y="140.97" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PD0(RXD)"/>
</segment>
<segment>
<label x="60.96" y="71.12" size="1.27" layer="95" xref="yes"/>
<pinref part="J1" gate="G$1" pin="D+2"/>
<wire x1="55.88" y1="71.12" x2="60.96" y2="71.12" width="0.1524" layer="91"/>
</segment>
</net>
<net name="A6" class="0">
<segment>
<wire x1="71.12" y1="148.59" x2="82.55" y2="148.59" width="0.1524" layer="91"/>
<label x="73.66" y="148.59" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="ADC6"/>
</segment>
</net>
<net name="A4_SDA" class="0">
<segment>
<wire x1="71.12" y1="153.67" x2="95.25" y2="153.67" width="0.1524" layer="91"/>
<label x="73.66" y="153.67" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC4(ADC4/SDA)"/>
<pinref part="R9" gate="G$1" pin="1"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="SDA"/>
<wire x1="173.99" y1="138.43" x2="168.91" y2="138.43" width="0.1524" layer="91"/>
<label x="168.91" y="138.43" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="D11_MOSI" class="0">
<segment>
<pinref part="ATMEGA328" gate="G$1" pin="PB3(MOSI/OC2)"/>
<wire x1="82.042" y1="110.49" x2="71.12" y2="110.49" width="0.1524" layer="91"/>
<label x="73.66" y="110.49" size="1.778" layer="95"/>
</segment>
<segment>
<pinref part="TAG-ICSP" gate="G$1" pin="ICSP_DAT/PGD"/>
<wire x1="232.41" y1="91.44" x2="229.87" y2="91.44" width="0.1524" layer="91"/>
<label x="229.87" y="91.44" size="1.016" layer="95" rot="R180" xref="yes"/>
</segment>
<segment>
<wire x1="190.627" y1="49.53" x2="175.26" y2="49.53" width="0.1524" layer="91"/>
<label x="173.99" y="49.53" size="1.778" layer="95"/>
<pinref part="U$11" gate="G$1" pin="MOSI"/>
</segment>
</net>
<net name="D12_MISO" class="0">
<segment>
<wire x1="71.12" y1="107.95" x2="82.55" y2="107.95" width="0.1524" layer="91"/>
<label x="73.66" y="107.95" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PB4(MISO)"/>
</segment>
<segment>
<pinref part="TAG-ICSP" gate="G$1" pin="VPP/MCLR"/>
<wire x1="232.41" y1="99.06" x2="229.87" y2="99.06" width="0.1524" layer="91"/>
<label x="229.87" y="99.06" size="1.016" layer="95" rot="R180" xref="yes"/>
</segment>
<segment>
<wire x1="190.627" y1="52.07" x2="175.26" y2="52.07" width="0.1524" layer="91"/>
<label x="173.99" y="52.07" size="1.778" layer="95"/>
<pinref part="U$11" gate="G$1" pin="MISO"/>
</segment>
</net>
<net name="D13_SCK" class="0">
<segment>
<wire x1="71.12" y1="105.41" x2="83.82" y2="105.41" width="0.1524" layer="91"/>
<label x="73.66" y="105.41" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PB5(SCK)"/>
</segment>
<segment>
<pinref part="TAG-ICSP" gate="G$1" pin="VSS(GND)"/>
<wire x1="232.41" y1="93.98" x2="229.87" y2="93.98" width="0.1524" layer="91"/>
<label x="229.87" y="93.98" size="1.016" layer="95" rot="R180" xref="yes"/>
</segment>
<segment>
<wire x1="190.627" y1="54.61" x2="175.26" y2="54.61" width="0.1524" layer="91"/>
<label x="173.99" y="54.61" size="1.778" layer="95"/>
<pinref part="U$11" gate="G$1" pin="SCK"/>
</segment>
</net>
<net name="A5_SCL" class="0">
<segment>
<label x="73.66" y="151.13" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC5(ADC5/SCL)"/>
<pinref part="R10" gate="G$1" pin="1"/>
<wire x1="71.12" y1="151.13" x2="101.6" y2="151.13" width="0.1524" layer="91"/>
<wire x1="101.6" y1="151.13" x2="101.6" y2="153.67" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="SCL"/>
<wire x1="161.29" y1="151.13" x2="160.02" y2="151.13" width="0.1524" layer="91"/>
<label x="160.02" y="151.13" size="1.778" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="A2_CHGSTAT" class="0">
<segment>
<wire x1="71.12" y1="158.75" x2="82.55" y2="158.75" width="0.1524" layer="91"/>
<label x="73.66" y="158.75" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC2(ADC2)"/>
</segment>
<segment>
<pinref part="MCP73831" gate="G$1" pin="STAT"/>
<pinref part="R7" gate="G$1" pin="1"/>
<label x="127" y="87.63" size="1.27" layer="95" rot="R180" xref="yes"/>
<wire x1="127" y1="90.17" x2="111.76" y2="90.17" width="0.1524" layer="91"/>
<wire x1="111.76" y1="90.17" x2="111.76" y2="96.52" width="0.1524" layer="91"/>
<wire x1="127" y1="87.63" x2="127" y2="90.17" width="0.1524" layer="91"/>
<junction x="127" y="90.17"/>
</segment>
</net>
<net name="D7_ACCEL" class="0">
<segment>
<wire x1="71.12" y1="123.19" x2="81.28" y2="123.19" width="0.1524" layer="91"/>
<label x="73.66" y="123.19" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PD7(AIN1)"/>
</segment>
<segment>
<pinref part="LIS3DH" gate="G$1" pin="INT1"/>
<wire x1="191.77" y1="153.67" x2="194.31" y2="153.67" width="0.1524" layer="91"/>
<pinref part="TP1" gate="G$1" pin="P$1"/>
<wire x1="194.31" y1="153.67" x2="194.31" y2="160.02" width="0.1524" layer="91"/>
</segment>
</net>
<net name="D6" class="0">
<segment>
<wire x1="71.12" y1="125.73" x2="81.28" y2="125.73" width="0.1524" layer="91"/>
<label x="73.66" y="125.73" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PD6(AIN0)"/>
</segment>
</net>
<net name="D3" class="0">
<segment>
<pinref part="ATMEGA328" gate="G$1" pin="PD3(INT1)"/>
<label x="73.66" y="133.35" size="1.778" layer="95"/>
<pinref part="C5" gate="G$1" pin="2"/>
<wire x1="93.98" y1="133.35" x2="88.9" y2="133.35" width="0.1524" layer="91"/>
<junction x="93.98" y="133.35"/>
<pinref part="R3" gate="G$1" pin="2"/>
<wire x1="88.9" y1="133.35" x2="87.63" y2="133.35" width="0.1524" layer="91"/>
<junction x="88.9" y="133.35"/>
<pinref part="SW1" gate="G$1" pin="P"/>
<wire x1="93.98" y1="133.35" x2="99.06" y2="133.35" width="0.1524" layer="91"/>
<wire x1="71.12" y1="133.35" x2="88.9" y2="133.35" width="0.1524" layer="91"/>
<wire x1="88.9" y1="133.35" x2="88.9" y2="140.97" width="0.1524" layer="91"/>
<label x="88.9" y="140.97" size="1.27" layer="95" xref="yes"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="LIS3DH" gate="G$1" pin="CS"/>
<wire x1="186.69" y1="138.43" x2="179.07" y2="138.43" width="0.1524" layer="91"/>
<pinref part="R12" gate="G$1" pin="2"/>
</segment>
</net>
<net name="A7_VMON" class="0">
<segment>
<label x="173.99" y="124.46" size="1.778" layer="95" rot="R180" xref="yes"/>
<pinref part="R5" gate="G$1" pin="2"/>
<pinref part="R6" gate="G$1" pin="1"/>
<wire x1="175.26" y1="118.11" x2="175.26" y2="124.46" width="0.1524" layer="91"/>
<pinref part="C2" gate="G$1" pin="1"/>
<wire x1="175.26" y1="124.46" x2="173.99" y2="124.46" width="0.1524" layer="91"/>
<junction x="175.26" y="118.11"/>
</segment>
<segment>
<wire x1="71.12" y1="146.05" x2="82.55" y2="146.05" width="0.1524" layer="91"/>
<label x="73.66" y="146.05" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="ADC7"/>
</segment>
</net>
<net name="VUSB" class="0">
<segment>
<pinref part="MCP73831" gate="G$1" pin="VIN"/>
<pinref part="C8" gate="G$1" pin="2"/>
<wire x1="127" y1="104.14" x2="127" y2="95.25" width="0.1524" layer="91"/>
<junction x="127" y="95.25"/>
<pinref part="SUPPLY34" gate="G$1" pin="VUSB"/>
</segment>
<segment>
<pinref part="SUPPLY33" gate="G$1" pin="VUSB"/>
<wire x1="66.04" y1="90.17" x2="66.04" y2="86.36" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="VBUS1"/>
<wire x1="25.4" y1="88.9" x2="22.86" y2="88.9" width="0.1524" layer="91"/>
<wire x1="22.86" y1="88.9" x2="22.86" y2="93.98" width="0.1524" layer="91"/>
<wire x1="22.86" y1="93.98" x2="58.42" y2="93.98" width="0.1524" layer="91"/>
<wire x1="58.42" y1="93.98" x2="58.42" y2="88.9" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="VBUS3"/>
<wire x1="58.42" y1="88.9" x2="55.88" y2="88.9" width="0.1524" layer="91"/>
<pinref part="J1" gate="G$1" pin="VBUS2"/>
<wire x1="25.4" y1="86.36" x2="22.86" y2="86.36" width="0.1524" layer="91"/>
<wire x1="22.86" y1="86.36" x2="22.86" y2="88.9" width="0.1524" layer="91"/>
<junction x="22.86" y="88.9"/>
<pinref part="J1" gate="G$1" pin="VBUS4"/>
<wire x1="55.88" y1="86.36" x2="58.42" y2="86.36" width="0.1524" layer="91"/>
<wire x1="58.42" y1="86.36" x2="58.42" y2="88.9" width="0.1524" layer="91"/>
<junction x="58.42" y="88.9"/>
<wire x1="66.04" y1="86.36" x2="58.42" y2="86.36" width="0.1524" layer="91"/>
<junction x="58.42" y="86.36"/>
</segment>
</net>
<net name="VBAT" class="0">
<segment>
<pinref part="MCP73831" gate="G$1" pin="VBAT"/>
<wire x1="147.32" y1="95.25" x2="160.528" y2="95.25" width="0.1524" layer="91"/>
<pinref part="LDO" gate="G$1" pin="VI"/>
<pinref part="C14" gate="G$1" pin="1"/>
<wire x1="165.1" y1="95.25" x2="163.83" y2="95.25" width="0.1524" layer="91"/>
<junction x="163.83" y="95.25"/>
<label x="154.94" y="96.52" size="1.778" layer="95"/>
<pinref part="JST" gate="G$1" pin="2"/>
<wire x1="160.528" y1="95.25" x2="163.83" y2="95.25" width="0.1524" layer="91"/>
<wire x1="181.61" y1="81.28" x2="160.528" y2="81.28" width="0.1524" layer="91"/>
<wire x1="160.528" y1="81.28" x2="160.528" y2="95.25" width="0.1524" layer="91"/>
<junction x="160.528" y="95.25"/>
</segment>
<segment>
<pinref part="R6" gate="G$1" pin="2"/>
<wire x1="163.83" y1="118.11" x2="165.1" y2="118.11" width="0.1524" layer="91"/>
<label x="163.83" y="118.11" size="1.27" layer="95" rot="R180" xref="yes"/>
</segment>
<segment>
<label x="130.81" y="46.99" size="1.778" layer="95" xref="yes"/>
<wire x1="130.81" y1="41.91" x2="130.81" y2="46.99" width="0.1524" layer="91"/>
<pinref part="IR2-BTM" gate="G$1" pin="A"/>
<wire x1="115.57" y1="41.91" x2="130.81" y2="41.91" width="0.1524" layer="91"/>
<wire x1="140.97" y1="41.91" x2="130.81" y2="41.91" width="0.1524" layer="91"/>
<junction x="130.81" y="41.91"/>
<pinref part="IRLED-TOP" gate="G$1" pin="A"/>
</segment>
<segment>
<pinref part="R8" gate="G$1" pin="2"/>
<pinref part="PFET" gate="G$1" pin="S"/>
<wire x1="29.21" y1="36.83" x2="33.02" y2="36.83" width="0.1524" layer="91"/>
<label x="29.21" y="36.83" size="1.27" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="MCP73831" gate="G$1" pin="PROG"/>
<wire x1="154.94" y1="92.71" x2="147.32" y2="92.71" width="0.1524" layer="91"/>
<pinref part="RCHRG" gate="G$1" pin="2"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="R4" gate="G$1" pin="1"/>
<pinref part="N-FET" gate="G$1" pin="G"/>
<wire x1="107.95" y1="21.59" x2="115.57" y2="21.59" width="0.1524" layer="91"/>
<pinref part="R17" gate="G$1" pin="2"/>
<wire x1="107.95" y1="21.59" x2="107.95" y2="16.51" width="0.1524" layer="91"/>
<junction x="107.95" y="21.59"/>
</segment>
</net>
<net name="D4_RGBPWR" class="0">
<segment>
<pinref part="R8" gate="G$1" pin="1"/>
<wire x1="29.21" y1="26.67" x2="25.4" y2="26.67" width="0.1524" layer="91"/>
<label x="25.4" y="26.67" size="1.778" layer="95" rot="R180" xref="yes"/>
<pinref part="PFET" gate="G$1" pin="G"/>
<wire x1="29.21" y1="26.67" x2="38.1" y2="26.67" width="0.1524" layer="91"/>
<wire x1="38.1" y1="26.67" x2="38.1" y2="29.21" width="0.1524" layer="91"/>
<junction x="29.21" y="26.67"/>
</segment>
<segment>
<wire x1="71.12" y1="130.81" x2="81.28" y2="130.81" width="0.1524" layer="91"/>
<label x="73.66" y="130.81" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PD4(XCK/T0)"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="RGB_LED" gate="G$1" pin="VDD"/>
<wire x1="43.18" y1="36.83" x2="43.18" y2="26.67" width="0.1524" layer="91"/>
<pinref part="PFET" gate="G$1" pin="D"/>
</segment>
</net>
<net name="D8" class="0">
<segment>
<pinref part="ATMEGA328" gate="G$1" pin="PB0(ICP)"/>
<wire x1="71.12" y1="118.11" x2="81.28" y2="118.11" width="0.1524" layer="91"/>
<label x="73.914" y="118.11" size="1.778" layer="95"/>
</segment>
</net>
<net name="A3_RGB_DATA" class="0">
<segment>
<pinref part="RGB_LED" gate="G$1" pin="DI"/>
<wire x1="43.18" y1="19.05" x2="40.64" y2="19.05" width="0.1524" layer="91"/>
<label x="40.64" y="19.05" size="1.27" layer="95" rot="R180" xref="yes"/>
</segment>
<segment>
<wire x1="71.12" y1="156.21" x2="82.55" y2="156.21" width="0.1524" layer="91"/>
<label x="73.66" y="156.21" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC3(ADC3)"/>
</segment>
</net>
<net name="ANT" class="0">
<segment>
<wire x1="229.87" y1="52.07" x2="219.71" y2="52.07" width="0.1524" layer="91"/>
<pinref part="ANTC1" gate="G$1" pin="2"/>
<pinref part="R2" gate="G$1" pin="1"/>
<wire x1="219.71" y1="52.07" x2="216.027" y2="52.07" width="0.1524" layer="91"/>
<junction x="219.71" y="52.07"/>
<pinref part="U$11" gate="G$1" pin="ANT"/>
<wire x1="216.027" y1="52.07" x2="215.9" y2="52.07" width="0.1524" layer="91"/>
<junction x="216.027" y="52.07"/>
<pinref part="U$1" gate="G$1" pin="1"/>
<pinref part="ANTC3" gate="G$1" pin="2"/>
<wire x1="229.87" y1="55.88" x2="229.87" y2="52.07" width="0.1524" layer="91"/>
<junction x="229.87" y="52.07"/>
</segment>
</net>
<net name="D2_RFM" class="0">
<segment>
<wire x1="71.12" y1="135.89" x2="82.55" y2="135.89" width="0.1524" layer="91"/>
<label x="73.66" y="135.89" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PD2(INT0)"/>
</segment>
<segment>
<wire x1="190.627" y1="44.45" x2="175.26" y2="44.45" width="0.1524" layer="91"/>
<label x="173.99" y="44.45" size="1.778" layer="95"/>
<pinref part="U$11" gate="G$1" pin="DIO0"/>
</segment>
</net>
<net name="D5" class="0">
<segment>
<pinref part="ATMEGA328" gate="G$1" pin="PD5(T1)"/>
<wire x1="71.12" y1="128.27" x2="81.28" y2="128.27" width="0.1524" layer="91"/>
<label x="73.66" y="128.27" size="1.778" layer="95"/>
</segment>
</net>
<net name="D9_IR" class="0">
<segment>
<wire x1="71.12" y1="115.57" x2="81.28" y2="115.57" width="0.1524" layer="91"/>
<label x="73.66" y="115.57" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PB1(OC1A)"/>
</segment>
<segment>
<pinref part="R4" gate="G$1" pin="2"/>
<wire x1="97.79" y1="21.59" x2="96.52" y2="21.59" width="0.1524" layer="91"/>
<label x="96.52" y="21.59" size="1.27" layer="95" rot="R180" xref="yes"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="IR2-BTM" gate="G$1" pin="C"/>
<pinref part="IRLED-TOP" gate="G$1" pin="C"/>
<wire x1="140.97" y1="29.21" x2="123.19" y2="29.21" width="0.1524" layer="91"/>
<pinref part="N-FET" gate="G$1" pin="D"/>
<wire x1="123.19" y1="29.21" x2="115.57" y2="29.21" width="0.1524" layer="91"/>
<wire x1="123.19" y1="26.67" x2="123.19" y2="29.21" width="0.1524" layer="91"/>
<junction x="123.19" y="29.21"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="U$5" gate="G$1" pin="TRACE"/>
<wire x1="250.19" y1="35.56" x2="250.19" y2="49.53" width="0.1524" layer="91"/>
<wire x1="250.19" y1="49.53" x2="248.92" y2="49.53" width="0.1524" layer="91"/>
<wire x1="248.92" y1="49.53" x2="248.92" y2="44.45" width="0.1524" layer="91"/>
<wire x1="248.92" y1="44.45" x2="247.65" y2="44.45" width="0.1524" layer="91"/>
<wire x1="247.65" y1="44.45" x2="247.65" y2="49.53" width="0.1524" layer="91"/>
<wire x1="247.65" y1="49.53" x2="246.38" y2="49.53" width="0.1524" layer="91"/>
<wire x1="246.38" y1="49.53" x2="246.38" y2="46.99" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="ANTC2" gate="G$1" pin="2"/>
<pinref part="R2" gate="G$1" pin="2"/>
<wire x1="229.87" y1="41.91" x2="219.71" y2="41.91" width="0.1524" layer="91"/>
<pinref part="U$5" gate="G$1" pin="FEED"/>
<wire x1="219.71" y1="41.91" x2="219.71" y2="35.56" width="0.1524" layer="91"/>
<junction x="219.71" y="41.91"/>
</segment>
</net>
<net name="A0" class="0">
<segment>
<wire x1="71.12" y1="163.83" x2="82.55" y2="163.83" width="0.1524" layer="91"/>
<label x="73.66" y="163.83" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC0(ADC0)"/>
</segment>
</net>
<net name="A1" class="0">
<segment>
<wire x1="71.12" y1="161.29" x2="82.55" y2="161.29" width="0.1524" layer="91"/>
<label x="73.66" y="161.29" size="1.778" layer="95"/>
<pinref part="ATMEGA328" gate="G$1" pin="PC1(ADC1)"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
</compatibility>
</eagle>
